# Milestone 1 — Report

**Scope:** inspect the supplied references, establish the project architecture, select and inspect the
heart 3D model, prepare an optimized asset for Godot. Status: **complete — awaiting your review/approval.**
No Stage 1 learning content, Stage 2 or Stage 3 features have been started.

## 1. Completed

1. **Reference review** — all 92 images, 10 videos (storyboards), the PDF reference card and the brief
   were inspected and classified per stage/feature → `docs/01_Reference_Inventory.md`.
2. **Heart model selection** — commercial models were rejected (no redistribution rights); the
   MRI-derived **BodyParts3D** dataset (CC BY-SA 2.1 JP) was selected because it is anatomically
   segmented and licensable.
3. **Asset preparation pipeline** (reproducible, `tools/asset_pipeline/`):
   * chamber segmentation of the hollow heart wall → RA, LA, RV, LV, interventricular & interatrial septum;
   * clean plane-cuts of the great vessels; pulmonary vessels trimmed at the hila;
   * reconstructed aortic valve (missing from the source) with an `open` blend shape;
   * Godot coordinate system (metres, +Y superior, +Z anterior), anatomical position;
   * decimation 537k → ~156k triangles (Godot meshoptimizer), 4 MB GLB, 36 named parts;
   * epicardial-fat vertex mask along the main coronary grooves;
   * procedural tissue textures (myocardium, vessel, valve, fat).
4. **Rendering look (Compatibility renderer)** — tissue shader (triplanar detail, wet specular, rim,
   epicardial fat, cutaway with solid-looking section faces), ghost and highlight shaders, studio lighting.
5. **Reusable runtime components** — `HeartModel`, `OrbitCamera`, `PartPicker`, `StudioEnvironment`,
   `AppState` (quality presets + settings), `SceneRouter` (fade transitions, safe loading).
6. **Main dashboard** — three stages with status chips and progress, rotating heart preview, graphics
   quality selector (persisted), credits & licences dialog, educational disclaimer.
7. **Heart Model Inspector** (Stage 1 · M1 preview) — orbit/pan/zoom, 6 preset views, structure tree with
   visibility checkboxes, hover tooltip, click selection with highlight, focus / isolate / hide / clear,
   cutaway (coronal / sagittal / transverse, depth, flip), model statistics and FPS.

Screenshots (software-rendered test machine): `docs/screenshots/`.

## 2. Files created

| Path | Purpose |
|---|---|
| `project.godot`, `icon.svg`, `export_presets.cfg` | project config (Compatibility, autoloads, global uniforms), Windows export preset |
| `assets/models/heart/heart.glb` (+ `.import`, `heart_manifest.json`) | optimized heart asset + per-part statistics |
| `assets/materials/*.tres` (13) | tissue / ghost / highlight / hover materials |
| `assets/shaders/tissue.gdshader`, `ghost.gdshader`, `highlight.gdshader` | shaders |
| `assets/textures/tissue/*.png` (7) | procedural detail textures |
| `assets/fonts/Inter-*.ttf` + licence, `assets/ui/theme.tres` | typography + application theme |
| `data/anatomy/heart_parts.json`, `data/credits.json` | part registry, credits |
| `scenes/main/main.tscn`, `scenes/shared/heart_model.tscn`, `scenes/tools/heart_inspector.tscn` | scenes |
| `scripts/core/app_state.gd`, `scene_router.gd` | autoloads |
| `scripts/shared/heart_model.gd`, `orbit_camera.gd`, `part_picker.gd`, `studio_environment.gd` | shared components |
| `scripts/ui/ui_palette.gd`, `main_dashboard.gd` | UI |
| `scripts/tools/heart_inspector.gd`, `build_theme.gd` | inspector, theme generator |
| `tools/asset_pipeline/*` | heart build pipeline (Python + Godot) |
| `tools/blender/open_heart_in_blender.py` | open/edit the heart in Blender, export settings |
| `docs/01–03*.md`, `ASSET_LICENSES.md`, `README.md` | documentation |

No files were modified outside the project folder; your reference folder was only read.

## 3. How to run and test

1. Install **Godot 4.3 or newer** (standard build, not .NET). Open Godot → *Import* → select
   `CardioCath3D/project.godot`. The first import takes ~30 s (fonts, textures, heart model).
2. Press **F5**. The dashboard opens.
3. Test checklist:
   * Dashboard: drag the heart preview; change *Graphics quality* (restart not needed); open *Credits*.
   * Stage 1 → **Open heart model**. Rotate (left-drag), pan (right/middle-drag), zoom (wheel).
   * Click a structure (e.g. LAD on the front) → cyan highlight + details on the right; hover shows names.
   * In the list untick *Chambers* → valves, papillary muscles and coronary tree remain visible.
   * Select *Aortic valve* → note the "reconstructed" flag. *Isolate* → other parts become translucent.
   * Enable **cutaway**, choose *Coronal*, move *Depth* → internal anatomy (LV cavity, mitral valve,
     chordae, papillary muscles); click internal structures through the cut.
   * *Reset all* restores everything. *← Dashboard* returns with a fade.
4. Optional QA screenshots: run Godot with
   `--path <project> res://scenes/tools/heart_inspector.tscn -- --qa-shots=C:/temp/qa`.

## 4. Known limitations

* Chamber/septum boundaries come from automatic segmentation; the AV-junction borders are approximate.
* Aortic valve is illustrative (not from imaging). Diagonal and obtuse-marginal branches are not
  separate objects (included in LAD / LCx).
* Educational texts (location, structure, function, relations) are intentionally not written yet
  (Milestone 2, for your review).
* Performance was verified for correctness on a software renderer only; real FPS must be checked on
  the target Intel laptop (FPS counter bottom-right of the inspector). Use *Low* quality if < 30 FPS.
* UI is English only for now.

## 5. Remaining work (next milestones)

M2 Stage 1 anatomy scene & educational content · M3 physiology, cardiac cycle, blood flow, histology ·
M4 Stage 2 · M5 Stage 3 · M6 integration, optimization, export (see `docs/02_Architecture.md`).

## 6. Decisions needed from you before Milestone 2

1. **Interface language:** English only, or bilingual English + Arabic (right-to-left layout)?
2. **Coronary branches:** is LAD/LCx with built-in diagonal/marginal branches acceptable, or should D1/D2
   and OM branches be split into separately selectable parts (manual work in Blender)?
3. **Histology (M3):** supply licensed micrographs, or approve openly-licensed images (e.g. OpenStax
   *Anatomy & Physiology 2e*, CC BY 4.0) with attribution?
4. **Stage 3 references (M5):** the instrument folder contains urinary-catheter kits; please add real
   cardiac-cath items if available (sheath, guidewire, Judkins catheters, inflation device, cath-lab table).
5. **Approval** of the heart model and the visual style shown in `docs/screenshots/`.
