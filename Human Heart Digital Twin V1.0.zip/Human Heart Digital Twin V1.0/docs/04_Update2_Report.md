# Update 2 — Stage 1 interactive heart, diseases and cardiac tissue

Requested changes: (1) a more realistic heart using the new images/videos and the histology manual,
(2) a fully interactive heart for medical students (dissection, heart-rate control, etc.),
(3) simulated diseases showing their effect on the heart.

## 1. New references used
| Reference | Used for |
|---|---|
| 3 realistic heart images (anatomical structure, cut-open heart, VOKA-style anterior view) | colour/gloss target: dark maroon wet myocardium, creamy epicardial fat in the grooves, glossy pale great vessels |
| Video: sheep-heart dissection (Arabic) | real tissue colours (pale fat over the base, dark ventricles), long-axis opening of the LV → *Long axis (LVOT)* cut and quick dissection steps |
| Video: cardiomyocyte 3D animation (VOKA) | structure of the 3D tissue and cardiomyocyte levels (branching striated fibres, capillaries, fibroblasts, opened cell with myofibrils, SR, nucleus, T-tubules, mitochondria) |
| Video: coronary plaque / bypass | occlusion marker in the LAD/RCA infarction scenarios |
| Michigan Histology Laboratory Manual (pp. 46–55, 142–155) | histology texts and 5 real micrographs (CC BY-NC-SA 4.0) and the muscle-type comparison table |

## 2. What was added / changed
**Realism** – baked ambient occlusion, new tissue lighting model (wrapped diffuse with red scattering,
GGX + sharp "wet" highlight), darker maroon myocardium, creamier fat, glossier vessels.
**Asset pipeline** – per-vertex chamber-proximity weights, LAD/RCA territories, AO and landmarks
(apex, AV plane, valve centres, chamber centroids, occlusion sites, label anchors).
**Beating heart** – `CardiacEngine` (sinus / AF / complete heart block / VF) drives a shader
deformation shared by every part, so arteries stay on the wall while it contracts.
**Heart Lab** – replaces the Milestone-1 inspector: Explore, Dissect, Physiology, Diseases, Quiz modes;
info panel with educational texts for all 36 structures; ECG monitor and vital signs; 3D labels.
**Cardiac Tissue** – new scene with 5 levels and micrograph viewer.

## 3. New / changed files
`scripts/shared/cardiac_engine.gd`, `scripts/stage1/heart_lab.gd`, `scripts/stage1/tissue_lab.gd`,
`scripts/ui/ecg_monitor.gd`, `scripts/ui/part_labels.gd`, `scripts/shared/heart_model.gd` (explode,
scalpel/undo, landmarks, markers), `orbit_camera.gd`, `part_picker.gd`, `studio_environment.gd`,
`assets/shaders/heart_common.gdshaderinc`, `tissue.gdshader`, `ghost.gdshader`, `highlight.gdshader`,
`striated.gdshader`, `tissue_glass.gdshader`, `assets/materials/*.tres` (+ `valve_aortic.tres`),
`assets/models/heart/heart.glb` + manifest, `assets/histology/*.jpg`, `data/anatomy/heart_parts.json`,
`data/physiology/conditions.json`, `data/physiology/phases.json`, `data/histology/tissue.json`,
`scenes/stage1/heart_lab.tscn`, `scenes/stage1/tissue_lab.tscn`, dashboard, credits, licences, docs.
Removed: `scenes/tools/heart_inspector.tscn` and its script (superseded by the Heart Lab).

## 4. How to test
1. Open the project in Godot 4.3+, press F5. Dashboard → Stage 1 → **Open Heart Lab**.
2. **Physiology**: the heart beats; move *Heart rate* (40–180), set *Speed* 0.1× and watch the phase
   name, valve chips and the ECG; enable *Labels*.
3. **Dissect**: *Four-chamber*, then *Long axis*, *Short axis*, *Valve plane*; move *Depth*/*Tilt*;
   turn on *Scalpel* and click structures; *Undo*; *Separate* slider.
4. **Diseases**: select each condition → *Show recommended view*; change *Severity*; compare
   lead II and V2 for the two infarctions; AF shows quivering atria and irregular beats; complete
   heart block shows independent atrial and ventricular beats; VF shows quivering ventricles, no output.
5. **Quiz**: *Start new quiz*.
6. Dashboard → **Cardiac tissue**: click through levels 1–5; level 4 → *Animate contraction*.

## 5. Known limitations
* All waveforms, vital signs and deformations are simplified **educational simulations**.
* Mitral, tricuspid and pulmonary valves come from static meshes (their open/closed state is shown in
  the Physiology panel); the reconstructed aortic valve animates.
* Infarct territories come from distance to the coronary branches (dominance pattern of this model);
  the colour change of infarcted tissue is an illustrative cue, not a time-accurate gross appearance.
* FPS checked only on a software renderer here — please check on the target laptop (FPS counter
  bottom-right; use *Graphics quality → Low* if needed).
* Micrographs are CC BY-NC-SA 4.0 → non-commercial distribution only.

## 6. Next
Blood-flow animation (pulmonary/systemic, arrows/particles) and pressure curves (Wiggers diagram) to
complete Stage 1, then Stage 2 (conduction system on this same heart, 12-lead viewer, six rhythms).
