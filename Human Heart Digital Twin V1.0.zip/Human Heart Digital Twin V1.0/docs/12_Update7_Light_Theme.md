# Update 7 — light clinical theme (white + green)

Version 0.6.1

## Colour system
White is the primary surface colour, and green is the secondary colour, used for actions and selection.

All tokens live in `scripts/ui/ui_palette.gd`. To regenerate the theme:

```
godot --headless --path . -s res://scripts/tools/build_theme.gd
```

| Token | Hex | Use | Contrast on white |
|---|---|---|---|
| PANEL | #FFFFFF | Cards, panels | — |
| BG | #EEF3F0 | App background (mint-grey) | — |
| PANEL_RAISED | #F4F8F5 | Inputs, raised rows | — |
| BORDER | #D3DED7 | Hairlines | — |
| TEXT | #15241F | Body text | 16.1 : 1 |
| TEXT_MUTED | #5B6B65 | Secondary text | 5.6 : 1 |
| ACCENT | #0B7A52 | Primary buttons, selection, progress | white text on it 5.4 : 1 |
| ACCENT_HOVER | #08643F | Hover / pressed | — |
| ACCENT_TINT | #E3F2EA | Hover background, selected list rows | — |
| SUCCESS | #0F7A45 | OK states | ≥ 4.5 : 1 |
| WARNING | #A86400 | Cautions, "simulated" notes | 4.7 : 1 |
| DANGER | #C2362F | Errors, BP | 5.4 : 1 |
| Info | #2563EB / #6D3FC8 | Secondary data colours | ≥ 4.5 : 1 |

### Rules applied
These are the ui-ux-pro-max fallback rules:
* Text contrast is at least 4.5 : 1.
* There is one accent colour: green, used only for interactive and selected states.
* Colours are semantic tokens; no raw hex values appear in the panels.
* Icons follow the text colour: muted by default, green on hover, white on filled green buttons.

## What changed
* `ui_palette.gd` and `build_theme.gd` were rewritten for the light theme.
* New switch, checkbox and radio icons (green and white). Godot's grey defaults were invisible on white.
* Hardcoded panel colours and rich-text colours were remapped in these files:
  * `main_dashboard.gd`
  * `ui_kit.gd`
  * `heart_lab.gd`
  * `ep_lab.gd`
  * `cath_lab.gd`
* Badges use darker text on light chips.
* The default 3D backdrop is now **Clinical mint** (white → soft green). Existing settings are switched to it once, through `styles_version` 3. The other backdrops are still available under View.

## Deliberately kept dark
Medical display screens and 3D overlays stay dark, as on real equipment:
* the ECG monitor and ECG strips;
* the 12-lead paper view;
* the fluoroscopy / angiography image;
* the 3D labels (light text with a dark outline).

## Testing
* Headless parse check of the dashboard and all three labs.
* Xvfb renders of the dashboard, the Heart Lab, the EP Lab and the Cath Lab, used to check contrast.
