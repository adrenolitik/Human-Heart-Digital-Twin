# Update 6 — blood flow, vessel fixes, interactive radial PCI

Version 0.6.0

> Simplified educational simulation. Not procedural guidance.

## Stage 1

### Cardiac-tissue module removed
* The **Cardiac tissue** button has been removed from the dashboard.
* The tissue scene, its script, its data and the micrographs were removed from the project, and their licence and credit entries were deleted.
* Copies of these files that already exist in your folder are no longer referenced, and can be deleted:
  * `scenes/stage1/tissue_lab.tscn`
  * `scripts/stage1/tissue_lab.gd`
  * `data/histology/`
  * `assets/histology/`
  * `assets/shaders/striated.gdshader`
  * `assets/shaders/tissue_glass.gdshader`

### Blood flow (Heart Lab → Physiology)
**What the student sees**
* Blood cells stream through the heart along centrelines computed from the model (`data/physiology/blood_paths.json`, built by `tools/asset_pipeline/build_blood_paths.py`).
* Two circuits are shown:
  * **Right heart:** superior/inferior vena cava → right atrium → tricuspid valve → right ventricle → outflow tract → pulmonary valve → trunk → pulmonary arteries.
  * **Left heart:** four pulmonary veins → left atrium → mitral valve → left ventricle → outflow tract → aortic valve → aorta.
* The flow follows the engine's real valve state, so it stays in step with the ECG and wall motion:
  * blood collects in the atria while the AV valves are shut;
  * it pours into the ventricles when they open;
  * it is ejected only while the aortic and pulmonary valves are open;
  * in diastole, run-off in the arteries slows.
* Colours follow the teaching convention: oxygen-poor blue-violet, oxygen-rich red.

**Controls**
* **Show blood**.
* **See-through walls:** the walls are ghosted while the valves and papillary muscles stay solid.
* Use 0.25× or 0.1× speed to follow each phase.

### Vessel fixes
* **Free ends closed.** Every free end of the great vessels is now closed with a domed cap: inferior vena cava, descending aorta, arch branches, pulmonary arteries, and the pulmonary veins that looked like hollow "claws". The pipeline change is in `build_final.py`.
* **Exploded view keeps vessel trees whole.** The aorta and its branches, the pulmonary trunk and arteries, the coronary arteries and the cardiac veins each move as one piece. Branches are no longer torn into floating segments.

## Stage 3 (v3)

### Scene
* The procedure starts directly at the **radial puncture**. The old "patient positioning" step was removed.
* Only the parts the procedure needs are shown:
  * the right forearm, wrist and hand on the arm board, inside the sterile sheet;
  * the arm arteries, great vessels and beating heart.
* Removed: the full body, head, chest, room, table, C-arm and the Room/Monitor cameras.
* Cameras: Auto, Access, Anatomy, Internal (keys 1–4).

### The student performs the procedure
Each step shows a task checklist. A task completes only when it is actually done, in order.

| Step | What you do | Safety checks |
|---|---|---|
| 1 Radial access | Click the pulse ring on the wrist (or **Puncture**) → hold **Advance mini-wire** → **Remove needle** | No wire before the puncture |
| 2 Sheath | Hold **Advance sheath** → **Remove mini-wire** → **Radial cocktail** | Sheath needs the wire as a rail; side port only after the wire is out |
| 3 Guidewire | Hold **Advance wire** (W) / **Pull back** (S); the current vessel is named live | Wire parks in the ascending aorta |
| 4 Catheter | Hold **Advance catheter** → **Remove guidewire** → advance to engage the left main | **The catheter can never pass the wire tip**; wire removal only at the aortic root |
| 5 Angiography | Choose projections and hold **Inject** (J) in two LCA views → **Engage RCA** → inject → **Re-engage LCA** | Injections shorter than about 1 s don't fill the artery |
| 6 Lesion | Inject, then **click the narrowing on the fluoroscopy image** → QCA overlay and internal close-up | Feedback if you click the wrong place |
| 7 Balloon | Hold **Advance coronary wire** (E) across the lesion → advance the balloon until the markers are centred (live distance in mm) → hold **Inflate** (I) to 6 atm or more until the waist disappears → **Deflate** (D) → pull back | Inflation only when centred; no moving while inflated; warning above 14 atm |
| 8 Stent | Advance the crimped stent and centre it → inflate to 11 atm or more (radial expansion, lumen opens) → deflate → pull the balloon back; the stent stays | Same checks as the balloon |
| 9 Final | Final injection (before/after) → **Remove wire & catheter** → **Sheath out · TR band** | Order enforced |

**Other controls**
* **Show me** plays a demonstration of the current step and marks it complete.
* **Redo step**, **Previous**, **Next** and **Restart**.
* Each step resets the C-arm projection to the one suggested for it. The **Auto** tab follows that suggestion.
* During balloon or stent inflation, the monitor shows a transient ST change (ischaemia).

### Layout direction
On computers with an Arabic system language, Godot mirrored the English interface: panels swapped sides and step names were cut off. The interface is now always left-to-right (`project.godot`, plus the Cath Lab UI).

## Testing done
* Headless parse check of every scene.
* Heart Lab render pass (Xvfb, Compatibility renderer): exploded view, physiology with blood flow, labels.
* **Cath Lab automated run.** The QA routine performed the whole procedure through the same functions the buttons use: click on the pulse, holds, injections, click on the lesion. It completed every task of every step, and captured 19 screenshots.
* **Not tested here:** the frame rate on the target 8 GB / Intel iGPU computer, and mouse use by a real student.

## References used for this update
* Cardiac-cycle valve timing and filling (passive filling, then atrial contraction; ejection only while the semilunar valves are open): OpenStax *Anatomy & Physiology*, "Cardiac Cycle" (LibreTexts 19.03).
* Simulator task design (wire, contrast, balloon tasks with safety metrics): published work on the VIST and VCSim3 interventional simulators.
