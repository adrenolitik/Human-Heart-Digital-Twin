# CardioCath 3D — Reference & Asset Inventory (Milestone 1)

Source folder: `the author's local reference folder` — 1 text brief, 1 PDF,
92 images in 5 folders, 10 videos. Every file was opened and reviewed (videos as 12-frame storyboards).

Legend — **Use**: `REF` visual/educational reference only · `FACT` factual source for content ·
`RECREATE` must be modelled/drawn by us · `NOT RELEVANT`.
Copyright: almost all images/videos are third-party (watermarks: Kenhub, AHA, Cleveland Clinic,
GE Healthcare, Adobe Stock, ginger.healthcare, YouTube channels). **None are embedded in the app.**

## 1. Documents

| File | Content | Stage / feature | Use |
|---|---|---|---|
| `مستند نصي جديد.txt` | The full CardioCath 3D project brief (same as the prompt) | All | Specification |
| `pcicard.pdf` (2 pp., PCIpedia reference card v2026, Cardionetworks Foundation) | CAG indications/contra-indications, radial vs femoral access, Judkins/Amplatz catheters, **coronary segment nomenclature 1–16** (RCA 1–4,16; LM 5; LAD 6–10; LCx 11–15), standard projections (LAO/RAO, cranial/caudal), FFR/iFR/IVUS/OCT, **conduction-system blood supply** (SA node: RCA ~60 % / LCx ~40 %; AV node: RCA ~90 %), right-heart pressures, ECG localisation of culprit artery, and 9 angiogram + line-drawing pairs (RCA, LCA, spider view) | Stage 1 coronary labels; Stage 2 conduction supply; Stage 3 access, catheters, projections, angiography visuals | FACT + REF (angiogram line drawings are ideal templates for the simulated angiography screen) |

## 2. `Cardiac photos` (53 images) → Stage 1 & Stage 2

| Images | Content | Feature | Use |
|---|---|---|---|
| 1, 12, 14, 15, 19, 20, 21, 22, 23, 41 (084933), 47 (085122) | Realistic external heart renders/illustrations (anterior/left views) | Stage 1 look-dev: myocardium colour, wet specular, epicardial fat in grooves, coronary/vein colours | REF |
| 13 | CT-angiography volume render of coronary tree | Coronary appearance | REF |
| 2, 17 (Cleveland Clinic), 25 (gross anatomy, anterior), 28, 082133 (anterior + posterior labelled), 8 (cardiac plexus) | Labelled external anatomy (aorta, SVC/IVC, auricles, RCA, LCA, LCx, LAD, great cardiac vein, coronary sinus) | Stage 1 labels, part names, relations | FACT/REF |
| 082152 (Kenhub-style RCA/LCA branches), 082230 (right/left coronary trees with LM, LAD, LCx, S1–S4, D1–D2, OM1–OM2, PDA, ramus), 082251 (labelled coronary branches incl. SA-node branch, conus, marginal, PDA) | Coronary branch anatomy | Stage 1 coronary branches; Stage 3 target segment | FACT/REF |
| 082103 (sectional anatomy), 082209, 082317 (four-chamber cross-section with blood-flow legend), 4, 18, 24, 084951, 085007, 085022, 085049 (valves labelled), 085107 | Internal anatomy: chambers, valves, chordae, papillary muscles, septa | Stage 1 internal view, valve animation, blood flow | REF |
| 085007 | Pulmonary & systemic circuit diagram | Stage 1 circulation | FACT/REF |
| 083012, 083056, 083137, 083156, 083216, 084210, 085221, 085251, 085308 | Conduction system (SA, AV, His, bundle branches, Purkinje), depolarisation sequence vs ECG, normal ECG intervals, action-potential phases | **Stage 2** conduction overlay & ECG module | FACT/REF |
| 083035, 083118 | Research figures: activation/repolarisation maps, body-surface potential maps, simulated transmembrane potentials | Stage 2 visual inspiration (colour-mapped activation) | REF |
| 085235, 085323 | Ventricular action potential, ionic currents; SEM of an isolated cardiomyocyte | Stage 1 biology (cardiomyocyte), Stage 2 | FACT/REF |
| 3, 5, 6, 7, 9, 26, 10 | Stylised "hero" images (heart in chest, glowing, X-ray), stent-in-artery illustration (10) | UI mood, Stage 3 stent look | REF |
| 11 (AHA) | Aortic root region close-up | Great vessels | REF |

## 3. `Angiography Screen` (15 images) → Stage 3

| Images | Content | Use |
|---|---|---|
| 12, 7 | Real coronary angiograms (LCA, RCA) with acquisition overlays | REF for the simulated X-ray look (grey, grain, vignetting, contrast-filled vessels) |
| 1, 11, 13, images, 8, 15, 3, 5, 6, 14, 2, 9 | Cath-lab monitor banks showing angiography + haemodynamic monitor side-by-side | REF for the Stage 3 display layout (angio screen + monitor) |
| 10 | 3D CT heart renders on a workstation | REF |

## 4. `Catheter & Instruments` (8 images) → Stage 3 — ⚠ mostly not cardiac

| Images | Content | Use |
|---|---|---|
| 082851 (balloon + stent in artery), 082922 (balloon catheter) | PCI balloon / stent | REF for balloon & stent models |
| 1, 2 ("Catheterization tray setup"), 3, 4, images | **Urinary** catheterisation kits, metal urethral catheters/sounds | NOT RELEVANT to coronary catheterisation |
| 11 | Historical surgical instruments engraving | NOT RELEVANT |

**Missing:** introducer sheath, 0.035″ guidewire, Judkins left/right diagnostic catheters, guiding catheter,
0.014″ coronary guidewire, contrast manifold/syringe, inflation device (indeflator), radial band.

## 5. `Patient & Table` (11 images) → Stage 3

| Images | Content | Use |
|---|---|---|
| 11, 12 | Cath-lab rooms with C-arm, patient table, ceiling monitors | REF (room layout, simple C-arm) |
| 13, 14 | Scrubbed staff opening a sterile table / back-table instruments | REF (back table) |
| 1, 2, 4, 5, 6, 7, images | General **examination couches** | Limited — a cath-lab table is a long radiolucent carbon-fibre tabletop on a pedestal, not a couch |

## 6. `Patient Monitor Screen` (7 images) → Stage 3 (also Stage 2 ECG styling)

Multi-parameter monitors (ECG, SpO₂ pleth, respiration, NIBP, temperature): colour conventions
(green ECG, cyan/blue SpO₂, yellow resp, red/white NIBP). **Use:** REF for the educational monitor UI.

## 7. Videos (10) — storyboards reviewed

| Video | Content | Stage | Use |
|---|---|---|---|
| Cardiac Catheterization – 3D Animation (80 s) | Arterial tree, femoral puncture, guidewire/catheter advance via iliac → aorta → coronary, fluoroscopy | 3 | REF for catheter route and camera framing |
| قسطرة القلب التشخيصية (60 s, Arabic) | Real cath lab, sheath/manifold on sterile field, radial access, fluoroscopy | 3 | REF |
| قسطرة القلب القسطرة القلبية (38 s, Arabic) | Plaque, femoral access, catheter in aortic root, balloon inflation, stent expansion | 3 | REF for balloon/stent sequence |
| Coronary angiography video (21 s) | Real LCA & RCA cine angiograms in multiple projections | 3 | REF for contrast filling / wash-out timing |
| Cardiac conduction system in 3D (81 s) | Myocytes → coronary surface → SA/AV/His/bundle branches/Purkinje glowing in a cut heart | 1 (biology) & 2 | REF (glow style, sequence) |
| Conduction System Explained (11 s) | Labelled conduction system with ECG strip | 2 | REF |
| Heart Valves in 3D (17 s) | Base view of the four valves opening/closing | 1 | REF for valve animation |
| How Blood Flows Through Your Heart (10 s) | Labelled flow diagram (blue/red arrows) | 1 | REF |
| How Does the Human Heart Pump Blood (10 s) | Rotating heart, flow arrows in cut heart, coronary highlight | 1 | REF |
| How Your Organs Keep You Alive (10 s) | Cut heart with RBCs flowing, chambers/valves labelled | 1 | REF |

## 8. External resources found and used

| Resource | Why | Licence |
|---|---|---|
| **BodyParts3D** (DBCLS) STL meshes via GitHub mirror `Kevin-Mattheus-Moerman/BodyParts3D` | Only free, MRI-derived, anatomically segmented heart dataset found that is licensable: separate valves, papillary muscles, great vessels, **individual coronary arteries and cardiac veins**, hollow myocardium with real chamber cavities | CC BY-SA 2.1 JP |
| Inter typeface | UI font | SIL OFL 1.1 |
| Godot 4.3 meshoptimizer (built-in) | Mesh decimation | MIT |

Rejected: commercial heart models (CGTrader, RenderHub, TurboSquid…) — licences forbid redistribution
in an app without purchase; generic Sketchfab models — mostly single-mesh, not anatomically segmented.

Candidate open sources for Stage 1 histology (need your approval, see report):
OpenStax *Anatomy & Physiology 2e* Fig. 10.22 / 19.17 (cardiac muscle micrograph with intercalated
discs; CC BY 4.0); Cell Image Library cardiac-muscle EM images (licence varies per image — to verify).

## 9. Gaps, limitations and conflicts

1. **No aortic valve** in BodyParts3D → reconstructed (illustrative) three-cusp valve, clearly flagged.
2. **No separate chamber meshes** in BodyParts3D (one hollow "wall of heart") → chambers and septa are
   regions segmented by our pipeline; boundaries at the AV junction are approximate.
3. **Diagonal / obtuse-marginal branches** are part of the LAD / LCx meshes (not separate objects).
4. **No conduction-system meshes** (SA/AV node, His, bundle branches, Purkinje) → will be modelled in
   Milestone 4 as an overlay on the same heart, guided by references 083012/085221/085308.
5. **No histology micrographs** supplied (only one SEM of a cardiomyocyte) → Stage 1 biology needs
   approved, licensed micrographs or clearly-labelled illustrative 3D.
6. **Stage 3 instrument folder is mostly urinary catheterisation** — cardiac instruments must be
   recreated from PCI references (PCIpedia card, video frames).
7. **No 12-lead ECG example recordings** supplied → Stage 2 waveforms will be synthetic and labelled
   "simulated".
8. Some reference images are stylised/AI-generated (glowing hearts) — used for mood only, never for
   anatomical facts.

## 10. References added in Update 2
| File | Content | Use |
|---|---|---|
| 3 images (labelled anterior heart; cut-open heart with valves/chordae; realistic anterior heart with pulmonary tree) | look-dev and internal anatomy | REF |
| Sheep-heart dissection video (Arabic, 44 s) | real colours; long-axis opening of the LV | REF |
| Cardiomyocyte 3D animation (VOKA, 17 s) | tissue → cell → organelles | REF (3D tissue module) |
| Coronary plaque / CABG video (10 s) | LAD plaque, bypass graft | REF (occlusion marker) |
| University of Michigan Histology Laboratory Manual (306 pp., CC BY-NC-SA 4.0) | muscle chapter pp. 46–55, cardiovascular pp. 142–155 | FACT + 5 micrographs used in the app with attribution |


## Update 3 references (folder `بقية الفيديوهات`, 34 images)

| Images | Content | Used for |
|---|---|---|
| 20261112_214117 … 214402 (11 photos of atlas plates, Netter-style) | Base and posterior surfaces, pericardium, coronary arteries and veins, opened right atrium/ventricle, valves from the base (diastole/systole), sections through LA/LV, conduction system | Atlas colour style (red arteries, blue/purple veins and pulmonary arteries, yellow fat in the grooves), position of epicardial fat in the AV and interventricular grooves, valve colours |
| Screenshot 214506 (interactivebiology), 214703–214841 (3D renders / models) | Photorealistic and stylised 3D hearts, sectioned hearts, valve views | Realistic colour style: crimson myocardium, cream-yellow fat, pale great vessels, light pink cut surfaces |
| Screenshot 214846 | Sectional anatomy diagram with flow arrows | Reference for a future blood-flow overlay |
| Screenshot 214907 | Photograph of a dissected heart | Specimen colour style (pinkish-tan, matte) |

All of these are third-party copyrighted images used only as visual references; none are shipped in
the application. Colours were measured from them (k-means of tissue pixels) and re-created in the
project's own materials.


## Update 4 references (3 videos attached in chat)

| Video | Content | Used for |
|---|---|---|
| Cardiac conduction system explained (short, 11 s) | Realistic 3D heart, glowing yellow conduction paths, Purkinje wave | Conduction glow halo, impulse colour |
| Cardiac conduction system in 3D (81 s) | Labelled SA/AV node, His, bundle branches, Purkinje fibres with ECG strip | Check of conduction anatomy and ECG link |
| How your organs keep you alive (short, 10 s) | Photoreal heart on grey background, four-chamber section with flow arrows, coronary glow | "Lifelike" colour style, marbling, trabeculae, Clinical grey background; blood-flow arrows noted for a future update |

Frames were extracted locally for colour measurement only; no video frames are shipped.
