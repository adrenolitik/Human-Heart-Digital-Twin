# Update 4 — vessel fixes, shorter text, state reset, realism from the videos

Version 0.3.2

## 1. Floating vessels fixed (`tools/asset_pipeline/build_final.py`, `heart.glb`)
* **Floating pieces removed.** Any piece of a structure that touches neither the rest of that structure nor any other structure (gap > 2.5 mm) is now removed. This took out the two floating pulmonary-artery branch stubs (the "T" and the loose rods in your screenshots) and 2,170 triangles of internal debris.
* **Pulmonary bifurcation closed.** The bifurcation had an open hole, so the vessel looked hollow from above. It now has a domed cap.
* **Open vessel ends look like cut vessels.** When no cutaway is active, the inside surface of a tube is shaded as a darker lumen. Before, the inner surface was drawn as a flat pale cap, which made the vessels look transparent.

## 2. Short text, details on request
* Heart Lab selection panel:
  * three key points (**Where / Does / Clinical**);
  * **More details** opens the full description (structure, relations, FMA id).
* Heart Lab Diseases panel: 3–4 key points per condition plus two "in the 3D heart" points; the full text is under **More details**.
* Cardiac-cycle phases: 2–3 bullet points per phase.
* Tissue Lab: bullet points per level; the full sentence is in the tooltip.
* EP Lab:
  * rhythm key points, with ECG criteria, mechanism and clinical notes under **More details**;
  * structure and wave cards cut to 3 bullets (When / What / ECG and Normal / Meaning / 3D);
  * shorter subtitles and help lines.

## 3. Normal heart restored when switching
* **Switching tabs in the Heart Lab** (Explore, Dissect, Physiology, Diseases, Quiz) restores the normal heart and shows a short "Normal heart restored" notice. This undoes:
  * removed or hidden structures and isolation;
  * cuts and the exploded view;
  * the disease;
  * heart rate, speed and motion.
* **Changing stage** (Heart Lab, Tissue Lab, EP Lab, dashboard) resets every shared value through `HeartModel.reset_global_state()`, called by `SceneRouter`:
  * cutaway, motion and disease values;
  * the EP overlay;
  * calcified valve material.

  Each lab therefore opens with a normal heart at its default rate.

## 4. Realism from the three videos
Frames were extracted with ffmpeg and colours measured from the realistic 3D heart.
* **New default colour style "Lifelike":**
  * muted brick-red myocardium with lighter marbling;
  * bright raised red coronary arteries and blue-purple cardiac veins;
  * grey-purple venae cavae and pulmonary trunk;
  * subtle epicardial fat.
* **Trabeculae carneae** on the inner wall of the ventricles (apical two-thirds), visible in the Dissect cuts.
* **Marbling** added to all styles through a new tileable noise texture (`noise_fbm.png`), which also makes the fat lobules irregular.
* **Conduction system glow:** a soft additive halo around the travelling impulse, like the yellow glowing pathways in the animations.
* **New "Clinical grey" background** (light grey, as in the animation), in Appearance.

The videos are third-party material. They were used only as a visual reference and are not included in the application.

## 5. UI (ui-ux-pro-max rules — fallback)
The skill's search database is not installed here, so its built-in priority rules were applied:
* **Progressive disclosure:** key points first, **More details** on demand.
* **Feedback:** a toast confirms state changes.
* **Contrast:** low-contrast meta text raised to #7E8BA3.
* **Text size:** no text below 12 px.

## Test
1. Heart Lab: cut the heart and remove parts in Dissect, then switch to Physiology. The heart is whole again and a notice appears.
2. In Physiology, raise the heart rate, then go to Diseases. The rate is back to 72.
3. Rotate the heart to the top and the left side. No floating vessels, and no hollow pulmonary trunk.
4. Use Appearance to compare Lifelike, Realistic, Atlas and Specimen.
5. Use Dissect → Four-chamber to see the trabeculae.
6. In the EP Lab, set speed to 0.1× and watch the glowing impulse.
