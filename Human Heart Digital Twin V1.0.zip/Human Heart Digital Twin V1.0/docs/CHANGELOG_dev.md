# CardioCath 3D

Interactive Virtual Cardiac Anatomy, Physiology, Electrophysiology & Catheterization Simulator —
an **educational** application (not a clinical device) built with Godot 4.3+ (Compatibility renderer).

## Current version: 0.6.1 — light clinical theme

* New interface colours: white is the primary colour and green the secondary one. Every text colour meets the
  WCAG AA contrast minimum. The default 3D backdrop is now "Clinical mint". Medical screens (ECG,
  fluoroscopy) stay dark. Details: `docs/12_Update7_Light_Theme.md`.

### 0.6.0 — blood flow, vessel fixes, interactive radial PCI

* Stage 1: animated **blood flow** in the Physiology tab; cardiac-tissue module removed; open vessel ends
  closed; exploded view keeps the aorta, pulmonary arteries, coronary arteries and cardiac veins whole.
* Stage 3: starts directly at the radial puncture; only the forearm, the arteries and the heart are shown;
  **you perform every action** (puncture, wires, sheath, catheter, contrast, balloon, stent, TR band)
  with a task checklist and safety checks. Details: `docs/11_Update6_Blood_Flow_Interactive_PCI.md`.

### 0.5.0 — Stage 3 v2: realistic radial PCI

* Partial patient from BodyParts3D (skin, thorax and arm bones, arteries) lying supine with the right
  arm on an arm board; sterile drape, cap, ECG leads, pulse oximeter, oxygen cannula.
* **External → Semi-transparent → Internal** views; **Start procedure** reveals the anatomy.
* 10 replayable steps of right transradial PCI with LCA and RCA angiography, lesion QCA, balloon waist,
  stent deployment and TR band; camera selection (Room, Access, Anatomy, Internal, Monitor).
* Details: `docs/09_Stage3_v2_Realistic_Radial_PCI.md`; references: `docs/10_Research_Radial_PCI_References.md`.

### 0.4.0 — Stage 3 Cath Lab (Milestone 5)

**Cath Lab** (Dashboard → Stage 3 → *Open Cath Lab*):
* Simplified cath-lab room with a C-arm, monitors and an instrument tray, and a patient containing the same beating heart.
* Eight guided steps: preparation (radial or femoral) → insertion → navigation → contrast →
  angiography → balloon → stent → before/after result.
* Simulated angiography that stays in sync with the 3D scene, a patient monitor with transient ischaemia
  during balloon inflation, and highlighted instruments with one-line explanations.
* Details: `docs/08_Milestone5_Stage3_Report.md`.

### 0.3.2 — vessel fixes, short text, state reset, lifelike look

* Floating vessel fragments removed; pulmonary bifurcation closed; open vessel ends shaded as lumens.
* Panels show 2–4 key points; **More details** opens the full text.
* Switching Heart Lab tabs or changing stage restores the normal heart (parts, cuts, disease, rate).
* New default **Lifelike** colour style (from the supplied animation videos), trabeculae carneae,
  marbling, glowing conduction impulse, *Clinical grey* background. Details: `docs/07_Update4_Fixes_Clarity_Realism.md`.

### 0.3.1 — realism & interface update

* Three heart colour styles matched to the supplied references — **Realistic** (default), **Atlas**
  (atlas colour-coding) and **Specimen** — chosen from the dashboard or *Appearance* in any lab (saved).
* Epicardial fat baked along the AV and interventricular grooves; neutral, warmer lighting; radial
  studio backdrop (navy / slate / light); focus mode (**F**) hides the side panels; colour key in Explore.
* Details: `docs/06_Update3_Realism_UI.md`.

### 0.3.0 — Stage 2 electrophysiology & ECG (Milestone 4)

**EP Lab** (Dashboard → Stage 2 → *Open EP Lab*, or *EP Lab* in the Heart Lab top bar) — built on the
same 3D heart:
* **Conduction** – SA node, internodal pathways, Bachmann's bundle, AV node, His bundle, left bundle
  branch with fascicles, right bundle branch (moderator band) and Purkinje network; the impulse glows
  through them in order, active structures light up in the sequence list; myocardium as tissue,
  depolarisation wavefront or isochrone (activation-time) map; see-through walls, translucent heart,
  four-chamber cut, 3D labels.
* **ECG waves** – annotated sweep (P, PR, QRS, ST, T, RR with PR/QT brackets), the component under the
  cursor is highlighted together with the matching 3D event; live PR, QRS, QT, QTc, RR.
* **12-lead** – paper-style 3 × 4 + rhythm strip (25 mm/s, 10 mm/mV), lead groups by wall, click a lead
  to see its axis in 3D with the heart-vector arrow, its loop and projection; frontal QRS axis.
* **Rhythms** – NSR, sinus bradycardia, sinus tachycardia, atrial fibrillation, PVCs (isolated /
  trigeminy / bigeminy) and ventricular tachycardia, heart-rate slider within each rhythm's range,
  live RR intervals and regularity.
* Every signal is labelled **SIMULATED · EDUCATIONAL · NOT DIAGNOSTIC**.

### Earlier: 0.2.0 — Stage 1 interactive heart

**Heart Lab** (Dashboard → Stage 1 → *Open Heart Lab*)
* **Explore** – 36 selectable structures (chambers, septa, valves, papillary muscles, great vessels,
  coronary arteries, cardiac veins) with location, structure, function, relations and clinical relevance;
  show/hide, isolate, 3D labels.
* **Dissect** – four-chamber, long-axis (LVOT), short-axis, valve-plane, coronal, sagittal, transverse
  and "cut along my view" sections with depth/tilt; scalpel (click to remove, undo); quick dissection
  steps; exploded view.
* **Physiology** – beating heart (atria then ventricles, long-axis shortening, aortic valve opening),
  heart rate 40–180 bpm, slow motion, cycle phases with valve states, simulated ECG (lead II / V2) and
  illustrative vital signs (HR, BP, SV, EF, CO).
* **Diseases** – anterior STEMI (LAD), inferior STEMI (RCA), hypertrophic cardiomyopathy, dilated
  cardiomyopathy, aortic stenosis, atrial fibrillation, complete AV block, ventricular fibrillation —
  each with 3D changes, ECG, vital signs, severity slider and recommended view.
* **Quiz** – identify 10 structures by clicking.

**Blood flow** (Heart Lab → Physiology): blood cells stream through the venae cavae and pulmonary veins,
collect in the atria, pour through the open AV valves and are ejected through the aortic and pulmonary
valves — driven by the same valve timing as the ECG and wall motion (oxygen-poor blue, oxygen-rich red).

## Run
Godot 4.3+ → Import `project.godot` → F5. Keyboard: Space = play/pause, Ctrl+Z = undo removal, Esc = clear;
in the EP Lab 1–4 switch modes and R restarts; in the Cath Lab W/S advance or pull back, J inject, I inflate, D deflate, E coronary wire, N/P next/previous.

## Docs
`docs/09_Stage3_v2_Realistic_Radial_PCI.md` (latest) · `docs/08_Milestone5_Stage3_Report.md` · `docs/05_Milestone4_Stage2_Report.md` · `docs/04_Update2_Report.md` · `docs/02_Architecture.md` ·
`docs/01_Reference_Inventory.md` · `ASSET_LICENSES.md` (BodyParts3D CC BY-SA 2.1 JP; Michigan
micrographs CC BY-NC-SA 4.0 → non-commercial use).
