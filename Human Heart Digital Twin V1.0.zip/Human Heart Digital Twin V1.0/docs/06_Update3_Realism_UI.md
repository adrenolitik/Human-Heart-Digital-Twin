# Update 3 — heart realism and interface colours

Version 0.3.1. This update is based on the 34 reference images in `بقية الفيديوهات`: atlas plates, 3D renders and a dissection photograph.

## What changed

### More realistic heart
* **Three colour styles.** Colours were measured from the references (k-means on the tissue pixels) and rebuilt in the project's materials (`data/anatomy/tissue_styles.json`):
  * **Realistic** (default): crimson myocardium, cream-yellow epicardial fat, pale great vessels, light-pink cut surfaces. Matched to the photorealistic 3D references.
  * **Atlas**: colour-coded like the atlas plates. Red aorta and arteries, blue venae cavae and cardiac veins, purple pulmonary trunk, bright yellow fat, white valves.
  * **Specimen**: the pinkish-tan, matte look of a dissected heart.
* **Epicardial fat follows the real grooves.** Fat is now baked into the GLB along:
  * the atrioventricular groove (around the RCA, LCX and coronary sinus);
  * the anterior and posterior interventricular grooves (LAD, PDA).

  These grooves are located from the chamber-weight boundaries, so small diagonal branches no longer spread fat over the whole wall. A low-frequency noise turns the edges into irregular lobules. The geometry is unchanged; only the fat channel of the GLB was re-baked (`tools/asset_pipeline/build_final.py`).
* **Neutral, warmer lighting.** The blue sky ambient and blue fill light were giving the red tissue a purple tint; both are now neutral.

### Interface
* **Appearance menu** in the top bar of the Heart Lab and the EP Lab: heart colour style and background (studio navy, neutral slate or light atlas).
* The choice is **saved** and applies to every scene, including the dashboard preview. The dashboard also has its own "Heart colours" selector.
* **Radial studio backdrop** behind the 3D view. It is a single camera-facing quad; the canvas background mode was avoided because it breaks depth sorting in the Compatibility renderer.
* **Focus mode** (button or **F**) hides the side panels with a fade, so the heart fills the screen. The camera re-centres automatically.
* **Colour key** in Heart Lab → Explore. It shows what each colour means in the active style (myocardium, fat, coronary arteries and veins, aorta, pulmonary trunk, venae cavae, valves). Colours always come with names.

## Files
* **New:**
  * `data/anatomy/tissue_styles.json`
  * `scripts/tools/style_shots.gd` and `scenes/tools/style_shots.tscn`: renders every style for QA
  * this report
* **Changed:**
  * Assets and pipeline: `assets/models/heart/heart.glb` (fat channel), `tools/asset_pipeline/build_final.py`
  * Shaders: `assets/shaders/tissue.gdshader` (lobular fat)
  * Shared scripts: `scripts/shared/studio_environment.gd` (lighting and backdrop), `scripts/shared/heart_model.gd` (`apply_style`)
  * Core: `scripts/core/app_state.gd` (style and backdrop settings, v0.3.1)
  * UI scripts: `scripts/ui/ui_kit.gd` (appearance menu, colour key), `scripts/ui/main_dashboard.gd`
  * Labs: `scripts/stage1/heart_lab.gd`, `scripts/stage2/ep_lab.gd`
  * Docs and credits: `docs/01_Reference_Inventory.md`, `data/credits.json`

## How to test
1. Open the project and look at the heart on the dashboard.
2. Change **Heart colours** at the bottom of the dashboard.
3. In the Heart Lab, open **Appearance** (sliders icon) and try each style and background. Open Explore → *Colour key*.
4. Press **F** for focus mode, then **F** again to bring the panels back.
5. Dissect → Four-chamber: the cut surfaces are now light pink, like the sectioned references.

## Notes
* The reference images are copyrighted third-party material. They were used only to measure colours and judge the look; none of them are included in the application.
* The colour styles are artistic choices that follow the references. Colour in a real heart varies with age, fat content and fixation.
