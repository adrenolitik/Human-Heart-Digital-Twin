# Milestone 4 — Stage 2: Electrophysiology & ECG (report)

Version 0.3.0 · Godot 4.3 Compatibility renderer · status: **implemented, awaiting your review**
(Stage 3 is still locked until you approve this milestone).

## 1. What was built

### EP Lab (`scenes/stage2/ep_lab.tscn`)
The lab uses **the same HeartModel and CardiacEngine** as Stage 1. Nothing about the heart was replaced.
The conduction system, wavefront and ECG were added on top of it.

| Mode | What the student sees and does |
|---|---|
| **Conduction** | SA node → internodal pathways and Bachmann's bundle → AV node (slow) → His bundle → left bundle branch (anterior, posterior and septal fascicles) and right bundle branch (moderator band) → Purkinje network. The impulse glows along each structure at its own activation time. The *Sequence* list lights up the structures that are active at that moment. Clicking a structure highlights it in 3D, dims the others, focuses the camera and explains its anatomy, timing and ECG meaning. A live status line describes the current step (e.g. "AV-node delay — PR segment"). |
| **ECG waves** | Annotated monitor sweep with P, QRS, ST and T bands and PR/QT/RR brackets in milliseconds. The band under the cursor is outlined, and the matching row in the *Components* list lights up together with the 3D event (atrial wavefront, ventricular wavefront, depolarised plateau, repolarisation). Clicking a band or a row opens its explanation and normal values. Live PR, QRS, QT, QTc (Bazett), RR and HR are shown. |
| **12-lead** | Paper-style ECG: 3 × 4 layout (2.5 s per column) plus a 10 s lead II rhythm strip, 25 mm/s and 10 mm/mV, 1 mm / 5 mm grid, calibration pulses. *Show lead groups* tints the inferior, lateral, septal and anterior leads and aVR. Clicking a lead shows its electrodes, axis and viewing wall. In 3D the lead axes appear around the heart (limb leads or chest leads), with the **heart-vector arrow**, its 0.5 s loop and its projection on the selected lead (green = positive, red = negative). The frontal QRS axis is computed and classified. *Freeze* stops the paper for study. |
| **Rhythms** | NSR (60–100), sinus bradycardia (40–59), sinus tachycardia (101–180), AF (mean ventricular rate 60–180), PVCs (base rate 50–110; isolated / trigeminy / bigeminy) and VT (110–180). Each rhythm has a card with ECG criteria, mechanism, what to look for and clinical notes. The last RR intervals are listed with their spread and a regular / irregular verdict. |

Shared controls: rhythm picker, heart-rate slider limited to each rhythm's range, play/pause, restart,
speed 1× / 0.5× / 0.25× / 0.1×. The myocardium can be shown as tissue, as a depolarisation wavefront
(bright front plus blue depolarised tint until repolarisation) or as an isochrone map (red = earliest →
violet = latest, with a colour legend). Other toggles: conduction system, see-through walls, translucent
heart, four-chamber cut, heart vector and lead axes, and 3D labels.

### How the simulation stays consistent
* **One clock.** `CardiacEngine` schedules P waves and QRS onsets for every rhythm. Every frame it
  writes the electrophysiology state to global shader uniforms (`heart_ep`, `heart_ep2`): time since
  SA firing, time relative to QRS onset, AV-node progress, AF and ectopic flags, and action-potential
  duration. The tubes, the myocardial wavefront, the contraction, the ECG and the UI all read this
  same state.
* **One heart vector.** The 12 leads are projections of a single moving dipole onto the standard lead
  axes:
  * P wave: right-atrial component, then left-atrial component.
  * QRS: septal (left → right) → main (leftward / inferior / posterior) → terminal (basal).
  * T wave, plus an ST "injury" vector where a condition needs one.
  * Because all leads come from one vector, Einthoven's law (II = I + III) holds, R-wave progression
    appears from V1 to V6, and aVR is negative.
  * Ectopic beats (PVC/VT) take their vector from the focus position toward the ventricular mass.
    This gives an inferior-axis, V1-negative PVC from the RVOT and a basal LV VT with positive
    precordial concordance.
* **Stage 1 diseases now have 12-lead patterns too:**
  * anterior STEMI: ST elevation V1–V4, anterior Q, hyperacute T
  * inferior STEMI: ST elevation II, III, aVF with reciprocal changes in I/aVL, inferior Q
  * HCM: high voltage, deep septal Q, lateral T inversion
  * aortic stenosis: LVH with strain
  * DCM and complete heart block: wide QRS
* **Timing.** The values below are typical teaching values. They are labelled as approximate in the
  app.
  * PR = 0.16·√(RR/0.8) s
  * AV-node delay ≈ 70 ms
  * HV ≈ 34 ms
  * QRS ≈ 88 ms; the ventricular activation map spans ≈ 30–93 ms
  * QT = 0.40·√RR s
  * AF baseline 5–7 Hz

### UI/UX upgrade (ui-ux-pro-max + ui-styling rules)
The ui-ux-pro-max search database is not installed in this environment (only its SKILL.md). The
changes follow its built-in priority rules, applied as general defaults rather than database matches:
* SVG icons (Lucide, ISC licence) replace every text glyph. Before, the UI used ← ♥ ✂ ❚❚ ▶ ✔ ✘ ▾ ‹ ›
  as icons.
* Icon-only buttons carry tooltips as accessible names.
* Controls have hit targets of at least 40 px and keep visible focus styles.
* **Segmented tabs** (shadcn-style) for the modes in Heart Lab, Tissue Lab and EP Lab.
* New theme variations: `SegmentButton`, `GhostButton` and `ListButton`, plus icon tint colours per
  state, all taken from the palette tokens.
* No text smaller than 12 px. Every 10–11 px label was raised.
* Charts and legends never rely on colour alone. Wave bands carry text labels, lead groups have named
  legends, and the isochrone bar is labelled "Earliest / Latest".
* A mandatory **SIMULATED · EDUCATIONAL · NOT DIAGNOSTIC** badge appears in the EP Lab, on the ECG
  strip and on the 12-lead paper.
* **Camera framing.** `OrbitCamera.frame_rect` shifts the projection so the heart is centred in the
  area the panels leave free. Panels no longer hide the heart in either lab.
* The dashboard unlocks Stage 2 and shows icons, Ghost/Primary buttons and a new version chip. The Heart
  Lab top bar has an *EP Lab* shortcut.

## 2. Files

**New**
* `scenes/stage2/ep_lab.tscn`
* `scripts/stage2/`: `ep_lab.gd`, `conduction_system.gd`, `ecg_recorder.gd`, `ecg_strip.gd`,
  `twelve_lead_view.gd`, `lead_axes_3d.gd`
* `scripts/ui/ui_kit.gd`
* `scripts/tools/ecg_check.gd`: headless check of 12-lead amplitudes and ECG segments
* `assets/shaders/conduction.gdshader`, `conduction_xray.gdshader`, `conduction_body.gdshaderinc`
* `assets/ui/icons/*.svg` (43 Lucide icons) and `LUCIDE-LICENSE.txt`
* `data/electro/conduction.json`, `rhythms.json`, `ep_content.json`
* `tools/asset_pipeline/build_conduction.py`, `glbread.py`
* `docs/05_Milestone4_Stage2_Report.md` and `docs/screenshots/stage2_*.png`

**Modified**
* `project.godot`: 11 new shader globals (`heart_ep*`)
* `assets/shaders/heart_common.gdshaderinc`: activation field and isochrone colours
* `assets/shaders/tissue.gdshader`: wavefront / isochrone overlay
* `scripts/shared/cardiac_engine.gd`:
  * vector 12-lead ECG
  * pvc and vt rhythms
  * EP clock and EP state
  * intervals, segment lookup, extra rhythm files
* `scripts/shared/heart_model.gd`: resets the EP uniforms
* `scripts/shared/orbit_camera.gd`: `frame_rect`
* `data/physiology/conditions.json`: ECG parameters converted to vector form
* `scripts/stage1/heart_lab.gd`, `scripts/stage1/tissue_lab.gd`, `scripts/ui/main_dashboard.gd`,
  `scripts/ui/ecg_monitor.gd`: UI kit and icons
* `scripts/tools/build_theme.gd` and `assets/ui/theme.tres`
* `scripts/core/app_state.gd`: v0.3.0, Stage 2 unlocked
* `ASSET_LICENSES.md`, `data/credits.json`, `README.md`, `docs/02_Architecture.md`

## 3. How to run and test
1. Open `project.godot` in Godot 4.3+ (first import takes a minute), then press F5.
2. On the dashboard, open **Stage 2 → Open EP Lab**.
3. **Conduction**
   1. Set the speed to **0.1×**.
   2. Watch the SA node, the atrial paths, the long AV-node pause, the His bundle, the bundle branches
      and the Purkinje network.
   3. Turn on *Labels*. Click rows in *Sequence* to highlight structures.
   4. Switch *Myocardium* to **Isochrones**, then turn on the four-chamber cut.
4. **ECG waves**
   1. Pause with Space when the QRS band is outlined.
   2. Compare the ECG strip with the 3D heart (ventricular wavefront).
   3. Click the T band to read about it.
5. **12-lead**
   1. Wait about 10 s for the paper to fill.
   2. Click aVR and V1–V6. The axis lights up in 3D.
   3. Turn on *Show lead groups*. Switch between *Limb leads* and *Chest leads*.
6. **Rhythms**
   1. Try each rhythm and move the heart-rate slider.
   2. PVC: choose *Bigeminy* and check that the RR list alternates short/long.
   3. AF: check that the spread is large and the verdict is "irregular".
7. **Stage 1 diseases on 12 leads:** run `godot --headless --path . -s res://scripts/tools/ecg_check.gd`.
   It prints per-lead extrema for the rhythms and for the STEMI and HCM conditions.
8. Developer screenshots: `godot --path . res://scenes/stage2/ep_lab.tscn -- --qa-shots=<folder>`.

## 4. Known limitations
* **Schematic conduction system.**
  * The tracts are generated from landmarks on this model, not traced from histology.
  * The internodal pathways are drawn schematically; their existence as discrete tracts is debated.
  * The atrial paths lie on the atrial wall surface.
* **Simplified wavefront.** Activation time uses straight-line distance from breakthrough sites at a
  uniform velocity. There is no anisotropy, no transmural gradient and no real re-entry; AF and VF are
  stylised.
* **Single dipole.** The ECG uses one heart vector. Real precordial proximity effects are only
  approximated by per-lead gains, and V2–V4 amplitudes are lower than in many real tracings. This
  model **is not a validated ECG generator** and must not be used diagnostically.
* **Approximate haemodynamics.** VT and PVC haemodynamic values are illustrative.
* **No ECG examples from you.** No ECG example files were among the references you supplied. The
  waveforms follow standard textbook morphology and should be reviewed by a cardiology teacher.
* **Performance not yet measured on target hardware.** Frame rate was not measured on the target
  Intel iGPU, because screenshots here use software rendering. In headless mode the scripts take only a
  few milliseconds per frame, and the added geometry is about 14 k vertices of tubes.

## 5. Next (Milestone 5, after your approval)
Stage 3 cath lab: procedure table, torso and access site, catheter path, angiography screen, monitor
with the Stage 2 ECG, and eight procedural steps.
