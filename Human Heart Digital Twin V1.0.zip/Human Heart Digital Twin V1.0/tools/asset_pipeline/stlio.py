import numpy as np, struct
def load_stl(p):
    with open(p,'rb') as f:
        data=f.read()
    if data[:5]==b'solid' and b'facet' in data[:300]:
        tris=[]
        for line in data.decode(errors='ignore').splitlines():
            line=line.strip()
            if line.startswith('vertex'): tris.append([float(x) for x in line.split()[1:4]])
        v=np.array(tris,dtype=np.float32).reshape(-1,3,3)
    else:
        n=struct.unpack('<I',data[80:84])[0]
        dt=np.dtype([('n','<f4',3),('v','<f4',(3,3)),('a','<u2')])
        v=np.frombuffer(data,dtype=dt,count=n,offset=84)['v'].copy()
    return v
