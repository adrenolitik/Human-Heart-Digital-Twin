"""Read the final heart.glb back into numpy (positions, normals, uv0, uv1, color, indices) per mesh."""
import json, struct, numpy as np
def read(path):
    f=open(path,'rb').read(); jl=struct.unpack('<I',f[12:16])[0]; js=json.loads(f[20:20+jl]); b=f[20+jl+8:]
    def acc(i):
        a=js['accessors'][i]; bv=js['bufferViews'][a['bufferView']]
        n={'VEC2':2,'VEC3':3,'VEC4':4,'SCALAR':1}[a['type']]
        dt={5126:np.float32,5125:np.uint32,5123:np.uint16,5121:np.uint8}[a['componentType']]
        stride=bv.get('byteStride')
        cnt=a['count']*n
        arr=np.frombuffer(b,dt,cnt,bv['byteOffset']).reshape(a['count'],n).astype(np.float64)
        if a.get('normalized'): arr/= {np.uint16:65535.0,np.uint8:255.0}[dt]
        return arr
    out={}
    for m in js['meshes']:
        at=m['primitives'][0]['attributes']
        d={'P':acc(at['POSITION']),'N':acc(at['NORMAL']),'I':acc(m['primitives'][0]['indices']).astype(int).reshape(-1,3)}
        for k,kk in (('TEXCOORD_0','UV0'),('TEXCOORD_1','UV1'),('COLOR_0','C')):
            if k in at: d[kk]=acc(at[k])
        out[m['name']]=d
    return out
