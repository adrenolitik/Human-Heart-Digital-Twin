import sys; sys.path.insert(0,'/home/claude/tools')
from stlio import load_stl
import numpy as np, scipy.ndimage as ndi
S='/home/claude/dl/bp3d/assets/BodyParts3D_data/stl/'
def tri_points(v, step=0.4):
    # sample points densely on triangles (barycentric grid by triangle size)
    a,b,c=v[:,0],v[:,1],v[:,2]
    L=np.maximum(np.linalg.norm(b-a,axis=1),np.linalg.norm(c-a,axis=1))
    pts=[v.reshape(-1,3)]
    n=np.clip(np.ceil(L/step).astype(int),1,20)
    for k in np.unique(n):
        m=n==k
        if k<=1: continue
        g=np.array([(i/k,j/k) for i in range(k+1) for j in range(k+1-i)])
        P=a[m,None,:]+g[None,:,0,None]*(b[m]-a[m])[:,None,:]+g[None,:,1,None]*(c[m]-a[m])[:,None,:]
        pts.append(P.reshape(-1,3))
    return np.concatenate(pts)
def voxelize(vs, lo, res, shape):
    g=np.zeros(shape,bool)
    for v in vs:
        p=tri_points(v); idx=np.floor((p-lo)/res).astype(int)
        ok=np.all((idx>=0)&(idx<np.array(shape)),axis=1); idx=idx[ok]
        g[idx[:,0],idx[:,1],idx[:,2]]=True
    return g
