"""Minimal glTF 2.0 binary writer (positions, normals, indices, optional morph targets)."""
import json, struct, numpy as np
def write_glb(path, parts, materials, copyright_=''):
    """parts: list of dict(id, group, P, N, I, targets=[dict(name,dP,dN)]); materials: list of dict(name,color,rough,double)"""
    mnames=[m['name'] for m in materials]; bin_=bytearray(); bviews=[]; accs=[]; meshes=[]; nodes=[]
    def push(arr,target):
        nonlocal bin_
        while len(bin_)%4: bin_+=b'\0'
        off=len(bin_); b=np.ascontiguousarray(arr).tobytes(); bin_+=b
        bv={'buffer':0,'byteOffset':off,'byteLength':len(b)}
        if target: bv['target']=target
        bviews.append(bv); return len(bviews)-1
    def acc(arr,ctype,typ,target,minmax=False):
        a={'bufferView':push(arr,target),'componentType':ctype,'count':len(arr) if typ!='SCALAR' else arr.size,'type':typ}
        if target==34962 and arr.ndim==2 and arr.itemsize*arr.shape[1]%4: bviews[-1]['byteStride']=4
        if minmax: a['min']=arr.min(0).tolist(); a['max']=arr.max(0).tolist()
        accs.append(a); return len(accs)-1
    for p in parts:
        P=p['P'].astype(np.float32); N=p['N'].astype(np.float32); I=p['I'].astype(np.uint32).reshape(-1)
        if len(P) < 65535:
            idx_acc=acc(I.astype(np.uint16),5123,'SCALAR',34963)
        else:
            idx_acc=acc(I,5125,'SCALAR',34963)
        prim={'attributes':{'POSITION':acc(P,5126,'VEC3',34962,True),'NORMAL':acc(N,5126,'VEC3',34962)},
              'indices':idx_acc,'material':mnames.index(p['group'])}
        if p.get('UV0') is not None:
            prim['attributes']['TEXCOORD_0']=acc(np.round(np.clip(p['UV0'],0,1)*65535).astype(np.uint16),5123,'VEC2',34962); accs[-1]['normalized']=True
        if p.get('UV1') is not None:
            prim['attributes']['TEXCOORD_1']=acc(np.round(np.clip(p['UV1'],0,1)*65535).astype(np.uint16),5123,'VEC2',34962); accs[-1]['normalized']=True
        if p.get('C') is not None:
            prim['attributes']['COLOR_0']=acc(np.round(np.clip(p['C'],0,1)*255).astype(np.uint8),5121,'VEC4',34962); accs[-1]['normalized']=True
        mesh={'name':p['id'],'primitives':[prim]}
        if p.get('targets'):
            prim['targets']=[{'POSITION':acc(t['dP'].astype(np.float32),5126,'VEC3',34962,True),'NORMAL':acc(t['dN'].astype(np.float32),5126,'VEC3',34962)} for t in p['targets']]
            mesh['weights']=[0.0]*len(p['targets']); mesh['extras']={'targetNames':[t['name'] for t in p['targets']]}
        meshes.append(mesh); nodes.append({'name':p['id'],'mesh':len(meshes)-1,'extras':{'group':p['group']}})
    mats=[{'name':m['name'],'pbrMetallicRoughness':{'baseColorFactor':m['color'],'metallicFactor':0.0,'roughnessFactor':m['rough']},'doubleSided':m.get('double',False)} for m in materials]
    gl={'asset':{'version':'2.0','generator':'CardioCath3D asset pipeline','copyright':copyright_},
        'scene':0,'scenes':[{'nodes':[len(nodes)]}],'nodes':nodes+[{'name':'Heart','children':list(range(len(nodes)))}],
        'meshes':meshes,'materials':mats,'accessors':accs,'bufferViews':bviews,'buffers':[{'byteLength':len(bin_)}]}
    js=json.dumps(gl,separators=(',',':')).encode(); js+=b' '*((4-len(js)%4)%4)
    while len(bin_)%4: bin_+=b'\0'
    with open(path,'wb') as f:
        f.write(struct.pack('<III',0x46546C67,2,12+8+len(js)+8+len(bin_)))
        f.write(struct.pack('<II',len(js),0x4E4F534A)); f.write(js)
        f.write(struct.pack('<II',len(bin_),0x004E4942)); f.write(bin_)
def smooth_normals(P,I):
    a,b,c=P[I[:,0]],P[I[:,1]],P[I[:,2]]; fn=np.cross(b-a,c-a); N=np.zeros_like(P,dtype=np.float64)
    for k in range(3): np.add.at(N,I[:,k],fn)
    return (N/np.maximum(np.linalg.norm(N,axis=1,keepdims=True),1e-12)).astype(np.float32)
