"""Stage 3 of the pipeline: assemble decimated parts into the final optimized GLB.
Per-vertex data written for the runtime shaders:
  COLOR_0  r = 1 - epicardial fat   g = ambient occlusion   b = LAD territory   a = RCA territory
  TEXCOORD_0 = (w_RA, w_LA)   TEXCOORD_1 = (w_RV, w_LV)   chamber-proximity weights for the beat / remodeling
All weights are functions of position only, so touching parts (e.g. a coronary artery on the wall) deform identically."""
import json, pickle, numpy as np, scipy.ndimage as ndi
from scipy.spatial import cKDTree
from glb import write_glb, smooth_normals
raw={p['id']:p for p in pickle.load(open('parts_raw.pkl','rb'))}
idx=json.load(open('dec_in/index.json'))
center=np.array(json.load(open('center.json'))['center_mm_bp3d'])
vox=np.load('vox.npz'); lo=vox['lo']; res=float(vox['res'])
seg=np.load('seg.npz'); lab=seg['lab']; names=list(seg['names'])
solid=np.load('cav.npz')['solid']

def to_bp(P):   # godot metres -> BodyParts3D mm
    return center+np.stack([P[:,0]*1000,-P[:,2]*1000,P[:,1]*1000],1)
def to_gd(B):
    q=(B-center)/1000.0; return np.stack([q[...,0],q[...,2],-q[...,1]],-1)
def sample(grid,B,outside_add=True):
    f=(B-lo)/res; i=np.clip(np.round(f).astype(int),0,np.array(grid.shape)-1)
    v=grid[i[:,0],i[:,1],i[:,2]].astype(np.float64)
    if outside_add:
        c=np.clip(f,0,np.array(grid.shape)-1); v=v+np.linalg.norm((f-c)*res,axis=1)
    return v

# --- load decimated parts
parts=[]
for e in idx:
    pid=e['id']; r=raw[pid]
    if r.get('targets'): p=dict(r)
    else:
        P=np.fromfile(f'dec_out/{pid}.pos','<f4').reshape(-1,3); N=np.fromfile(f'dec_out/{pid}.nrm','<f4').reshape(-1,3)
        I=np.fromfile(f'dec_out/{pid}.idx','<u4').reshape(-1,3)
        used=np.unique(I); remap=np.full(len(P),-1,np.int64); remap[used]=np.arange(len(used))
        p=dict(id=pid,group=r['group'],P=P[used],N=N[used],I=remap[I].astype(np.uint32))
    parts.append(p)
by={p['id']:p for p in parts}

# --- Update 4: drop floating fragments. A connected component is removed when it touches neither the
# rest of its own part nor any other part (gap > FLOAT_GAP): e.g. detached pulmonary-artery branch stubs.
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
FLOAT_GAP=0.0025
removed_log=[]
for p in parts:
    if p.get('targets'): continue
    P,I=p['P'],p['I'].astype(np.int64)
    q=np.round(P/1e-5).astype(np.int64); _,inv=np.unique(q,axis=0,return_inverse=True); inv=inv.ravel()
    T=inv[I]; n=inv.max()+1
    r=np.r_[T[:,0],T[:,1],T[:,2]]; c=np.r_[T[:,1],T[:,2],T[:,0]]
    nc,lab_=connected_components(coo_matrix((np.ones(len(r)),(r,c)),shape=(n,n)),directed=False)
    if nc<=1: continue
    tl=lab_[T[:,0]]; sizes=np.bincount(tl,minlength=nc); main=int(np.argmax(sizes))
    others=cKDTree(np.concatenate([o['P'] for o in parts if o is not p]))
    keep=np.ones(len(I),bool)
    kept_tree=cKDTree(P[np.unique(I[tl==main])])
    for ci in range(nc):
        if ci==main or sizes[ci]==0: continue
        vi=np.unique(I[tl==ci])
        if others.query(P[vi])[0].min()>FLOAT_GAP and kept_tree.query(P[vi])[0].min()>FLOAT_GAP:
            keep[tl==ci]=False; removed_log.append((p['id'],int(sizes[ci])))
    if not keep.all():
        I2=I[keep]; used=np.unique(I2); remap=np.full(len(P),-1,np.int64); remap[used]=np.arange(len(used))
        p['P']=P[used]; p['N']=p['N'][used]; p['I']=remap[I2].astype(np.uint32)
print('floating fragments removed:',removed_log)

# --- Update 4: close the opening at the pulmonary bifurcation (the trunk-to-branch junction was open in
# the source mesh, so the vessel looked hollow from above). Domed cap with outward-facing triangles.
from loops import boundary_loops
def cap_loop(p, loop):
    P=p['P']; Q=P[loop].astype(np.float64); c=Q.mean(0)
    u,s_,vt=np.linalg.svd(Q-c); n=vt[2]
    near=P[np.linalg.norm(P-c,axis=1)<0.03].mean(0)
    if np.dot(n,c-near)<0: n=-n
    rad=np.linalg.norm(Q-c,axis=1).mean()
    ring=(Q*0.5+c*0.5)+n*rad*0.18; top=c+n*rad*0.24
    base=len(P); m=len(Q)
    newP=np.concatenate([ring,top[None]]).astype(np.float32)
    tris=[]
    for i in range(m):
        j=(i+1)%m; a,b=loop[i],loop[j]; ra,rb=base+i,base+j
        tris+= [[a,b,rb],[a,rb,ra]]
        tris.append([ra,rb,base+m])
    tris=np.array(tris,np.int64)
    # orient: triangle normals should point along +n
    A,B,C=[np.concatenate([P,newP])[tris[:,k]] for k in range(3)]
    if np.dot(np.cross(B-A,C-A).sum(0),n)<0: tris=tris[:,[0,2,1]]
    p['P']=np.concatenate([P,newP]); p['N']=np.concatenate([p['N'],np.repeat(n[None].astype(np.float32),len(newP),0)])
    p['I']=np.concatenate([p['I'].reshape(-1,3).astype(np.int64),tris]).astype(np.uint32)
    return len(tris)
pa=by['pulmonary_arteries']
for lp in boundary_loops(pa['P'],pa['I']):
    c=pa['P'][lp].mean(0)
    if len(lp)>40 and -0.01<c[0]<0.03 and c[1]>0.05:
        print('capped pulmonary bifurcation opening:',cap_loop(pa,lp),'tris')

# --- Update 5: close every free vessel end. BodyParts3D vessels stop as open, often obliquely cut
# tubes (pulmonary veins looked like hollow "claws"; coronary twigs were open pipes). A boundary loop
# that is not a junction with another part (mean distance > 1.8 mm to every other part) gets a domed cap.
def cap_free_ends(p, others_tree):
    n=0
    for lp in boundary_loops(p['P'],p['I']):
        if len(lp)<3: continue
        Q=p['P'][lp]
        if others_tree is not None and others_tree.query(Q)[0].mean()<0.0018: continue
        n+=cap_loop(p,lp)
    return n
cap_log=[]
for p in parts:
    if p['group'] not in ('great_vessel','coronary_artery','cardiac_vein'): continue
    vessel_only=p['group'] in ('coronary_artery','cardiac_vein')   # coronaries lie ON the wall: only other vessels count as junctions
    ot=cKDTree(np.concatenate([o['P'] for o in parts if o is not p and (not vessel_only or o['group']==p['group'])]))
    k=cap_free_ends(p,ot)
    if k: cap_log.append((p['id'],k))
print('free vessel ends capped:',cap_log)

# --- chamber distance fields (mm) and centroids
dist={}; cent={}
for n in ('RA','LA','RV','LV'):
    m=lab==names.index(n)+1
    dist[n]=ndi.distance_transform_edt(~m)*res
    cent[n]=to_gd(np.argwhere(m).mean(0)*res+lo+res/2)
SIG=14.0
# --- ambient-occlusion density grid: myocardium solid + every part surface
occ=solid.astype(np.float32).copy()
for p in parts:
    B=to_bp(p['P']); f=np.round((B-lo)/res).astype(int); ok=np.all((f>=0)&(f<np.array(occ.shape)),1); f=f[ok]
    occ[f[:,0],f[:,1],f[:,2]]=1.0
occ=ndi.binary_dilation(occ>0,iterations=1).astype(np.float32)
dens=ndi.gaussian_filter(occ,4.0/res)
# --- territories
def pts(ids): return np.concatenate([by[i]['P'] for i in ids])
tLAD=cKDTree(pts(['lad','lad_septal','left_main'])); tRCA=cKDTree(pts(['rca','rca_pda','rca_posterolateral','rca_septal','rca_marginal'])); tLCX=cKDTree(pts(['lcx']))
# Epicardial fat (Update 3, from the atlas / specimen references): thick in the atrioventricular groove
# (RCA, LCX, coronary sinus, left main), thinner along the interventricular grooves (LAD, PDA, cardiac veins).
FAT_GROOVE=cKDTree(pts(['rca','left_main','lcx','coronary_sinus']))
FAT_IV=cKDTree(pts(['lad','rca_pda','great_cardiac_vein','middle_cardiac_vein','rca_marginal']))
FAT_PARTS={'right_atrium','left_atrium','right_ventricle','left_ventricle','aortic_root','pulmonary_trunk_root'}
WALL={'right_atrium','left_atrium','right_ventricle','left_ventricle','interventricular_septum','interatrial_septum','papillary_muscles_rv','papillary_muscles_lv','aortic_root','pulmonary_trunk_root'}
aos=[]
for p in parts:
    P=p['P']; N=p['N']; B=to_bp(P)
    w={n:np.exp(-(sample(dist[n],B)/SIG)**2) for n in dist}
    p['UV0']=np.stack([w['RA'],w['LA']],1).astype(np.float32); p['UV1']=np.stack([w['RV'],w['LV']],1).astype(np.float32)
    Bn=to_bp(P+N*0.0015); d=sample(dens,Bn,False)
    p['_occ']=d; aos.append(d)
    s=6.0/1000
    eL=np.exp(-tLAD.query(P)[0]/s); eR=np.exp(-tRCA.query(P)[0]/s); eC=np.exp(-tLCX.query(P)[0]/s)
    tot=eL+eR+eC+1e-30; vent=np.maximum(w['LV'],w['RV'])
    fat=np.zeros(len(P))
    if p['id'] in FAT_PARTS:
        def ss(x): x=np.clip(x,0,1); return x*x*(3-2*x)
        # grooves located from the chamber-weight boundaries (independent of small coronary branches):
        # AV groove = atrial weight ~ ventricular weight; interventricular grooves = LV weight ~ RV weight
        wa=np.maximum(w['RA'],w['LA']); wv=np.maximum(w['RV'],w['LV'])
        av=np.exp(-((wa-wv)/0.30)**2)*ss((wa+wv-0.35)/0.3)
        iv=np.exp(-((w["LV"]-w["RV"])/0.24)**2)*ss((wv-0.25)/0.25)*(1-ss((wa-0.3)/0.3))
        d1=FAT_GROOVE.query(P)[0]; d2=FAT_IV.query(P)[0]
        near=np.maximum(ss((0.0110-d1)/(0.0110-0.0030)), ss((0.0075-d2)/(0.0075-0.0020)))
        fat=np.clip(np.maximum(av*1.15,iv)*near,0,1)
    p['_lad']=(eL/tot)*np.clip(vent*1.4,0,1); p['_rca']=(eR/tot)*np.clip(vent*1.4,0,1); p['_fat']=fat
allocc=np.concatenate(aos); lo_q,hi_q=np.percentile(allocc,[40,96]); print('occ pct',lo_q,hi_q)
for p in parts:
    ao=1.0-np.clip((p['_occ']-lo_q)/(hi_q-lo_q),0,1)*0.75
    p['C']=np.stack([1-p['_fat'],ao,p['_lad'],p['_rca']],1).astype(np.float32)
MATS=[dict(name='chamber',color=[0.55,0.16,0.14,1],rough=0.55),dict(name='septum',color=[0.50,0.14,0.13,1],rough=0.55),
      dict(name='valve',color=[0.86,0.80,0.68,1],rough=0.45,double=True),dict(name='papillary',color=[0.62,0.20,0.18,1],rough=0.5),
      dict(name='great_vessel',color=[0.70,0.30,0.30,1],rough=0.45),dict(name='coronary_artery',color=[0.78,0.12,0.10,1],rough=0.35),
      dict(name='cardiac_vein',color=[0.30,0.27,0.55,1],rough=0.4)]
write_glb('heart.glb',parts,MATS,'Derived from BodyParts3D (c) 2008 Life Science Integrated Database Center, CC BY-SA 2.1 JP. Aortic valve reconstructed (illustrative).')

# --- landmarks for physiology, dissection presets, labels, disease markers
def cen(pid): P=by[pid]['P']; return (P.min(0)+P.max(0))/2
mitral=by['mitral_valve']['P'].mean(0); tric=by['tricuspid_valve']['P'].mean(0); aov=by['aortic_valve']['P'].mean(0); pulv=by['pulmonary_valve']['P'].mean(0)
LVP=by['left_ventricle']['P']; apex=LVP[np.argmax(np.linalg.norm(LVP-mitral,axis=1))]
base=(mitral+tric)/2
allP=np.concatenate([p['P'] for p in parts]); hc=(allP.min(0)+allP.max(0))/2
def along(pid,origin,dmin,dmax):
    P=by[pid]['P']; d=np.linalg.norm(P-origin,axis=1); m=(d>dmin)&(d<dmax); return P[m].mean(0)
lm=by['left_main']['P']; lm_origin=lm[np.argmin(np.linalg.norm(lm-aov,axis=1))]
rc=by['rca']['P']; rca_origin=rc[np.argmin(np.linalg.norm(rc-aov,axis=1))]
lad=by['lad']['P']; lad_origin=lad[np.argmin(np.linalg.norm(lad-lm_origin,axis=1))]
markers={'lad_proximal':along('lad',lad_origin,0.008,0.016).tolist(),'rca_proximal':along('rca',rca_origin,0.020,0.030).tolist()}
anchors={}
for p in parts:
    c=cen(p['id']); d=c-hc; n=np.linalg.norm(d)
    if n<0.012: anchors[p['id']]=c.tolist(); continue
    d/=n; P=p['P']; anchors[p['id']]=P[np.argmax(P@d)].tolist()
summary=[]; tot=0
for p in parts:
    lo_,hi_=p['P'].min(0),p['P'].max(0); tot+=len(p['I'])
    summary.append({'id':p['id'],'group':p['group'],'triangles':int(len(p['I'])),'vertices':int(len(p['P'])),'center_m':((lo_+hi_)/2).round(4).tolist(),'size_m':(hi_-lo_).round(4).tolist(),'reconstructed':bool(raw[p['id']].get('reconstructed',False)),'label_anchor':np.round(anchors[p['id']],5).tolist()})
phys={'chamber_centroids':{k:np.round(v,5).tolist() for k,v in cent.items()},'apex':apex.round(5).tolist(),'base':base.round(5).tolist(),
      'mitral_center':mitral.round(5).tolist(),'tricuspid_center':tric.round(5).tolist(),'aortic_valve_center':aov.round(5).tolist(),'pulmonary_valve_center':pulv.round(5).tolist(),
      'heart_center':hc.round(5).tolist(),'markers':{k:np.round(v,5).tolist() for k,v in markers.items()},'weight_sigma_mm':SIG}
json.dump({'total_triangles':tot,'physiology':phys,'parts':summary},open('heart_manifest.json','w'),indent=1)
print('total tris',tot,'parts',len(parts)); print(json.dumps(phys,indent=0)[:900])
