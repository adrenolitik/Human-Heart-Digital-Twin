"""Generate a schematic cardiac conduction system on the CardioCath heart (Godot space, metres).
Landmarks are derived from this model's own geometry; paths are snapped to the endocardial
(or atrial) surface. Output: data/electro/conduction.json (polylines with arrival times).
Times: class 0 = atrial (s after SA firing), class 1 = AV node (fraction 0..1 of the nodal delay),
class 2 = ventricular conduction (s relative to QRS onset; negative = before the QRS)."""
import json, numpy as np
from scipy.spatial import cKDTree
from glbread import read
rng=np.random.default_rng(3)
M=read('heart.glb'); phys=json.load(open('heart_manifest.json'))['physiology']
L=lambda k: np.array(phys[k]) if k in phys else np.array(phys['chamber_centroids'][k])
def pts(*ids): return np.concatenate([M[i]['P'] for i in ids])
def sel(ids, test):
    P=[];N=[]
    for i in ids:
        m=M[i]; k=test(m); P.append(m['P'][k]); N.append(m['N'][k])
    return np.concatenate(P), np.concatenate(N)
wRA=lambda m: m['UV0'][:,0]; wLA=lambda m: m['UV0'][:,1]; wRV=lambda m: m['UV1'][:,0]; wLV=lambda m: m['UV1'][:,1]
LVendo=sel(['left_ventricle','interventricular_septum','papillary_muscles_lv'], lambda m: wLV(m)>0.95)
RVendo=sel(['right_ventricle','interventricular_septum','papillary_muscles_rv'], lambda m: wRV(m)>0.95)
LVsept=sel(['interventricular_septum'], lambda m: (wLV(m)>0.95)&(wLV(m)>wRV(m)))
RVsept=sel(['interventricular_septum'], lambda m: (wRV(m)>0.95)&(wRV(m)>wLV(m)))
ATR=sel(['right_atrium','left_atrium','interatrial_septum'], lambda m: np.ones(len(m['P']),bool))
RAin=sel(['right_atrium','interatrial_septum'], lambda m: wRA(m)>0.9)
def snap(S, p, off=0.0006):
    P,N=S; t=cKDTree(P); d,i=t.query(p); return P[i]+N[i]*off
def path(S, way, step=0.0015, off=0.0006, smooth=2):
    way=[np.asarray(w) for w in way]; out=[]
    for a,b in zip(way[:-1],way[1:]):
        n=max(2,int(np.linalg.norm(b-a)/step))
        for s in np.linspace(0,1,n,endpoint=False): out.append(a+(b-a)*s)
    out.append(way[-1]); out=np.array(out)
    P,N=S; t=cKDTree(P); d,i=t.query(out); q=P[i]+N[i]*off
    for _ in range(smooth):
        q[1:-1]=(q[:-2]+q[1:-1]*2+q[2:])/4
    return q
def arclen(q): return np.concatenate([[0],np.cumsum(np.linalg.norm(np.diff(q,axis=0),axis=1))])

apex=L('apex'); base=L('base'); axis=(base-apex)/np.linalg.norm(base-apex)
# --- landmarks
svc=M['superior_vena_cava']['P']; ring=svc[svc[:,1]<np.percentile(svc[:,1],8)].mean(0)
RA=M['right_atrium']['P']; near=RA[np.linalg.norm(RA-ring,axis=1)<0.016]
SA=near[np.argmax(-near[:,0]+0.5*near[:,2])]
cs=M['coronary_sinus']['P']; cs_os=cs[np.argmin(np.linalg.norm(cs-L('RA'),axis=1))]
tv=M['tricuspid_valve']['P']; ivs_c=M['interventricular_septum']['P'].mean(0); tv_sept=tv[np.argmin(np.linalg.norm(tv-ivs_c,axis=1))]
AV=snap(RAin, 0.55*cs_os+0.45*tv_sept, 0.0)
aov=L('aortic_valve_center'); his_t=aov-axis*0.011
ivsP=M['interventricular_septum']['P']; BIF=ivsP[np.argmin(np.linalg.norm(ivsP-his_t,axis=1))]
ias=M['interatrial_septum']['P']
ias_ant=ias[np.argmax(ias[:,1]+ias[:,2])]; ias_post=ias[np.argmax(ias[:,1]-ias[:,2])]
LA=M['left_atrium']['P']; la_roof=LA[np.argmax(LA[:,1]+0.6*LA[:,2]+0.3*LA[:,0])]
ivc=M['inferior_vena_cava']['P']; ivc_top=ivc[ivc[:,1]>np.percentile(ivc[:,1],92)].mean(0)
crista=snap(ATR, ivc_top+np.array([-0.006,0.004,0.006]),0.0)
L_len=np.linalg.norm(base-apex)
def lvsep_at(f): return snap(LVsept, base-axis*L_len*f, 0.0)
def rvsep_at(f): return snap(RVsept, base-axis*L_len*f, 0.0)
# papillary clusters
def two_clusters(P):
    c=P[[np.argmax(P[:,2]),np.argmin(P[:,2])]]
    for _ in range(10):
        lab=np.argmin(np.linalg.norm(P[:,None]-c[None],axis=2),1); c=np.array([P[lab==k].mean(0) for k in range(2)])
    return c
plv=two_clusters(M['papillary_muscles_lv']['P']); al=plv[np.argmax(plv[:,2]+plv[:,0])]; pm=plv[np.argmin(plv[:,2]+plv[:,0])]
prv=two_clusters(M['papillary_muscles_rv']['P']); ant_rv=prv[np.argmax(prv[:,2])]
al_b=snap(LVendo,al,0.0); pm_b=snap(LVendo,pm,0.0); rv_pap=snap(RVendo,ant_rv,0.0)

polys=[]
def add(pid,cls,q,t,name):
    polys.append({"id":pid,"class":cls,"name":name,"points":np.round(q,5).tolist(),"t":np.round(t,5).tolist()})
# --- atrial preferential pathways (schematic) and Bachmann's bundle
V_ATR=1.7; V_BACH=2.0
for pid,way,name in [("internodal",[SA,ias_ant,AV],"Anterior internodal pathway"),("internodal",[SA,0.5*(SA+ias_post),ias_post,AV],"Middle internodal pathway"),("internodal",[SA,crista,AV],"Posterior internodal pathway (crista terminalis)")]:
    q=path(ATR,way,off=0.0005); add(pid,0,q,arclen(q)/V_ATR+0.004,name)
q=path(ATR,[SA,ias_ant,la_roof],off=0.0005); add("bachmann",0,q,arclen(q)/V_BACH+0.004,"Bachmann's bundle")
t_av_in=float(arclen(path(ATR,[SA,ias_ant,AV]))[-1]/V_ATR+0.004)
# --- AV node (short, slow)
avn=np.array([AV+(BIF-AV)*s*0.25 for s in np.linspace(0,1,8)]); add("av_node",1,avn,np.linspace(0,1,8),"AV node")
HIS0=avn[-1]
# --- His bundle (relative to QRS onset)
his=np.array([HIS0+(BIF-HIS0)*s for s in np.linspace(0,1,10)]); add("his",2,his,np.linspace(-0.056,-0.047,10),"Bundle of His")
V_BB=2.0; V_PK=3.0
def branch(pid,S,way,t0,v,name,off=0.0007):
    q=path(S,way,off=off); t=t0+arclen(q)/v; add(pid,2,q,t,name); return q,t
lbb,lt=branch("lbb",LVsept,[BIF,lvsep_at(0.18)],-0.047,V_BB,"Left bundle branch")
laf,laft=branch("laf",LVendo,[lbb[-1],lvsep_at(0.35)+(al_b-lvsep_at(0.35))*0.3,al_b],lt[-1],V_BB,"Left anterior fascicle")
lpf,lpft=branch("lpf",LVendo,[lbb[-1],lvsep_at(0.35)+(pm_b-lvsep_at(0.35))*0.3,pm_b],lt[-1],V_BB,"Left posterior fascicle")
lsf,lsft=branch("lsf",LVsept,[lbb[-1],lvsep_at(0.55)],lt[-1],V_BB,"Left septal fascicle")
rbb,rt=branch("rbb",RVsept,[BIF,rvsep_at(0.30),rvsep_at(0.55)],-0.047,V_BB,"Right bundle branch")
mod=np.array([rbb[-1]+(rv_pap-rbb[-1])*s for s in np.linspace(0,1,12)]); mt=rt[-1]+arclen(mod)/V_BB
add("rbb",2,mod,mt,"Moderator band (right bundle branch)")
# --- Purkinje networks: random geodesic-like walks on the endocardium
def purkinje(S,seeds,pid,name,n_walk=7,max_len=0.045,cav=None):
    P,N=S; tree=cKDTree(P); terms=[]
    nb=tree.query(P,k=10)[1]
    for (sp,st) in seeds:
        i0=tree.query(sp)[1]
        for w in range(n_walk):
            d=rng.normal(size=3); d-=N[i0]*np.dot(d,N[i0]); d/=np.linalg.norm(d)+1e-9
            d=0.6*d+0.4*(apex-P[i0])/np.linalg.norm(apex-P[i0]+1e-9)
            stack=[(i0,d,st,0.0,0)]
            while stack:
                i,dd,t,ln,depth=stack.pop(); q=[P[i]+N[i]*0.0006]; tt=[t]
                while ln<max_len*(0.7 if depth else 1.0):
                    cand=nb[i][1:]; v=P[cand]-P[i]; dl=np.linalg.norm(v,axis=1)+1e-9
                    score=(v@dd)/dl+rng.normal(0,0.35,len(cand))
                    j=cand[np.argmax(score)]
                    if np.linalg.norm(P[j]-P[i])<1e-6: break
                    step=np.linalg.norm(P[j]-P[i]); ln+=step; t+=step/V_PK
                    dd=0.75*dd+0.25*(P[j]-P[i])/step; dd-=N[j]*np.dot(dd,N[j]); dd/=np.linalg.norm(dd)+1e-9
                    i=j; q.append(P[i]+N[i]*0.0006); tt.append(t)
                    if depth<2 and rng.random()<0.06 and len(q)>4:
                        r=np.cross(dd,N[i]); stack.append((i,0.5*dd+0.8*r*rng.choice([-1,1]),t,0.0,depth+1))
                if len(q)>3:
                    q=np.array(q)
                    for _ in range(2): q[1:-1]=(q[:-2]+q[1:-1]*2+q[2:])/4
                    add(pid,2,q,np.array(tt),name); terms.append((q[-1],tt[-1]))
    return terms
lv_terms=purkinje(LVendo,[(laf[-1],laft[-1]),(lpf[-1],lpft[-1]),(lsf[-1],lsft[-1]),(lbb[-1],lt[-1])],"purkinje_lv","Purkinje fibres (LV)",n_walk=6)
rv_terms=purkinje(RVendo,[(mod[-1],mt[-1]),(rbb[-1],rt[-1])],"purkinje_rv","Purkinje fibres (RV)",n_walk=6)
# --- myocardial breakthrough sources (6) for the shader activation map
def nearest_term(terms,p):
    k=np.argmin([np.linalg.norm(a-p) for a,_ in terms]); return terms[k]
src=[(lsf[-1],lsft[-1]),(laf[-1],laft[-1]),(lpf[-1],lpft[-1]),nearest_term(lv_terms,apex),(mod[-1],mt[-1]),nearest_term(rv_terms,apex)]
pv=M['pulmonary_valve']['P'].mean(0); rvot=snap(RVendo, pv-axis*0.012, 0.0)
LVE=LVendo[0]; vt=LVE[np.argmax(LVE[:,0]-LVE[:,2]*0.6+ (LVE-apex)@axis*0.8)]
# shift so that the earliest myocardial breakthrough defines QRS onset (t = 0)
shift=-min(t for _,t in src)
for p in polys:
    if p['class']==2: p['t']=np.round(np.array(p['t'])+shift,5).tolist()
src=[(p,t+shift) for p,t in src]
# per-point deformation weights (nearest heart vertex): wRA,wLA,wRV,wLV,LAD,RCA
ALLP=np.concatenate([m['P'] for m in M.values()]); ALLW=np.concatenate([np.c_[m['UV0'],m['UV1'],m['C'][:,2:4]] for m in M.values()])
kt=cKDTree(ALLP)
for p in polys:
    d,i=kt.query(np.array(p['points'])); p['w']=np.round(ALLW[i],3).tolist()
out={"version":1,"note":"Schematic conduction system generated from this model's landmarks; positions are approximate. Times in seconds.",
 "landmarks":{k:np.round(v,5).tolist() for k,v in dict(sa_node=SA,av_node=AV,his_bifurcation=BIF,bachmann_end=la_roof,cs_ostium=cs_os).items()},
 "t_av_entry":round(t_av_in,4),
 "sources":{"atrial":[np.round(np.append(SA,0.0),5).tolist(),np.round(np.append(la_roof,float(arclen(path(ATR,[SA,ias_ant,la_roof]))[-1]/V_BACH)),5).tolist()],
   "ventricular":[np.round(np.append(p,t),5).tolist() for p,t in src],"his_start":round(-0.056+shift,4),
   "pvc_focus":np.round(rvot,5).tolist(),"vt_focus":np.round(vt,5).tolist()},
 "polylines":polys}
import os; os.makedirs('data/electro',exist_ok=True)
json.dump(out,open('data/electro/conduction.json','w'))
from collections import Counter
print(Counter(p['id'] for p in polys)); print('t_av_entry',t_av_in,'SA',SA.round(4),'AV',AV.round(4),'BIF',BIF.round(4))
print('vent src times',[round(t,4) for _,t in src]); print('size KB',os.path.getsize('data/electro/conduction.json')/1024)
