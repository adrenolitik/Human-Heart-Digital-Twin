"""Stage 1 blood flow: centrelines through the chambers, valves and great vessels of the heart model.
Output data/physiology/blood_paths.json (heart-model space, metres). Each path is a list of points with a
gate per point: 0 = always flowing (venous return), 1 = flows only while the AV valves are open (atrium ->
ventricle), 2 = flows only while the semilunar valves are open (ventricle -> great artery), 3 = great artery
(fast in systole, slow run-off in diastole), and a lumen
radius per point used to spread the particles across the vessel/chamber."""
import json, numpy as np
from glbread import read
from scipy.cluster.vq import kmeans2
M=read('heart.glb'); man=json.load(open('heart_manifest.json'))['physiology']
C=man['chamber_centroids']; RA,LA,RV,LV=[np.array(C[k]) for k in ('RA','LA','RV','LV')]
apex=np.array(man['apex']); mit=np.array(man['mitral_center']); tri=np.array(man['tricuspid_center'])
aov=np.array(man['aortic_valve_center']); pv=np.array(man['pulmonary_valve_center'])
# Needs data/cath/cath_paths.json from the Stage 3 build (not in this release); blood_paths.json is already built.
cath=json.load(open('data/cath/cath_paths.json'))
def centreline(P, toward, nb=10, trim=0.06):
    d=np.linalg.norm(P-toward,axis=1); lo,hi=np.percentile(d,trim*100),np.percentile(d,100-trim*100)
    edges=np.linspace(hi,lo,nb+1); out=[]
    for a,b in zip(edges[:-1],edges[1:]):
        m=(d<=a)&(d>b)
        if m.sum()>8: out.append(P[m].mean(0))
    return np.array(out)               # far -> near
def rad(P,line):
    return [float(np.median(np.sort(np.linalg.norm(P-q,axis=1))[:60])) for q in line]
paths=[]
def add(side, pts, gates, radii):
    paths.append({'side':side,'points':np.round(np.array(pts),5).tolist(),'gate':gates,'r':np.round(radii,4).tolist()})
# right heart: SVC / IVC -> RA -> tricuspid -> RV -> RVOT -> pulmonary valve -> trunk -> L/R pulmonary artery
svcP=M['superior_vena_cava']['P']; ivcP=M['inferior_vena_cava']['P']
paP=M['pulmonary_arteries']['P']; ptr=M['pulmonary_trunk_root']['P']
bif=paP[np.argmax(paP[:,1])] if False else paP[np.argsort(np.linalg.norm(paP-ptr.mean(0),axis=1))[:200]].mean(0)
rvot=(RV*0.4+pv*0.6); rv_low=RV+(apex-RV)*0.35
for side_x in (+1,-1):          # pulmonary artery branches: patient's left (+x) and right (-x)
    br=paP[(paP[:,0]-bif[0])*side_x>0.012]
    far=br[np.argmax(np.linalg.norm(br-bif,axis=1))]
    brl=centreline(br,bif,nb=6)[::-1]
    for vc,P in (('svc',svcP),('ivc',ivcP)):
        vl=centreline(P,RA,nb=6)
        pts=list(vl)+[RA,tri,RV,rv_low,rvot,pv,ptr.mean(0),bif]+list(brl)
        g=[0]*len(vl)+[0,1,1,1,2,2,3,3]+[3]*len(brl)          # RA | tricuspid, RV | RV low, RVOT, pulm. valve | trunk, bifurcation, branch
        r=rad(P,vl)+[0.012,0.007,0.012,0.010,0.008,0.006,0.007,0.007]+[0.005]*len(brl)
        add('right',pts,g,r)
# left heart: 4 pulmonary veins -> LA -> mitral -> LV -> LVOT -> aortic valve -> aorta (root..descending)
pvP=M['pulmonary_veins']['P']
far=pvP[np.linalg.norm(pvP-LA,axis=1)>np.percentile(np.linalg.norm(pvP-LA,axis=1),55)]
cent,lab=kmeans2(far,4,seed=3,minit='++')
ao=np.array(cath['aorta'])
ao_rad=0.010
lv_low=LV+(apex-LV)*0.35; lvot=LV*0.4+aov*0.6
for k in range(4):
    Q=pvP[np.linalg.norm(pvP-cent[k],axis=1)<0.03]
    vl=centreline(np.concatenate([Q]),LA,nb=5)
    pts=list(vl)+[LA,mit,LV,lv_low,lvot,aov]+list(ao[1::3])
    g=[0]*len(vl)+[0,1,1,1,2,2]+[3]*len(ao[1::3])          # LA | mitral, LV | LV low, LVOT, aortic valve | aorta
    r=[0.004]*len(vl)+[0.013,0.008,0.013,0.010,0.008,0.007]+[ao_rad]*len(ao[1::3])
    add('left',pts,g,r)
json.dump({'note':'Blood-flow centrelines (simplified, educational). Gates: 0 venous, 1 AV valves open, 2 semilunar valves open, 3 great artery run-off.','paths':paths},
          open('data/physiology/blood_paths.json','w'),separators=(',',':'))
for p in paths: print(p['side'],len(p['points']),np.round(p['points'][0],3),np.round(p['points'][-1],3))
