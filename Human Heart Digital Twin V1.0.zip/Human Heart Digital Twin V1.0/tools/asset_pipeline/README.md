# Heart asset pipeline (reproducible)

Builds `assets/models/heart/heart.glb` from BodyParts3D STL meshes. Python 3 + numpy, scipy,
scikit-image, Pillow; Godot 4.3+ for decimation (uses Godot's built-in meshoptimizer).

| Step | Script | What it does |
|---|---|---|
| 0 | (git) | `git clone --depth 1 --filter=blob:none --no-checkout https://github.com/Kevin-Mattheus-Moerman/BodyParts3D` then `git checkout HEAD -- assets/BodyParts3D_data/stl/<FMA ids>.stl` (ids listed in `build_raw.py`) |
| 1 | `vox.py` | Voxelises the BodyParts3D *wall of heart* (FMA7274) + valves at 1 mm; finds the myocardium volume |
| 2 | `seg.py` | Convex-hull cavity detection + seeded watershed → RA, RV, LA, LV, aortic-root and pulmonary-trunk lumens |
| 3 | `build_raw.py` | Labels every wall triangle by nearest lumen (septa = interior triangles close to both LV/RV or LA/RA), plane-clips the great vessels, keeps the main pulmonary vessels, generates the reconstructed aortic valve (+ `open` morph target), converts to Godot space (metres, +Y up, +Z anterior), welds vertices, writes `dec_in/` |
| 4 | `decimate.gd` | `godot --headless -s decimate.gd -- dec_in dec_out targets.json` → meshoptimizer LODs, picks the level nearest each target in `targets.json` |
| 5 | `build_final.py` | Assembles the final GLB (36 named nodes) with per-vertex COLOR_0 = (1−fat, AO, LAD territory, RCA territory), TEXCOORD_0 = (w_RA, w_LA), TEXCOORD_1 = (w_RV, w_LV); writes `heart_manifest.json` with landmarks, label anchors and occlusion sites |
| 6 | `textures.py` | Generates the tileable tissue textures (myocardium, vessel, valve, fat) |

Coordinate conversion: BodyParts3D mm (+x patient-left, −y anterior, +z superior) →
Godot metres: `(x, z, −y) × 0.001` after subtracting the wall centroid (see `center.json`).

Paths in the scripts point to the working folders used when the asset was built; edit the
`S=` / output paths at the top of each script before re-running on another machine.

> Note: these scripts were run on the original build machine and contain its absolute paths. Adjust the paths before re-running them. The built outputs (heart.glb and data/*.json) are already included.
