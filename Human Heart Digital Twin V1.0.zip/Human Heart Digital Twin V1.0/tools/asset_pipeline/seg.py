import numpy as np, scipy.ndimage as ndi
from skimage.segmentation import watershed
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
d=np.load('vox.npz'); lo=d['lo']; res=float(d['res']); V=d['V']
c=np.load('cav.npz'); cav=c['cav']; hull=c['hull']; solid=c['solid']
dt=ndi.distance_transform_edt(cav); dh=ndi.distance_transform_edt(hull)
seeds={'RV':(10,-150,1221),'LV':(39,-118,1236),'RA':(-18,-111,1239),'LA':(11,-87,1243),'AO':(11,-122,1274),'PT':(18,-145,1268)}
names=list(seeds)
mk=np.zeros(cav.shape,np.int32)
for i,n in enumerate(names):
    p=np.round((np.array(seeds[n])-lo)/res).astype(int)
    sl=tuple(slice(max(q-3,0),q+4) for q in p); mk[sl][cav[sl]]=i+1
OUT=len(names)+1
mk[(dh<=2.5)&cav]=OUT
lab=watershed(-dt,mk,mask=cav)
np.savez_compressed('seg.npz',lab=lab,names=np.array(names+['OUT']))
for i,n in enumerate(names+['OUT']): print(n, int((lab==i+1).sum()),'mL' )
cols=np.array([[1,1,1],[.2,.4,1],[1,.2,.2],[.4,.6,1],[1,.5,.5],[1,.8,0],[.5,.2,.8],[.85,.85,.85]])
fig,ax=plt.subplots(2,4,figsize=(20,10))
for k,z in enumerate([1195,1205,1215,1225,1235,1245,1260,1272]):
    zi=int((z-lo[2])/res); img=cols[lab[:,:,zi]]; img[solid[:,:,zi]]=[.3,0,0]; img[V[:,:,zi]]=[0,.7,0]
    a=ax.flat[k]; a.imshow(np.transpose(img,(1,0,2)),origin='lower',extent=[lo[0],lo[0]+lab.shape[0]*res,lo[1],lo[1]+lab.shape[1]*res]); a.set_title(f'z={z}')
plt.savefig('/home/claude/ref/seg.png',dpi=55)
