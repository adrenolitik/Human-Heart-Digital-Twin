extends SceneTree
# Decimates raw part meshes with Godot's built-in meshoptimizer (ImporterMesh.generate_lods).
# usage: godot --headless -s decimate.gd -- <in_dir> <out_dir> <targets.json>
func _init():
	var a := OS.get_cmdline_user_args()
	var ind: String = a[0]; var outd: String = a[1]
	var targets: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(a[2]))
	var index: Array = JSON.parse_string(FileAccess.get_file_as_string(ind + "/index.json"))
	DirAccess.make_dir_recursive_absolute(outd)
	var report := []
	for e in index:
		var id: String = e["id"]
		var pos := FileAccess.get_file_as_bytes(ind + "/" + id + ".pos").to_float32_array()
		var nrm := FileAccess.get_file_as_bytes(ind + "/" + id + ".nrm").to_float32_array()
		var idx := FileAccess.get_file_as_bytes(ind + "/" + id + ".idx").to_int32_array()
		var V := PackedVector3Array(); V.resize(pos.size() / 3)
		var N := PackedVector3Array(); N.resize(V.size())
		for i in V.size():
			V[i] = Vector3(pos[3*i], pos[3*i+1], pos[3*i+2]); N[i] = Vector3(nrm[3*i], nrm[3*i+1], nrm[3*i+2])
		var arr := []; arr.resize(Mesh.ARRAY_MAX)
		arr[Mesh.ARRAY_VERTEX] = V; arr[Mesh.ARRAY_NORMAL] = N; arr[Mesh.ARRAY_INDEX] = idx
		var im := ImporterMesh.new()
		im.add_surface(Mesh.PRIMITIVE_TRIANGLES, arr)
		var tgt: int = int(targets.get(id, e["tris"]))
		var out_idx := idx
		if tgt < e["tris"]:
			im.generate_lods(25.0, 60.0, [])
			var best := idx; var bestd := 1e18
			for l in im.get_surface_lod_count(0):
				var li := im.get_surface_lod_indices(0, l)
				var d: float = abs(li.size() / 3.0 - tgt)
				if d < bestd: bestd = d; best = li
			out_idx = best
		var sa := im.get_surface_arrays(0)
		var VV: PackedVector3Array = sa[Mesh.ARRAY_VERTEX]; var NN: PackedVector3Array = sa[Mesh.ARRAY_NORMAL]
		var fp := PackedFloat32Array(); fp.resize(VV.size()*3); var fn := PackedFloat32Array(); fn.resize(VV.size()*3)
		for i in VV.size():
			fp[3*i]=VV[i].x; fp[3*i+1]=VV[i].y; fp[3*i+2]=VV[i].z; fn[3*i]=NN[i].x; fn[3*i+1]=NN[i].y; fn[3*i+2]=NN[i].z
		var f := FileAccess.open(outd + "/" + id + ".pos", FileAccess.WRITE); f.store_buffer(fp.to_byte_array()); f.close()
		f = FileAccess.open(outd + "/" + id + ".nrm", FileAccess.WRITE); f.store_buffer(fn.to_byte_array()); f.close()
		f = FileAccess.open(outd + "/" + id + ".idx", FileAccess.WRITE); f.store_buffer(out_idx.to_byte_array()); f.close()
		report.append({"id": id, "in": e["tris"], "out": out_idx.size() / 3, "verts_in": V.size(), "verts_out": VV.size()})
		print(id, " ", e["tris"], " -> ", out_idx.size() / 3)
	var rf := FileAccess.open(outd + "/report.json", FileAccess.WRITE); rf.store_string(JSON.stringify(report, " ")); rf.close()
	quit()
