"""Procedural, tileable tissue textures (original work, no external images)."""
import numpy as np
from PIL import Image
rng=np.random.default_rng(7)
def periodic_noise(n,sx,sy,seed):
    r=np.random.default_rng(seed); w=r.standard_normal((n,n))
    fx=np.fft.fftfreq(n)[:,None]; fy=np.fft.fftfreq(n)[None,:]
    filt=np.exp(-((fx*sx)**2+(fy*sy)**2))
    h=np.real(np.fft.ifft2(np.fft.fft2(w)*filt)); h-=h.min(); return h/h.max()
def normal_from_height(h,strength):
    gx=(np.roll(h,-1,1)-np.roll(h,1,1))*strength; gy=(np.roll(h,-1,0)-np.roll(h,1,0))*strength
    n=np.stack([-gx,-gy,np.ones_like(h)],-1); n/=np.linalg.norm(n,axis=-1,keepdims=True)
    return ((n*0.5+0.5)*255).astype(np.uint8)
def save(a,name): Image.fromarray(a).save(f'tex/{name}.png')
N=512
# --- myocardium: fine muscle-fibre striations + soft lobular noise
fib=periodic_noise(N,10,70,1)          # elongated along one axis = fibres
lob=periodic_noise(N,40,40,2); fine=periodic_noise(N,180,180,3)
h=0.40*fib+0.40*lob+0.20*fine
save(normal_from_height(h,3.2),'myocardium_normal')
alb=0.80+0.20*(0.6*lob+0.4*fib); save((np.stack([alb,alb*0.96,alb*0.95],-1)*255).astype(np.uint8),'myocardium_albedo')
rough=0.50+0.25*(1-fine)*0.8+0.1*lob; save((np.clip(rough,0,1)*255).astype(np.uint8),'myocardium_roughness')
# --- vessel wall: smooth with faint longitudinal texture
v=0.6*periodic_noise(N,6,60,4)+0.4*periodic_noise(N,120,120,5)
save(normal_from_height(v,2.5),'vessel_normal')
# --- valve leaflet: fibrous, slightly translucent-looking variation
f=0.7*periodic_noise(N,12,90,6)+0.3*periodic_noise(N,150,150,7)
save(normal_from_height(f,3.0),'valve_normal')
a=0.85+0.15*f; save((np.stack([a,a*0.97,a*0.9],-1)*255).astype(np.uint8),'valve_albedo')
print('ok')

# --- epicardial fat: lobulated bumps
fat=0.7*periodic_noise(N,70,70,8)+0.3*periodic_noise(N,200,200,9)
save(normal_from_height(fat,5.0),'fat_normal')
print('fat ok')
