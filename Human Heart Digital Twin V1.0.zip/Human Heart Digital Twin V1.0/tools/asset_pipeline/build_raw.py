"""Build a segmented, named raw heart GLB from BodyParts3D STL meshes.
Coordinates: BodyParts3D (mm; +x patient-left, -y anterior, +z superior)
 -> Godot (m; +X patient-left, +Y superior, +Z anterior/toward viewer)."""
import sys, json, struct; sys.path.insert(0,'/home/claude/tools')
import numpy as np, scipy.ndimage as ndi
from scipy.spatial import cKDTree
from stlio import load_stl
S='/home/claude/dl/bp3d/assets/BodyParts3D_data/stl/'
vox=np.load('vox.npz'); lo=vox['lo']; res=float(vox['res'])
seg=np.load('seg.npz'); lab=seg['lab'].copy(); names=list(seg['names'])
cav=np.load('cav.npz'); solid=cav['solid']
AO=names.index('AO')+1; OUT=names.index('OUT')+1
zc=np.arange(lab.shape[2])*res+lo[2]
lab[(lab==AO)&(zc[None,None,:]<1249)]=OUT          # AO leak below root -> outside
xc=np.arange(lab.shape[0])*res+lo[0]; yc=np.arange(lab.shape[1])*res+lo[1]
rad=np.sqrt((xc[:,None,None]-13)**2+(yc[None,:,None]+121)**2)
lab[(lab==AO)&(rad>15.5)]=OUT                       # keep only the aortic-root lumen
PT=names.index('PT')+1
lab[(lab==PT)&(np.sqrt((xc[:,None,None]-25)**2+(yc[None,:,None]+143)**2)>14)]=OUT
hull=cav['hull']; ext=(~hull)|(lab==OUT)
dext=ndi.distance_transform_edt(~ext)*res
def vcoords(mask): return np.argwhere(mask)*res+lo+res/2
trees={n:cKDTree(vcoords(lab==i+1)) for i,n in enumerate(names) if n!='OUT'}

# ---------- wall labelling ----------
wall=load_stl(S+'FMA7274.stl'); cen=wall.mean(1)
D={n:t.query(cen,k=1)[0] for n,t in trees.items()}
keys=list(D); M=np.stack([D[k] for k in keys],1)
best=np.argmin(M,1); wl=np.array(keys)[best]
ci=np.clip(np.floor((cen-lo)/res).astype(int),0,np.array(dext.shape)-1)
interior=dext[ci[:,0],ci[:,1],ci[:,2]]>3.0
srt=np.sort(M,1)
def both(a,b,th): return (D[a]<th)&(D[b]<th)
wl=np.where(both('LV','RV',13.0)&interior&np.isin(wl,['LV','RV']),'IVS',wl)
wl=np.where(both('LA','RA',8.0)&interior&np.isin(wl,['LA','RA']),'IAS',wl)
for k in np.unique(wl): print('wall',k,(wl==k).sum())

# ---------- helpers ----------
def clip_plane(v,n,d):
    n=np.asarray(n,float); s_=v@n-d; ins=s_>=0; cnt=ins.sum(1); out=[v[cnt==3]]
    def lerp(a,b,sa,sb): t=(sa/(sa-sb))[:,None]; return a+(b-a)*t
    for k,want in ((1,True),(2,False)):
        m=cnt==k; T=v[m]; Sv=s_[m]; I=ins[m]
        if not len(T): continue
        idx=np.argmax(I==want,1)   # the lone vertex
        r=np.arange(len(T)); a=T[r,idx]; b=T[r,(idx+1)%3]; c=T[r,(idx+2)%3]
        sa=Sv[r,idx]; sb=Sv[r,(idx+1)%3]; sc=Sv[r,(idx+2)%3]
        ab=lerp(a,b,sa,sb); ac=lerp(a,c,sa,sc)
        if want: out.append(np.stack([a,ab,ac],1))
        else: out.append(np.stack([ab,b,c],1)); out.append(np.stack([ab,c,ac],1))
    return np.concatenate(out).astype(np.float32)
def clip(v,keep_fn):
    k=keep_fn(v[:,0])&keep_fn(v[:,1])&keep_fn(v[:,2]); return v[k]
def dist_to(n,c): return trees[n].query(c)[0]
parts=[]  # (id, group, name, tris)
def add(pid,group,v): 
    if len(v): parts.append((pid,group,v))
L=lambda f: load_stl(S+f+'.stl')
wall_map={'RA':'right_atrium','LA':'left_atrium','RV':'right_ventricle','LV':'left_ventricle',
          'IVS':'interventricular_septum','IAS':'interatrial_septum','AO':'aortic_root','PT':'pulmonary_trunk_root'}
for k,pid in wall_map.items(): add(pid,'chamber' if k in('RA','LA','RV','LV') else ('septum' if 'sept' in pid else 'great_vessel'),wall[wl==k])
add('tricuspid_valve','valve',L('FMA7234')); add('mitral_valve','valve',L('FMA7235')); add('pulmonary_valve','valve',L('FMA7246'))
add('papillary_muscles_rv','papillary',np.concatenate([L('FMA7260'),L('FMA7261'),L('FMA7262')]))
add('papillary_muscles_lv','papillary',np.concatenate([L('FMA7266'),L('FMA9352nsn')]))
add('superior_vena_cava','great_vessel',L('FMA4720'))
add('inferior_vena_cava','great_vessel',clip_plane(L('FMA10951'),[0,0,1],1176))
add('ascending_aorta','great_vessel',L('FMA3736'))
add('aortic_arch','great_vessel',L('FMA3768'))
add('descending_aorta','great_vessel',clip_plane(L('FMA3784'),[0,0,1],1198))
arch_br=np.concatenate([clip_plane(L('FMA3932nsn'),[0,0,-1],-1350),clip_plane(L('FMA4058'),[0,0,-1],-1350),clip_plane(clip_plane(L('FMA4694'),[0,0,-1],-1350),[-1,0,0],-45)])
add('aortic_arch_branches','great_vessel',arch_br)
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
def keep_big(v,min_tris=250):
    p=v.reshape(-1,3); q=np.round(p/1e-3).astype(np.int64); u,inv=np.unique(q,axis=0,return_inverse=True); I=inv.reshape(-1,3)
    r=np.concatenate([I[:,0],I[:,1],I[:,2]]); c=np.concatenate([I[:,1],I[:,2],I[:,0]])
    n,lab_=connected_components(coo_matrix((np.ones(len(r)),(r,c)),shape=(len(u),len(u))),directed=False)
    tl=lab_[I[:,0]]; cnt=np.bincount(tl,minlength=n); return v[cnt[tl]>=min_tris]
def box(v,xmin,xmax,zmax=None,ymax=None):
    v=clip_plane(clip_plane(v,[1,0,0],xmin),[-1,0,0],-xmax)
    if zmax is not None: v=clip_plane(v,[0,0,-1],-zmax)
    if ymax is not None: v=clip_plane(v,[0,-1,0],-ymax)
    return v
pa=box(L('FMA66326'),-30,62,zmax=1300)
add('pulmonary_arteries','great_vessel',keep_big(clip(pa,lambda c:(dist_to('PT',c)<60)|(c[:,2]>1262))))
pv=box(L('FMA66643'),-34,66)
add('pulmonary_veins','great_vessel',keep_big(clip(pv,lambda c:dist_to('LA',c)<34)))
for pid,f in [('rca','FMA3802'),('rca_marginal','FMA3818'),('rca_pda','FMA3840nsn'),('rca_posterolateral','FMA76994'),('rca_septal','FMA71669'),
              ('left_main','FMA4685'),('lad','FMA3862nsn'),('lcx','FMA3895'),('lad_septal','FMA71670')]:
    add(pid,'coronary_artery',L(f))
for pid,f in [('coronary_sinus','FMA4706'),('great_cardiac_vein','FMA4707'),('middle_cardiac_vein','FMA4713'),('anterior_cardiac_veins','FMA71567'),('posterior_lv_veins','FMA76751')]:
    add(pid,'cardiac_vein',L(f))

# ---------- transform ----------
center=wall.reshape(-1,3).mean(0)
def tf(v): 
    p=(v-center)/1000.0
    return np.stack([p[...,0],p[...,2],-p[...,1]],-1).astype(np.float32)
def weld(v):
    p=v.reshape(-1,3); q=np.round(p/2e-6).astype(np.int64)
    u,inv=np.unique(q,axis=0,return_inverse=True); inv=inv.reshape(-1)
    P=np.zeros((len(u),3),np.float64); np.add.at(P,inv,p); cnt=np.bincount(inv); P/=cnt[:,None]
    I=inv.reshape(-1,3); I=I[(I[:,0]!=I[:,1])&(I[:,1]!=I[:,2])&(I[:,0]!=I[:,2])]
    a,b,c=P[I[:,0]],P[I[:,1]],P[I[:,2]]; fn=np.cross(b-a,c-a)
    N=np.zeros_like(P); 
    for k in range(3): np.add.at(N,I[:,k],fn)
    N/=np.maximum(np.linalg.norm(N,axis=1,keepdims=True),1e-12)
    return P.astype(np.float32),N.astype(np.float32),I.astype(np.uint32)


# ---------- aortic valve (reconstructed: not present in BodyParts3D) ----------
def aortic_valve():
    c=np.array([17.5,-119.3,1249.5]); n=np.array([-0.50,-0.12,0.86]); n/=np.linalg.norm(n)
    R=10.4; depth=7.5
    u=np.cross(n,[0,0,1.0]); u/=np.linalg.norm(u); w=np.cross(n,u)
    def ang(p): d=p-c; d=d-n*(d@n); return np.arctan2(d@w,d@u)
    thL=ang(np.array([23.8,-119.5,1267.6])); thRCA=ang(np.array([5.5,-132.4,1257.8]))
    cand=[thL+2*np.pi/3,thL-2*np.pi/3]; dif=lambda a,b: abs((a-b+np.pi)%(2*np.pi)-np.pi)
    thR=min(cand,key=lambda t:dif(t,thRCA)); thN=[t for t in cand if t is not thR][0]
    NS,NR=24,10; Ps=[];Po=[];I=[]
    for cusp,th0 in enumerate([thR,thL,thN]):
        base=len(Ps)
        for i in range(NS+1):
            s_=i/NS; th=th0-np.pi/3+s_*2*np.pi/3; d=np.cos(th)*u+np.sin(th)*w
            for j in range(NR+1):
                rho=j/NR
                zc=-(depth*np.sin(np.pi*s_)*rho**0.8+2.5*(1-rho))
                Ps.append(c+n*zc+d*R*rho*0.995)
                zo=-depth*np.sin(np.pi*s_)*rho**0.8+(1-rho)*8.5
                Po.append(c+n*zo+d*R*(0.80+0.195*rho))
        for i in range(NS):
            for j in range(NR):
                a=base+i*(NR+1)+j; b=a+NR+1
                I+=[[a,b,a+1],[a+1,b,b+1]]
    return np.array(Ps),np.array(Po),np.array(I)
avP,avO,avI=aortic_valve()

# ---------- transform & export for decimation ----------
center=wall.reshape(-1,3).mean(0)
def tf(p):
    p=(p-center)/1000.0
    return np.stack([p[...,0],p[...,2],-p[...,1]],-1).astype(np.float32)
def weld(v):
    p=v.reshape(-1,3).astype(np.float64); q=np.round(p/2e-6).astype(np.int64)
    u,inv=np.unique(q,axis=0,return_inverse=True); inv=inv.reshape(-1)
    P=np.zeros((len(u),3)); np.add.at(P,inv,p); P/=np.bincount(inv)[:,None]
    I=inv.reshape(-1,3); I=I[(I[:,0]!=I[:,1])&(I[:,1]!=I[:,2])&(I[:,0]!=I[:,2])]
    return P.astype(np.float32),I.astype(np.uint32)
import pickle, os
from glb import smooth_normals
out=[]
for pid,group,v in parts:
    P,I=weld(tf(v)); out.append(dict(id=pid,group=group,P=P,I=I,N=smooth_normals(P,I)))
P=tf(avP); PO=tf(avO); N=smooth_normals(P,avI); NO=smooth_normals(PO,avI)
out.insert(11,dict(id='aortic_valve',group='valve',P=P,I=avI.astype(np.uint32),N=N,targets=[dict(name='open',dP=PO-P,dN=NO-N)],reconstructed=True))
pickle.dump(out,open('/home/claude/pipeline/parts_raw.pkl','wb'))
os.makedirs('/home/claude/pipeline/dec_in',exist_ok=True)
idx=[]
for p in out:
    p['P'].astype('<f4').tofile(f"/home/claude/pipeline/dec_in/{p['id']}.pos"); p['N'].astype('<f4').tofile(f"/home/claude/pipeline/dec_in/{p['id']}.nrm"); p['I'].astype('<u4').tofile(f"/home/claude/pipeline/dec_in/{p['id']}.idx")
    idx.append({'id':p['id'],'tris':int(len(p['I']))}); print(p['id'],len(p['I']))
json.dump(idx,open('/home/claude/pipeline/dec_in/index.json','w'),indent=1)
json.dump({'center_mm_bp3d':center.tolist(),'transform':'godot=(x,z,-y)*0.001 after subtracting center'},open('/home/claude/pipeline/center.json','w'))
