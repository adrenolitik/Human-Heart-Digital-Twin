import numpy as np
from collections import defaultdict
def boundary_loops(P,I):
    q=np.round(P/1e-5).astype(np.int64); _,inv=np.unique(q,axis=0,return_inverse=True); inv=inv.ravel()
    T=inv[I.reshape(-1,3)]
    cnt=defaultdict(int); dire={}
    for t in T:
        for a,b in ((t[0],t[1]),(t[1],t[2]),(t[2],t[0])):
            k=(min(a,b),max(a,b)); cnt[k]+=1; dire[k]=(a,b)
    nxt={}
    for k,c in cnt.items():
        if c==1: a,b=dire[k]; nxt[a]=b
    rep={}
    for i,w in enumerate(inv): rep.setdefault(w,i)
    loops=[];seen=set()
    for s in list(nxt):
        if s in seen: continue
        L=[s]; seen.add(s); c=nxt.get(s)
        while c is not None and c not in seen: L.append(c); seen.add(c); c=nxt.get(c)
        loops.append([rep[w] for w in L])
    return loops
