"""
CardioCath 3D - open the prepared heart in Blender for inspection or manual refinement.

Usage (Blender 3.6+ / 4.x):
  blender --python tools/blender/open_heart_in_blender.py
or open Blender > Scripting tab > Open this file > Run Script.

What it does
  * imports assets/models/heart/heart.glb (glTF importer, +Y up is converted to Blender +Z up)
  * sorts the 36 parts into collections by anatomical group (from data/anatomy/heart_parts.json)
  * prints triangle counts so you can keep the Godot budget (~160k triangles total)

Re-exporting after edits (File > Export > glTF 2.0):
  * Format: glTF Binary (.glb), Include: Selected or Visible objects
  * Transform: +Y Up = ON
  * Geometry: Apply Modifiers ON, Normals ON, Tangents OFF, UVs optional, Vertex Colors ON
    (the chamber walls carry an epicardial-fat mask in vertex colour; keep it)
  * Shape keys ON (the aortic valve has an 'open' shape key)
  * Keep object names unchanged - they are the part ids used by data/anatomy/heart_parts.json
Save over assets/models/heart/heart.glb; Godot re-imports automatically.
"""
import bpy, json, os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))
GLB = os.path.join(ROOT, "assets", "models", "heart", "heart.glb")
DATA = os.path.join(ROOT, "data", "anatomy", "heart_parts.json")

def main():
    if not os.path.exists(GLB):
        raise FileNotFoundError(GLB)
    bpy.ops.import_scene.gltf(filepath=GLB)
    with open(DATA, encoding="utf-8") as f:
        data = json.load(f)
    group_of = {p["id"]: p["group"] for p in data["parts"]}
    names = {g["id"]: g["name"] for g in data["groups"]}
    cols = {}
    for gid, gname in names.items():
        c = bpy.data.collections.new("Heart - " + gname)
        bpy.context.scene.collection.children.link(c)
        cols[gid] = c
    total = 0
    for ob in list(bpy.context.selected_objects):
        if ob.type != "MESH":
            continue
        gid = group_of.get(ob.name.split(".")[0])
        if gid in cols:
            for c in ob.users_collection:
                c.objects.unlink(ob)
            cols[gid].objects.link(ob)
        tris = sum(len(p.vertices) - 2 for p in ob.data.polygons)
        total += tris
        print(f"{ob.name:28s} {tris:8d} tris")
    print(f"TOTAL {total} triangles")

main()
