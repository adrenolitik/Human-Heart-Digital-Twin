// Conduction glow halo: additive shell around the tubes (drawn through walls like the x-ray pass).
shader_type spatial;
render_mode unshaded, cull_back, blend_add, depth_draw_never, depth_test_disabled;
#define HALO
#include "res://assets/shaders/conduction_body.gdshaderinc"
