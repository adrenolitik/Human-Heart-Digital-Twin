// Conduction tubes seen through the myocardium ("x-ray" pass, drawn without depth test).
shader_type spatial;
render_mode unshaded, cull_disabled, blend_mix, depth_draw_never, depth_test_disabled;
#include "res://assets/shaders/conduction_body.gdshaderinc"
