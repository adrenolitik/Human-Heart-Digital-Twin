// Additive fresnel glow (material_overlay) for selection / hover / disease emphasis.
shader_type spatial;
render_mode unshaded, blend_add, depth_draw_never, cull_back;
#include "res://assets/shaders/heart_common.gdshaderinc"
uniform vec4 glow_color : source_color = vec4(0.13, 0.72, 0.85, 1.0);
uniform float intensity : hint_range(0.0, 2.0) = 0.6;
uniform float pulse_speed = 2.2;
uniform float pulse_amount : hint_range(0.0, 1.0) = 0.35;
varying vec3 world_pos;
void vertex() {
	VERTEX += heart_offset(VERTEX, NORMAL, COLOR, UV, UV2);
	world_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}
void fragment() {
	if (heart_clipped(world_pos)) { discard; }
	float fres = pow(1.0 - clamp(abs(dot(normalize(NORMAL), normalize(VIEW))), 0.0, 1.0), 1.6);
	float pulse = 1.0 - pulse_amount * (0.5 + 0.5 * sin(TIME * pulse_speed));
	ALBEDO = glow_color.rgb * intensity * pulse * (0.25 + 0.75 * fres);
}
