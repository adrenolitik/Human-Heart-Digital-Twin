// CardioCath 3D - conduction-system tubes (Stage 2). Included by conduction.gdshader and
// conduction_xray.gdshader. Vertex data written by ConductionSystem:
//   COLOR.r = activation time encoded (t + 0.06) / 0.26, COLOR.g = class / 3 (0 atrial, 1 AV node, 2 ventricular),
//   COLOR.b/a = LAD/RCA territory, UV/UV2 = chamber weights (the tubes follow the beating walls).
#include "res://assets/shaders/heart_common.gdshaderinc"
uniform vec4 base_color : source_color = vec4(0.95, 0.80, 0.30, 1.0);
uniform float highlight = 0.0;      // 1 = structure selected in the UI
uniform float dim = 0.0;            // 1 = another structure is selected
uniform float alpha_amount = 1.0;
uniform float halo_width = 0.0016;  // HALO pass only: how far the glow shell extends (m)
varying float v_t;
varying float v_cls;
varying vec3 world_pos;

void vertex() {
	v_t = COLOR.r * 0.26 - 0.06;
	v_cls = floor(COLOR.g * 3.0 + 0.5);
	if (v_cls > 0.5 && v_cls < 1.5) { v_t = COLOR.r; }   // AV node: fraction 0..1
	VERTEX += heart_offset(VERTEX, NORMAL, vec4(1.0, 1.0, COLOR.b, COLOR.a), UV, UV2);
#ifdef HALO
	VERTEX += NORMAL * halo_width;   // inflated shell around the tube
#endif
	world_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	if (heart_clipped(world_pos)) { discard; }
	float now; float w; float tail;
	if (v_cls < 0.5) { now = heart_ep.x; w = 0.010; tail = 0.05; }
	else if (v_cls < 1.5) { now = heart_ep.z; w = 0.16; tail = 0.6; }
	else { now = heart_ep.y; w = 0.006; tail = 0.04; }
	float dt = now - v_t;
	float front = exp(-dt * dt / (w * w));
	float trail = dt > 0.0 ? exp(-dt / tail) : 0.0;
	if (v_cls < 0.5 && heart_ep2.x > 0.5) {
		// atrial fibrillation: disorganised flicker in the atrial pathways
		float n = sin(v_t * 900.0 + heart_ep2.z * 41.0) * sin(v_t * 370.0 - heart_ep2.z * 27.0);
		front = smoothstep(0.4, 0.9, n); trail = 0.0;
	}
	if (v_cls > 1.5 && heart_ep2.y > 0.5) { front *= 0.0; trail *= 0.0; }   // ectopic beat bypasses the His-Purkinje system
	float glow = clamp(max(front, trail * 0.45), 0.0, 1.0);
	float fres = pow(1.0 - clamp(abs(dot(normalize(NORMAL), normalize(VIEW))), 0.0, 1.0), 1.5);
	vec3 rest = base_color.rgb * (0.55 + 0.30 * highlight) * (1.0 - 0.55 * dim);
	vec3 hot = vec3(1.0, 0.97, 0.80);
	vec3 c = mix(rest, hot, front) + base_color.rgb * trail * 0.5;
	c += base_color.rgb * fres * 0.25;
	c += vec3(0.25, 0.85, 1.0) * highlight * 0.35 * (0.6 + 0.4 * sin(TIME * 5.0));
#ifdef HALO
	// soft additive glow (like the reference animations): bright where the impulse is, fading to the shell edge
	float facing = clamp(abs(dot(normalize(NORMAL), normalize(VIEW))), 0.0, 1.0);
	float g2 = max(front, trail * 0.35) * (1.0 - 0.7 * dim) + highlight * 0.25;
	ALBEDO = mix(base_color.rgb, vec3(1.0, 0.92, 0.55), front) * g2 * pow(facing, 2.0) * 1.4;
	ALPHA = 1.0;
#else
	ALBEDO = c;
	ALPHA = alpha_amount * (0.55 + 0.45 * max(glow, highlight)) * (1.0 - 0.6 * dim);
#endif
}
