// Conduction tubes, depth-tested pass (see conduction_body.gdshaderinc).
shader_type spatial;
render_mode unshaded, cull_disabled, blend_mix, depth_draw_always;
#include "res://assets/shaders/conduction_body.gdshaderinc"
