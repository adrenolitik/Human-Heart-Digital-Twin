// CardioCath 3D - Stage 3 anatomy revealed under the skin (bones, great vessels, upper-limb arteries).
// Fades in with `reveal`. Bones: pale translucent with a soft Fresnel edge (radiograph-like, as in the
// transparent-patient reference). Arteries: solid red with a little sheen once fully revealed.
shader_type spatial;
render_mode cull_back, blend_mix, depth_draw_always;
uniform vec4 base_color : source_color = vec4(0.9, 0.87, 0.8, 1.0);
uniform float reveal = 0.0;
uniform float body_alpha = 0.22;     // alpha at normal incidence when revealed
uniform float edge_alpha = 0.75;     // alpha at grazing angles
uniform float roughness_v = 0.45;
uniform float highlight = 0.0;       // label/selection highlight
uniform vec4 highlight_color : source_color = vec4(0.13, 0.72, 0.85, 1.0);
void fragment() {
	float fres = pow(1.0 - clamp(dot(normalize(NORMAL), normalize(VIEW)), 0.0, 1.0), 2.0);
	ALBEDO = base_color.rgb;
	ROUGHNESS = roughness_v;
	ALPHA = mix(body_alpha, edge_alpha, fres) * reveal;
	EMISSION = highlight_color.rgb * highlight * (0.3 + 0.7 * fres);
	if (ALPHA < 0.01) { discard; }
}
