// CardioCath 3D - anatomical tissue shader (Compatibility-renderer safe).
// * beat / disease deformation and cutaway from heart_common.gdshaderinc
// * object-space triplanar detail (albedo, roughness, whiteout-blended normals) - meshes have no texture UVs
// * baked ambient occlusion (COLOR.g), epicardial fat (COLOR.r), infarct tissue change (COLOR.b/a)
// * custom light(): wrapped diffuse with red scattering (sub-surface look) + GGX + sharp "wet" lobe
// * back faces exposed by the cutaway are drawn as flat section colour
shader_type spatial;
render_mode cull_disabled;
#include "res://assets/shaders/heart_common.gdshaderinc"

uniform vec4 albedo : source_color = vec4(0.55, 0.16, 0.14, 1.0);
uniform vec4 section_color : source_color = vec4(0.42, 0.09, 0.08, 1.0);
uniform bool cap_backfaces = true;
uniform sampler2D albedo_tex : source_color, hint_default_white, filter_linear_mipmap, repeat_enable;
uniform sampler2D rough_tex : hint_default_white, filter_linear_mipmap, repeat_enable;
uniform sampler2D normal_tex : hint_normal, filter_linear_mipmap, repeat_enable;
uniform float tex_scale = 28.0;
uniform float roughness : hint_range(0.0, 1.0) = 0.5;
uniform float rough_tex_amount : hint_range(0.0, 1.0) = 0.6;
uniform float normal_strength : hint_range(0.0, 2.0) = 0.6;
uniform float specular_amount : hint_range(0.0, 1.0) = 0.5;
uniform float rim_amount : hint_range(0.0, 1.0) = 0.12;
uniform float detail_amount : hint_range(0.0, 1.0) = 1.0;
uniform float ao_amount : hint_range(0.0, 1.0) = 0.8;
uniform float wet_amount : hint_range(0.0, 2.0) = 0.6;
uniform float wrap_amount : hint_range(0.0, 1.0) = 0.35;
uniform float scatter_amount : hint_range(0.0, 1.0) = 0.35;
uniform vec4 scatter_color : source_color = vec4(0.95, 0.30, 0.22, 1.0);
uniform float fat_amount : hint_range(0.0, 1.0) = 0.0;
uniform vec4 fat_color : source_color = vec4(0.80, 0.68, 0.46, 1.0);
uniform sampler2D fat_normal_tex : hint_normal, filter_linear_mipmap, repeat_enable;
uniform vec4 infarct_color : source_color = vec4(0.44, 0.33, 0.30, 1.0);
uniform float calcification = 0.0;
// Update 4 (from the supplied 3D animation videos): large-scale marbling of the epicardium and
// trabeculae carneae on the ventricular endocardium.
uniform float mottle_amount : hint_range(0.0, 1.0) = 0.0;
uniform vec4 mottle_color : source_color = vec4(0.70, 0.46, 0.40, 1.0);
uniform float trabecula_amount : hint_range(0.0, 1.0) = 0.0;
uniform sampler2D noise_tex : hint_default_white, filter_linear_mipmap, repeat_enable;   // tileable fbm (r, g, b = 3 octave mixes)
uniform float light_gain = 0.85;   // aortic stenosis (valve material only)

varying vec3 obj_pos;
varying vec3 obj_nrm;
varying vec3 world_pos;
varying float v_ischemia;
varying float v_border;
varying vec2 v_act;

void vertex() {
	obj_pos = VERTEX;
	obj_nrm = NORMAL;
	VERTEX += heart_offset(VERTEX, NORMAL, COLOR, UV, UV2);
	world_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	float zl = smoothstep(0.45, 0.80, COLOR.b); float zr = smoothstep(0.45, 0.80, COLOR.a);
	v_ischemia = is_wall * clamp(heart_ischemia.z * zl + heart_ischemia.w * zr, 0.0, 1.0);
	float bl = smoothstep(0.25, 0.45, COLOR.b) * (1.0 - zl); float br = smoothstep(0.25, 0.45, COLOR.a) * (1.0 - zr);
	v_border = is_wall * clamp(heart_ischemia.z * bl + heart_ischemia.w * br, 0.0, 1.0);
	v_act = (heart_ep.w > 0.0 && is_wall > 0.5) ? heart_activation(obj_pos, UV, UV2) : vec2(1e3, 0.0);
}

// Stage 2 overlay: depolarisation wavefront (mode 1) or static isochrone map (mode 2).
void ep_overlay(vec2 act, vec3 op, inout vec3 alb, inout vec3 em) {
	if (heart_ep.w <= 0.0 || is_wall < 0.5 || act.x > 100.0) { return; }
	bool atr = act.y > 0.5;
	if (heart_ep.w > 1.5) {
		float range = atr ? 0.10 : (heart_ep2.y > 0.5 ? 0.17 : 0.085);
		float x = act.x / range;
		vec3 c = heart_iso_color(x);
		float band = smoothstep(0.42, 0.48, abs(fract(x * 10.0) - 0.5));
		alb = mix(alb, c * 0.55, 0.85) * (1.0 - 0.35 * band);
		em += c * 0.10;
		return;
	}
	float now = atr ? heart_ep.x : heart_ep.y;
	float dt = now - act.x;
	float apd = atr ? 0.13 : heart_ep2.w;
	if (atr && heart_ep2.x > 0.5) {
		// atrial fibrillation: many small, chaotic re-entrant wavelets instead of one organised front
		vec3 q = op * 330.0; float t = heart_ep2.z;
		float n = sin(q.x + t * 37.0 + sin(q.y * 0.7 + t * 11.0) * 2.0) * sin(q.y * 1.1 - t * 29.0) * sin(q.z * 0.9 + t * 23.0 + q.x * 0.4);
		float f = smoothstep(0.55, 0.85, n);
		em += vec3(1.0, 0.82, 0.35) * f * 0.9;
		alb = mix(alb, alb * vec3(0.8, 0.9, 1.25), 0.35);
		return;
	}
	float front = smoothstep(-0.003, 0.0, dt) * (1.0 - smoothstep(0.002, 0.016, dt));
	float depol = smoothstep(0.0, 0.004, dt) * (1.0 - smoothstep(apd - 0.05, apd, dt));
	alb = mix(alb, alb * vec3(0.62, 0.78, 1.45), depol * 0.55);
	em += vec3(1.0, 0.86, 0.38) * front * 1.35 + vec3(0.10, 0.22, 0.55) * depol * 0.18;
}

vec3 tri_w(vec3 n) { vec3 w = pow(abs(n), vec3(4.0)); return w / max(w.x + w.y + w.z, 1e-5); }

void fragment() {
	if (heart_clipped(world_pos)) { discard; }
	// Back faces: flat section colour only while a cutaway is active (closes the cut); otherwise they are
	// the inside of an open vessel / chamber and are shaded as a darker lumen, so tube ends look cut, not hollow.
	if (!FRONT_FACING && cap_backfaces && heart_clip_enabled > 0.5) {
		ALBEDO = section_color.rgb;
		ROUGHNESS = 0.8;
		SPECULAR = 0.15;
		NORMAL = vec3(0.0, 0.0, 1.0);
	} else {
		vec3 n = normalize(obj_nrm);
		vec3 w = tri_w(n);
		vec3 p = obj_pos * tex_scale;
		vec2 ux = p.zy; vec2 uy = p.xz; vec2 uz = p.xy;
		vec3 alb = texture(albedo_tex, ux).rgb * w.x + texture(albedo_tex, uy).rgb * w.y + texture(albedo_tex, uz).rgb * w.z;
		float r = texture(rough_tex, ux).r * w.x + texture(rough_tex, uy).r * w.y + texture(rough_tex, uz).r * w.z;
		vec3 tx = texture(normal_tex, ux).xyz * 2.0 - 1.0;
		vec3 ty = texture(normal_tex, uy).xyz * 2.0 - 1.0;
		vec3 tz = texture(normal_tex, uz).xyz * 2.0 - 1.0;
		// epicardial fat: baked groove mask broken into irregular lobules by low-frequency noise
		float fn = texture(noise_tex, ux * 0.23).r * w.x + texture(noise_tex, uy * 0.23).r * w.y + texture(noise_tex, uz * 0.23).r * w.z;
		float fat = smoothstep(0.20, 0.78, (1.0 - COLOR.r) + (fn - 0.5) * 0.40) * fat_amount;
		if (fat > 0.001) {
			vec3 fx = texture(fat_normal_tex, ux * 0.7).xyz * 2.0 - 1.0;
			vec3 fy = texture(fat_normal_tex, uy * 0.7).xyz * 2.0 - 1.0;
			vec3 fz = texture(fat_normal_tex, uz * 0.7).xyz * 2.0 - 1.0;
			tx = mix(tx, fx, fat); ty = mix(ty, fy, fat); tz = mix(tz, fz, fat);
		}
		float s = normal_strength * detail_amount;
		tx.xy *= s; ty.xy *= s; tz.xy *= s;
		tx = vec3(tx.xy + n.zy, abs(tx.z) * n.x);
		ty = vec3(ty.xy + n.xz, abs(ty.z) * n.y);
		tz = vec3(tz.xy + n.xy, abs(tz.z) * n.z);
		vec3 nb = normalize(tx.zyx * w.x + ty.xzy * w.y + tz.xyz * w.z);
		vec3 nv = normalize((VIEW_MATRIX * MODEL_MATRIX * vec4(nb, 0.0)).xyz);
		if (!FRONT_FACING) { nv = -nv; }
		NORMAL = nv;
		vec3 fatc = fat_color.rgb * mix(0.82, 1.06, fn) + vec3(0.03, 0.01, -0.02) * (1.0 - fn);
		vec3 base = mix(albedo.rgb, fatc, fat);
		// infarcted myocardium: pale / mottled, dull surface
		float mott = alb.r;
		base = mix(base, infarct_color.rgb * (0.70 + 0.6 * mott), v_ischemia * 0.9);
		base = mix(base, vec3(0.22, 0.03, 0.04), v_border * 0.7);   // hyperaemic / haemorrhagic border zone
		base = mix(base, vec3(0.86, 0.84, 0.76), calcification * smoothstep(0.82, 1.0, mott + 0.12));
		// marbling: soft lighter / darker patches (thin epicardial fat, subepicardial vessels)
		if (mottle_amount > 0.0) {
			float m1 = texture(noise_tex, ux * 0.09).g * w.x + texture(noise_tex, uy * 0.09).g * w.y + texture(noise_tex, uz * 0.09).g * w.z;
			float m2 = texture(noise_tex, ux * 0.031).b * w.x + texture(noise_tex, uy * 0.031).b * w.y + texture(noise_tex, uz * 0.031).b * w.z;
			float m = clamp(m1 * 0.6 + m2 * 0.7 - 0.15, 0.0, 1.0);
			base = mix(base, mottle_color.rgb, mottle_amount * smoothstep(0.42, 0.78, m) * (1.0 - fat));
			base *= mix(1.0, 0.86, mottle_amount * (1.0 - smoothstep(0.05, 0.35, m)));
		}
		// trabeculae carneae: irregular muscular ridges on the inner surface of the ventricles (apical 2/3)
		if (trabecula_amount > 0.0 && is_wall > 0.5) {
			float endo = smoothstep(0.93, 0.985, max(UV2.x, UV2.y));
			vec3 axl = normalize(heart_base.xyz - heart_apex.xyz);
			float along = dot(obj_pos - heart_apex.xyz, axl) / max(length(heart_base.xyz - heart_apex.xyz), 1e-4);
			endo *= 1.0 - smoothstep(0.55, 0.85, along);
			if (endo > 0.001) {
				// anisotropic noise: strands run roughly apex -> base, irregular width and branching
				vec3 tdir = normalize(cross(axl, n) + vec3(1e-4));
				vec2 tuv = vec2(dot(obj_pos, tdir) * 55.0, along * 2.2);
				float strand = texture(noise_tex, tuv).g * 0.7 + texture(noise_tex, tuv * vec2(2.3, 1.7)).r * 0.3;
				float crev = 1.0 - smoothstep(0.36, 0.50, strand);
				base *= 1.0 - 0.42 * crev * endo * trabecula_amount;
			}
		}
		if (!FRONT_FACING) { base *= 0.55; fat *= 0.0; }   // lumen / inner wall of an open tube
		float ao = mix(1.0, COLOR.g, ao_amount);
		ALBEDO = base * mix(vec3(1.0), alb, detail_amount) * mix(1.0, ao, 0.55);
		AO = ao;
		AO_LIGHT_AFFECT = 0.35;
		ROUGHNESS = clamp(mix(roughness, roughness * (0.6 + 0.8 * r), rough_tex_amount * detail_amount), 0.05, 1.0);
		ROUGHNESS = mix(ROUGHNESS, 0.42, fat);
		ROUGHNESS = mix(ROUGHNESS, 0.75, max(v_ischemia, calcification) * 0.8);
		SPECULAR = specular_amount * ao;
		vec3 em = vec3(0.0);
		ep_overlay(v_act, obj_pos, ALBEDO, em);
		EMISSION = em;
	}
}

void light() {
	float ndl = dot(NORMAL, LIGHT);
	float diff = clamp((ndl + wrap_amount) / ((1.0 + wrap_amount) * (1.0 + wrap_amount)), 0.0, 1.0);
	float term = clamp(1.0 - abs(ndl), 0.0, 1.0) * clamp(ndl + 0.6, 0.0, 1.0);
	vec3 sss = scatter_color.rgb * scatter_amount * term;
	DIFFUSE_LIGHT += LIGHT_COLOR * ATTENUATION * (vec3(diff) + sss) * light_gain / PI;
	vec3 h = normalize(VIEW + LIGHT);
	float ndh = max(dot(NORMAL, h), 0.0);
	float nl = clamp(ndl, 0.0, 1.0);
	float rr = max(ROUGHNESS, 0.06);
	float a2 = rr * rr * rr * rr;
	float dd = ndh * ndh * (a2 - 1.0) + 1.0;
	float ggx = a2 / (PI * dd * dd);
	float fres = 0.04 + 0.96 * pow(1.0 - max(dot(VIEW, h), 0.0), 5.0);
	float wet = pow(ndh, 700.0) * 4.0 * wet_amount;
	float rim = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 4.0) * rim_amount * clamp(ndl + 0.4, 0.0, 1.0);
	SPECULAR_LIGHT += LIGHT_COLOR * ATTENUATION * (nl * (ggx * fres * 0.25 * SPECULAR_AMOUNT * 2.0 + wet * fres * 4.0) + rim * 0.5) / PI;
}
