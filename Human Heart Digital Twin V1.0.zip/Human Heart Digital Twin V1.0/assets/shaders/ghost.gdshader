// Translucent "x-ray" context for structures that are not isolated.
shader_type spatial;
render_mode unshaded, blend_mix, depth_draw_never, cull_back;
#include "res://assets/shaders/heart_common.gdshaderinc"
uniform vec4 tint : source_color = vec4(0.55, 0.75, 0.95, 1.0);
uniform float alpha_amount : hint_range(0.0, 1.0) = 0.12;
varying vec3 world_pos;
void vertex() {
	VERTEX += heart_offset(VERTEX, NORMAL, COLOR, UV, UV2);
	world_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}
void fragment() {
	if (heart_clipped(world_pos)) { discard; }
	float fres = pow(1.0 - clamp(abs(dot(normalize(NORMAL), normalize(VIEW))), 0.0, 1.0), 2.0);
	ALBEDO = tint.rgb;
	ALPHA = alpha_amount * (0.25 + 0.75 * fres);
}
