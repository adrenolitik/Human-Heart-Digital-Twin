// CardioCath 3D - shared heart deformation & cutaway (included by tissue / ghost / highlight shaders).
// Every vertex is displaced by a field that depends only on its model-space position and the
// per-vertex weights baked by the asset pipeline, so touching parts always move together:
//   UV  = (w_RA, w_LA), UV2 = (w_RV, w_LV)  chamber proximity weights
//   COLOR.b = LAD territory, COLOR.a = RCA territory
global uniform vec4 heart_clip_plane;   // xyz world normal, w distance; fragments with dot(n,p) > w are cut away
global uniform float heart_clip_enabled;
global uniform vec4 heart_c_ra;         // xyz chamber centroid (model space), w = contraction amount
global uniform vec4 heart_c_la;
global uniform vec4 heart_c_rv;
global uniform vec4 heart_c_lv;
global uniform vec4 heart_apex;         // xyz apex, w = longitudinal shortening (m)
global uniform vec4 heart_base;         // xyz centre of the AV plane
global uniform vec4 heart_remodel;      // x LV endocardial thickening (m, <0 thinning), y septal thickening (m), z LV dilation, w RV dilation
global uniform vec4 heart_remodel2;     // x LA dilation, y RA dilation, z LV outer growth (hypertrophy), w unused
global uniform vec4 heart_ischemia;     // x LAD akinesis, y RCA akinesis, z LAD tissue change, w RCA tissue change
global uniform vec4 heart_fib;          // x atrial fibrillation amplitude (m), y ventricular fibrillation amplitude (m), z time

// --- Stage 2 electrophysiology (written by CardiacEngine; overlay off when heart_ep.w == 0)
global uniform vec4 heart_ep;       // x s since atrial activation, y s relative to QRS onset, z AV-node fraction, w overlay (0 off, 1 wave, 2 isochrones)
global uniform vec4 heart_ep2;      // x AF (chaotic atria), y ectopic ventricular beat, z time, w ventricular action-potential duration (s)
global uniform vec4 heart_ep_sa;    // xyz SA node, w atrial conduction velocity (m/s)
global uniform vec4 heart_ep_bb;    // xyz end of Bachmann's bundle, w its activation time (s)
global uniform vec4 heart_ep_v0;    // ventricular breakthrough sites from the Purkinje network: xyz, w time rel. QRS (s)
global uniform vec4 heart_ep_v1;
global uniform vec4 heart_ep_v2;
global uniform vec4 heart_ep_v3;
global uniform vec4 heart_ep_v4;
global uniform vec4 heart_ep_v5;
global uniform vec4 heart_ep_focus; // xyz ectopic ventricular focus (PVC / VT), w myocardial conduction velocity (m/s)

uniform float is_wall = 0.0;           // 1 for myocardium-like materials (thickening applies to their endocardial surface)

vec3 heart_offset(vec3 p, vec3 n, vec4 col, vec2 uva, vec2 uvv) {
	float wRA = uva.x; float wLA = uva.y; float wRV = uvv.x; float wLV = uvv.y;
	vec3 d = vec3(0.0);
	// --- static remodelling (disease)
	d += (p - heart_c_lv.xyz) * (heart_remodel.z + heart_remodel2.z) * wLV;
	d += (p - heart_c_rv.xyz) * heart_remodel.w * wRV;
	d += (p - heart_c_la.xyz) * heart_remodel2.x * wLA;
	d += (p - heart_c_ra.xyz) * heart_remodel2.y * wRA;
	if (is_wall > 0.5) {
		// Endocardial surfaces are identified from the baked proximity weights (smooth, normal-independent):
		// the inner surface has weight ~1, the epicardial surface of a ~1 cm wall ~0.6.
		float in_lv = smoothstep(0.86, 0.97, wLV);
		float in_rv = smoothstep(0.86, 0.97, wRV);
		float sept = smoothstep(0.30, 0.60, wLV * wRV);
		float h_lv = heart_remodel.x + heart_remodel.y * sept;   // LV-side thickening (m)
		float h_rv = heart_remodel.y * sept;                     // RV-side septal thickening (m)
		vec3 to_lv = heart_c_lv.xyz - p; float dl = max(length(to_lv), 1e-4);
		vec3 to_rv = heart_c_rv.xyz - p; float dr = max(length(to_rv), 1e-4);
		d += to_lv / dl * clamp(h_lv, -0.01, dl * 0.7) * in_lv;
		d += to_rv / dr * clamp(h_rv, -0.01, dr * 0.7) * in_rv * (1.0 - in_lv);
	}
	// --- contraction (regional akinesis in infarcted territory, slight paradoxical bulge)
	float vloc = clamp(1.0 - 1.15 * (heart_ischemia.x * smoothstep(0.35, 0.7, col.b) + heart_ischemia.y * smoothstep(0.35, 0.7, col.a)), -0.15, 1.0);
	d += (heart_c_lv.xyz - p) * heart_c_lv.w * wLV * vloc;
	d += (heart_c_rv.xyz - p) * heart_c_rv.w * wRV * vloc;
	d += (heart_c_la.xyz - p) * heart_c_la.w * wLA;
	d += (heart_c_ra.xyz - p) * heart_c_ra.w * wRA;
	// --- long-axis shortening: the AV plane descends toward the (nearly fixed) apex
	vec3 ax = heart_base.xyz - heart_apex.xyz;
	float L = max(length(ax), 1e-5);
	ax /= L;
	float s = dot(p - heart_apex.xyz, ax) / L;
	float bw = s <= 1.0 ? clamp(s, 0.0, 1.0) : exp(-(s - 1.0) * 2.5);
	d -= ax * heart_apex.w * bw;
	// --- fibrillation (uncoordinated quivering)
	if (heart_fib.x + heart_fib.y > 0.0) {
		float t = heart_fib.z;
		vec3 q = p * 140.0;
		vec3 nz = vec3(sin(q.y * 1.3 + t * 31.0) + sin(q.z * 0.9 + t * 23.0),
			sin(q.z * 1.1 + t * 27.0) + sin(q.x * 1.7 + t * 19.0),
			sin(q.x * 1.2 + t * 29.0) + sin(q.y * 0.8 + t * 21.0)) * 0.5;
		d += nz * (heart_fib.x * max(wLA, wRA) + heart_fib.y * max(wLV, wRV));
	}
	return d;
}

// Educational activation map: x = activation time (s; atrial rel. SA firing, ventricular rel. QRS onset),
// y = 1 for atrial myocardium. Distances are straight-line (a simplification of real wavefront paths).
vec2 heart_activation(vec3 p, vec2 uva, vec2 uvv) {
	float atr = max(uva.x, uva.y) > max(uvv.x, uvv.y) ? 1.0 : 0.0;
	if (atr > 0.5) {
		float v = max(heart_ep_sa.w, 0.1);
		float t = min(length(p - heart_ep_sa.xyz) / v, heart_ep_bb.w + length(p - heart_ep_bb.xyz) / v);
		return vec2(t, 1.0);
	}
	float vm = 0.6;
	if (heart_ep2.y > 0.5) {
		return vec2(length(p - heart_ep_focus.xyz) / max(heart_ep_focus.w, 0.1), 0.0);
	}
	float t = heart_ep_v0.w + length(p - heart_ep_v0.xyz) / vm;
	t = min(t, heart_ep_v1.w + length(p - heart_ep_v1.xyz) / vm);
	t = min(t, heart_ep_v2.w + length(p - heart_ep_v2.xyz) / vm);
	t = min(t, heart_ep_v3.w + length(p - heart_ep_v3.xyz) / vm);
	t = min(t, heart_ep_v4.w + length(p - heart_ep_v4.xyz) / vm);
	t = min(t, heart_ep_v5.w + length(p - heart_ep_v5.xyz) / vm);
	return vec2(t, 0.0);
}

// Rainbow isochrone colour (red = earliest ... violet = latest), as on clinical activation maps.
vec3 heart_iso_color(float x) {
	x = clamp(x, 0.0, 1.0);
	float y = 1.0 - x;   // reversed "jet": red (early) -> yellow -> green -> blue
	vec3 c = clamp(vec3(1.5 - abs(4.0 * y - 3.0), 1.5 - abs(4.0 * y - 2.0), 1.5 - abs(4.0 * y - 1.0)), 0.0, 1.0);
	c = mix(vec3(0.95, 0.10, 0.08), c, smoothstep(0.0, 0.10, x));
	return mix(c, vec3(0.58, 0.22, 0.88), smoothstep(0.80, 1.0, x));   // latest = violet
}

bool heart_clipped(vec3 world_pos) {
	return heart_clip_enabled > 0.5 && dot(heart_clip_plane.xyz, world_pos) > heart_clip_plane.w;
}
