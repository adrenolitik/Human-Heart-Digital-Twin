## PartPicker
## Ray-casts from the active camera against heart part colliders (physics layer 2).
## Skips parts that are hidden/ghosted (their collision layer is cleared) and hits that
## lie in the removed half-space of the cutaway plane, so internal structures can be
## picked through the cut.
class_name PartPicker
extends Node

@export var heart_path: NodePath
@export var max_distance := 5.0
var heart: HeartModel

func _ready() -> void:
	heart = get_node_or_null(heart_path) as HeartModel

func pick(screen_pos: Vector2) -> Dictionary:
	if heart == null:
		return {}
	var cam := get_viewport().get_camera_3d()
	if cam == null:
		return {}
	var from := cam.project_ray_origin(screen_pos)
	var dir := cam.project_ray_normal(screen_pos)
	var space := heart.get_world_3d().direct_space_state
	var exclude: Array[RID] = []
	for i in 16:   # walk through at most 16 clipped hits
		var q := PhysicsRayQueryParameters3D.create(from, from + dir * max_distance, HeartModel.PICK_LAYER, exclude)
		q.hit_back_faces = true
		var hit := space.intersect_ray(q)
		if hit.is_empty():
			return {}
		if heart.is_point_clipped(hit["position"]):
			exclude.append(hit["rid"])
			continue
		var id := heart.part_from_collider(hit["collider"])
		if id != "":
			return {"id": id, "position": hit["position"], "normal": hit["normal"]}
		exclude.append(hit["rid"])
	return {}

## True if another structure lies between the camera and `world_point` (used for label culling).
func is_occluded(part_id: String, world_point: Vector3) -> bool:
	if heart == null:
		return false
	var cam := get_viewport().get_camera_3d()
	if cam == null:
		return false
	var from := cam.global_position
	var to := world_point + (from - world_point).normalized() * 0.0025
	var space := heart.get_world_3d().direct_space_state
	var exclude: Array[RID] = []
	for i in 12:
		var q := PhysicsRayQueryParameters3D.create(from, to, HeartModel.PICK_LAYER, exclude)
		var hit := space.intersect_ray(q)
		if hit.is_empty():
			return false
		if heart.is_point_clipped(hit["position"]):
			exclude.append(hit["rid"])
			continue
		return heart.part_from_collider(hit["collider"]) != part_id
	return false
