## OrbitCamera
## Inspection camera: left-drag rotate, right/middle-drag pan, wheel zoom, keyboard
## (arrows / +/-), smooth damping, preset views and focus-on-point.
## Emits `clicked` only when the mouse was released without dragging, so picking and
## orbiting never conflict.
class_name OrbitCamera
extends Node3D

signal clicked(screen_pos: Vector2)
signal hovered(screen_pos: Vector2)
signal view_changed

@export var distance := 0.42
@export var min_distance := 0.12
@export var max_distance := 1.2
@export var rotate_speed := 0.006
@export var pan_speed := 0.0012
@export var zoom_step := 1.12
@export var damping := 12.0
@export var fov := 35.0

const DRAG_THRESHOLD := 5.0
const VIEWS := {
	"anterior": Vector2(0.0, -8.0), "posterior": Vector2(180.0, -8.0),
	"left": Vector2(90.0, -8.0), "right": Vector2(-90.0, -8.0),
	"superior": Vector2(0.0, -80.0), "inferior": Vector2(0.0, 80.0),
}

var camera: Camera3D
## Screen rectangle (pixels) left free by the UI panels. When set, the projection is shifted
## (Camera3D h/v offset) so the orbit target appears at the centre of this rectangle instead of
## the centre of the window, so panels never hide the subject.
var frame_rect := Rect2()
var _yaw := 0.0
var _pitch := -8.0
var _target := Vector3.ZERO
var _cur_yaw := 0.0
var _cur_pitch := -8.0
var _cur_target := Vector3.ZERO
var _cur_distance := 0.42
var _home := {}
var _press_pos := Vector2.ZERO
var _dragging := false
var _button := 0

func _ready() -> void:
	camera = Camera3D.new()
	camera.fov = fov
	camera.near = 0.005
	camera.far = 20.0
	add_child(camera)
	camera.current = true
	_cur_distance = distance
	_home = {"yaw": _yaw, "pitch": _pitch, "target": _target, "distance": distance}
	_apply(true)

func set_home(yaw_deg: float, pitch_deg: float, target: Vector3, dist: float) -> void:
	_home = {"yaw": yaw_deg, "pitch": pitch_deg, "target": target, "distance": dist}

func reset_view(animated := true) -> void:
	set_view(_home["yaw"], _home["pitch"], _home["target"], _home["distance"], animated)

func set_view(yaw_deg: float, pitch_deg: float, target: Vector3, dist: float, animated := true) -> void:
	_yaw = yaw_deg
	_pitch = clampf(pitch_deg, -89.0, 89.0)
	_target = target
	distance = clampf(dist, min_distance, max_distance)
	if not animated:
		_cur_yaw = _yaw; _cur_pitch = _pitch; _cur_target = _target; _cur_distance = distance
	_apply(not animated)
	view_changed.emit()

func set_preset(view_name: String, animated := true) -> void:
	if VIEWS.has(view_name):
		var v: Vector2 = VIEWS[view_name]
		var y := v.x
		while y - _yaw > 180.0: y -= 360.0
		while y - _yaw < -180.0: y += 360.0
		set_view(y, v.y, _home["target"], _home["distance"], animated)

## Places the camera on the side of `dir` (from target toward the camera).
func look_from_direction(dir: Vector3, target: Vector3, dist: float, animated := true) -> void:
	var d := dir.normalized()
	var pitch := -rad_to_deg(asin(clampf(d.y, -1.0, 1.0)))
	var yaw := rad_to_deg(atan2(d.x, d.z))
	# keep the yaw continuous with the current one to avoid long spins
	while yaw - _yaw > 180.0: yaw -= 360.0
	while yaw - _yaw < -180.0: yaw += 360.0
	set_view(yaw, pitch, target, dist, animated)

func get_view_direction() -> Vector3:
	return (camera.global_position - _cur_target).normalized() if camera else Vector3.BACK

func get_target() -> Vector3:
	return _target

func focus_on(point: Vector3, dist := -1.0) -> void:
	_target = point
	if dist > 0.0:
		distance = clampf(dist, min_distance, max_distance)
	view_changed.emit()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP and mb.pressed:
			distance = clampf(distance / zoom_step, min_distance, max_distance); view_changed.emit()
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN and mb.pressed:
			distance = clampf(distance * zoom_step, min_distance, max_distance); view_changed.emit()
		elif mb.button_index in [MOUSE_BUTTON_LEFT, MOUSE_BUTTON_RIGHT, MOUSE_BUTTON_MIDDLE]:
			if mb.pressed:
				_button = mb.button_index
				_press_pos = mb.position
				_dragging = false
			else:
				if mb.button_index == MOUSE_BUTTON_LEFT and not _dragging:
					clicked.emit(mb.position)
				_button = 0
				_dragging = false
	elif event is InputEventMouseMotion:
		var mm := event as InputEventMouseMotion
		if _button != 0:
			if not _dragging and mm.position.distance_to(_press_pos) > DRAG_THRESHOLD:
				_dragging = true
			if _dragging:
				if _button == MOUSE_BUTTON_LEFT:
					_yaw -= mm.relative.x * rotate_speed * 57.2958
					_pitch = clampf(_pitch - mm.relative.y * rotate_speed * 57.2958, -89.0, 89.0)
				else:
					var basis := camera.global_transform.basis
					_target += (-basis.x * mm.relative.x + basis.y * mm.relative.y) * pan_speed * distance / 0.42
				view_changed.emit()
		else:
			hovered.emit(mm.position)
	elif event is InputEventKey and event.pressed:
		var k := event as InputEventKey
		match k.keycode:
			KEY_LEFT: _yaw += 10.0
			KEY_RIGHT: _yaw -= 10.0
			KEY_UP: _pitch = clampf(_pitch + 8.0, -89.0, 89.0)
			KEY_DOWN: _pitch = clampf(_pitch - 8.0, -89.0, 89.0)
			KEY_EQUAL, KEY_KP_ADD: distance = clampf(distance / zoom_step, min_distance, max_distance)
			KEY_MINUS, KEY_KP_SUBTRACT: distance = clampf(distance * zoom_step, min_distance, max_distance)
			KEY_HOME: reset_view()
			_: return
		view_changed.emit()

func _process(delta: float) -> void:
	var t := 1.0 - exp(-damping * delta)
	_cur_yaw = lerpf(_cur_yaw, _yaw, t)
	_cur_pitch = lerpf(_cur_pitch, _pitch, t)
	_cur_target = _cur_target.lerp(_target, t)
	_cur_distance = lerpf(_cur_distance, distance, t)
	_apply(false)

func _apply(_snap: bool) -> void:
	var rot := Basis.from_euler(Vector3(deg_to_rad(_cur_pitch), deg_to_rad(_cur_yaw), 0.0), EULER_ORDER_YXZ)
	global_position = _cur_target
	if camera:
		camera.position = rot * Vector3(0, 0, _cur_distance)
		camera.look_at(_cur_target, Vector3.UP if absf(_cur_pitch) < 89.5 else Vector3(0, 0, -1))
		if frame_rect.has_area() and is_inside_tree():
			var vp := get_viewport().get_visible_rect().size
			var off := frame_rect.get_center() - vp * 0.5
			var wpp := 2.0 * _cur_distance * tan(deg_to_rad(camera.fov) * 0.5) / maxf(vp.y, 1.0)
			camera.h_offset = -off.x * wpp
			camera.v_offset = off.y * wpp
		else:
			camera.h_offset = 0.0
			camera.v_offset = 0.0

func get_camera() -> Camera3D:
	return camera
