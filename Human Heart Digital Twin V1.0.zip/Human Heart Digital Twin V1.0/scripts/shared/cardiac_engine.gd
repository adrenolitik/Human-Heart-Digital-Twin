## CardiacEngine
## Educational cardiac-cycle simulator that drives the 3D heart.
## * Beat scheduling for the rhythm models: sinus, atrial fibrillation (af), complete AV block (chb),
##   ventricular fibrillation (vf), premature ventricular contractions (pvc), ventricular tachycardia (vt).
## * Atrial / ventricular contraction curves, cycle phases and valve states (timing scales with heart rate).
## * Simulated 12-lead ECG from a time-varying cardiac dipole (heart vector) projected on the lead axes
##   (Einthoven / Goldberger / Wilson geometry). The vector frame is the heart model frame:
##   x = patient's left, y = superior, z = anterior.
## * Stage 2 electrophysiology state (impulse position in the conduction system, myocardial wavefront)
##   written to global shader uniforms heart_ep*.
## * Illustrative haemodynamics (EDV, ESV, SV, EF, CO, BP).
## * Writes global shader uniforms consumed by heart_common.gdshaderinc and opens the aortic valve.
## All signals are SIMULATED teaching approximations, not clinically validated models.
class_name CardiacEngine
extends Node

signal condition_changed(condition: Dictionary)
signal beat(kind: String)          # "atrial" | "ventricular"
signal rate_changed(hr: float)

const CONDITIONS_PATH := "res://data/physiology/conditions.json"
const K_LV := 0.15                 # fraction of the distance to the chamber centroid at full contraction
const K_RV := 0.13
const K_LA := 0.10
const K_RA := 0.10
const LONG_SHORTEN := 0.009        # metres of AV-plane descent at full systole
const LEAD_NAMES := ["I", "II", "III", "aVR", "aVL", "aVF", "V1", "V2", "V3", "V4", "V5", "V6"]
## Frontal-plane angles (hexaxial reference, degrees, +90 = inferior) and horizontal-plane angles
## (0 = patient's left, 90 = anterior) of the lead axes.
const FRONTAL_ANGLE := {"I": 0.0, "II": 60.0, "III": 120.0, "aVR": -150.0, "aVL": -30.0, "aVF": 90.0}
const PRECORDIAL_GAIN := {"V1": 1.25, "V2": 2.1, "V3": 2.0, "V4": 1.8, "V5": 1.3, "V6": 1.0}
const PRECORDIAL_ANGLE := {"V1": 115.0, "V2": 94.0, "V3": 75.0, "V4": 60.0, "V5": 30.0, "V6": 0.0}
# Normal QRS loop: septal (left-to-right), main (leftward / inferior / posterior), terminal (basal).
const V_SEPTAL := Vector3(-0.53, -0.10, 0.84)
const V_MAIN := Vector3(0.78, -0.55, -0.30)
const V_TERM := Vector3(-0.46, 0.60, -0.65)
const V_P_RA := Vector3(0.30, -0.80, 0.52)
const V_P_LA := Vector3(0.78, -0.45, -0.43)
const V_T := Vector3(0.66, -0.64, 0.38)
const CONDUCTION_PATH := "res://data/electro/conduction.json"

var heart: HeartModel
var playing := true
var speed := 1.0
var motion_scale := 1.0            # exaggeration for teaching (1 = default)
var beating := true
var hr := 72.0                     # ventricular rate set by the user (sinus rate for sinus rhythm)
var atrial_rate := 80.0            # used for complete heart block
var severity := 1.0
var sim_time := 0.0
var conditions: Array = []
## Extra condition/rhythm files merged into `conditions` (set before adding the node to the tree).
var extra_paths := PackedStringArray()
## Stage 2 overlay written to heart_ep.w: 0 off (Stage 1), 1 depolarisation wave, 2 isochrone map.
var ep_overlay := 0
var ep_pvc_every := 4                # PVC pattern: 2 = bigeminy, 3 = trigeminy, 4+ = isolated
var condition := {}
var sim := {}                      # condition["sim"]

var _a_beats: Array[float] = []    # P-wave onsets (s)
var _v_beats: Array[float] = []    # QRS onsets (s)
var _v_ect: Array[bool] = []       # true = ectopic ventricular beat (PVC / VT)
var _a_cond: Array[bool] = []      # true = P wave conducted to the ventricles
var _beat_n := 0
var _ep := {}                      # conduction data (sources, AV entry time, His start)
var _ect_dir := {"pvc": Vector3(0.2, -0.85, -0.45), "vt": Vector3(-0.1, -0.2, 0.95)}
var _ep_state := {}
var _next_a := 0.2
var _next_v := 0.2
var _rng := RandomNumberGenerator.new()
var _a_amt := 0.0
var _v_amt := 0.0
var _phase := ""
var _phase_id := ""
## Last chamber/apex motion values written to the shaders (for CPU-side followers, e.g. Stage 3 devices).
var motion_uniforms := {}

func _ready() -> void:
	_rng.seed = 7
	var d = JSON.parse_string(FileAccess.get_file_as_string(CONDITIONS_PATH)) if FileAccess.file_exists(CONDITIONS_PATH) else null
	if d is Dictionary:
		conditions = d.get("conditions", [])
	else:
		push_error("CardiacEngine: missing or invalid %s" % CONDITIONS_PATH)
	for path in extra_paths:
		var e = JSON.parse_string(FileAccess.get_file_as_string(path)) if FileAccess.file_exists(path) else null
		if e is Dictionary:
			conditions.append_array(e.get("conditions", []))
		else:
			push_warning("CardiacEngine: could not read %s" % path)
	_load_conduction()
	set_condition("normal")

# ------------------------------------------------------------------ public API
func get_condition_ids() -> PackedStringArray:
	var out := PackedStringArray()
	for c in conditions:
		out.append(c["id"])
	return out

func get_condition_data(id: String) -> Dictionary:
	for c in conditions:
		if c["id"] == id:
			return c
	return {}

func set_condition(id: String) -> void:
	var c := get_condition_data(id)
	if c.is_empty():
		push_warning("CardiacEngine: unknown condition %s" % id)
		return
	condition = c
	sim = c.get("sim", {})
	var r: Array = sim.get("hr_range", [40, 180])
	hr = clampf(float(sim.get("hr", 72)), r[0], r[1])
	atrial_rate = float(sim.get("atrial_rate", 80))
	_reset_schedule()
	_apply_static()
	_update_focus()
	condition_changed.emit(condition)
	rate_changed.emit(hr)

func get_rhythm() -> String:
	return String(sim.get("rhythm", "sinus"))

func get_hr_range() -> Vector2:
	var r: Array = sim.get("hr_range", [40, 180])
	return Vector2(r[0], r[1])

func set_hr(v: float) -> void:
	var r := get_hr_range()
	hr = clampf(v, r.x, r.y)
	rate_changed.emit(hr)

func set_severity(v: float) -> void:
	severity = clampf(v, 0.0, 1.0)
	_apply_static()

func restart() -> void:
	sim_time = 0.0
	_reset_schedule()

func set_beating(on: bool) -> void:
	beating = on
	if not on:
		_write_motion(0.0, 0.0)

func get_phase() -> String:
	return _phase

func get_phase_id() -> String:
	return _phase_id

## Valve states for the current instant: {"av": bool open, "sl": bool open}
func get_valve_states() -> Dictionary:
	match _phase_id:
		"ejection": return {"av": false, "sl": true}
		"ivc", "ivr": return {"av": false, "sl": false}
		"vf": return {"av": false, "sl": false}
		_: return {"av": true, "sl": false}

func rr() -> float:
	return 60.0 / maxf(hr, 1.0)

# ------------------------------------------------------------------ timing helpers
func _pr(rr_: float) -> float:
	return clampf(0.16 * sqrt(rr_ / 0.8), 0.12, 0.20)

func _systole(rr_: float) -> float:   # electromechanical systole incl. isovolumetric contraction
	return clampf(0.30 * sqrt(rr_), 0.16, 0.42)

func _ivr(rr_: float) -> float:
	return clampf(0.06 * sqrt(rr_ / 0.8), 0.035, 0.08)

func _qt(rr_: float) -> float:
	return clampf(0.40 * sqrt(rr_), 0.24, 0.50)

func _reset_schedule() -> void:
	_a_beats.clear()
	_v_beats.clear()
	_v_ect.clear()
	_a_cond.clear()
	_beat_n = 0
	_next_a = sim_time + 0.15
	_next_v = sim_time + 0.15 + _pr(rr())

func _schedule(horizon: float) -> void:
	var rhythm := get_rhythm()
	match rhythm:
		"sinus":
			while _next_a <= horizon:
				var r := rr()
				_push_a(_next_a, true)
				_push_v(_next_a + _pr(r), false)
				_next_a += r
		"pvc":
			# Sinus rhythm; every Nth beat is replaced by a premature ectopic beat (coupling ~0.55 RR).
			# The sinus P wave that follows falls in the refractory period (not conducted), so the
			# next conducted beat arrives on schedule: a full compensatory pause.
			while _next_a <= horizon:
				var r := rr()
				_beat_n += 1
				if ep_pvc_every >= 2 and _beat_n % ep_pvc_every == 0 and _beat_n > 1:
					_push_v(_next_a - r + _pr(r) + 0.55 * r, true)
					_push_a(_next_a, false)
				else:
					_push_a(_next_a, true)
					_push_v(_next_a + _pr(r), false)
				_next_a += r
		"vt":
			# Regular wide ectopic ventricular beats; the sinus node keeps firing independently (AV dissociation).
			while _next_a <= horizon:
				_push_a(_next_a, false)
				_next_a += 60.0 / atrial_rate
			while _next_v <= horizon:
				_push_v(_next_v, true)
				_next_v += rr()
		"af":
			while _next_v <= horizon:
				_push_v(_next_v, false)
				_next_v += rr() * _rng.randf_range(0.62, 1.38)
		"chb":
			while _next_a <= horizon:
				_push_a(_next_a, false)
				_next_a += 60.0 / atrial_rate
			while _next_v <= horizon:
				_push_v(_next_v, false)
				_next_v += rr()
		_:
			pass
	var keep := sim_time - 14.0
	while _a_beats.size() > 0 and _a_beats[0] < keep:
		_a_beats.pop_front()
		_a_cond.pop_front()
	while _v_beats.size() > 0 and _v_beats[0] < keep:
		_v_beats.pop_front()
		_v_ect.pop_front()

func _push_a(t: float, conducted: bool) -> void:
	_a_beats.append(t)
	_a_cond.append(conducted)

func _push_v(t: float, ectopic: bool) -> void:
	_v_beats.append(t)
	_v_ect.append(ectopic)

func _last_before(arr: Array[float], t: float) -> float:
	var best := -1e9
	for x in arr:
		if x <= t and x > best:
			best = x
	return best

# ------------------------------------------------------------------ contraction curves
func _ventricular_curve(tau: float, rr_: float) -> float:
	if tau < 0.0:
		return 0.0
	var ivc := 0.05
	var ts := _systole(rr_)
	var ivr := _ivr(rr_)
	if tau < ivc:
		return 0.10 * tau / ivc
	if tau < ts:
		var x := (tau - ivc) / (ts - ivc)
		return 0.10 + 0.90 * smoothstep(0.0, 0.65, x)
	var y := (tau - ts) / (ivr + 0.14)
	return 1.0 - smoothstep(0.0, 1.0, y)

func _atrial_curve(tau: float) -> float:
	var x := (tau - 0.05) / 0.11
	if x <= 0.0 or x >= 1.0:
		return 0.0
	return pow(sin(PI * x), 1.2)

# ------------------------------------------------------------------ frame update
func _process(delta: float) -> void:
	if playing:
		sim_time += delta * speed
	_schedule(sim_time + 1.0)
	var r := rr()
	var tv := _last_before(_v_beats, sim_time - 0.02)
	var ta := _last_before(_a_beats, sim_time)
	var rhythm := get_rhythm()
	_v_amt = 0.0 if rhythm == "vf" else _ventricular_curve(sim_time - 0.02 - tv, r)
	if _is_ectopic_at(tv):
		_v_amt *= 0.62 if rhythm == "pvc" else 0.75   # dyssynchronous (and, for a PVC, under-filled) contraction
	_a_amt = 0.0 if rhythm in ["af", "vf"] else _atrial_curve(sim_time - ta)
	_update_phase(sim_time - 0.02 - tv, r, rhythm)
	if beating:
		_write_motion(_v_amt, _a_amt)
	var fib := Vector4.ZERO
	if beating:
		if rhythm == "af":
			fib.x = 0.00055 * motion_scale
		elif rhythm == "vf":
			fib.y = 0.0011 * motion_scale
			fib.x = 0.0004 * motion_scale
	fib.z = sim_time
	RenderingServer.global_shader_parameter_set("heart_fib", fib)
	_update_ep()
	if heart:
		var av_open := 0.0
		if _phase_id == "ejection":
			var ts := _systole(r)
			var t := sim_time - 0.02 - tv
			av_open = smoothstep(0.05, 0.08, t) * (1.0 - smoothstep(ts - 0.03, ts, t))
		heart.set_valve_open("aortic_valve", av_open * float(sim.get("av_max_open", 1.0)) if beating else 0.0)

func _write_motion(v: float, a: float) -> void:
	if heart == null:
		return
	var c: Dictionary = heart.physiology.get("chamber_centroids", {})
	var s := motion_scale
	var lv := float(sim.get("lv_contractility", 1.0)) * s
	var rv := float(sim.get("rv_contractility", 1.0)) * s
	var la := float(sim.get("la_contractility", 1.0)) * s
	var ra := float(sim.get("ra_contractility", 1.0)) * s
	_set_chamber("heart_c_lv", c.get("LV", []), K_LV * v * lv)
	_set_chamber("heart_c_rv", c.get("RV", []), K_RV * v * rv)
	_set_chamber("heart_c_la", c.get("LA", []), K_LA * a * la)
	_set_chamber("heart_c_ra", c.get("RA", []), K_RA * a * ra)
	var ap := heart.get_landmark("apex")
	motion_uniforms["heart_apex"] = Vector4(ap.x, ap.y, ap.z, LONG_SHORTEN * v * lv)
	RenderingServer.global_shader_parameter_set("heart_apex", motion_uniforms["heart_apex"])

func _set_chamber(uniform_name: String, centroid, amount: float) -> void:
	var p := heart.get_landmark_from(centroid)
	motion_uniforms[uniform_name] = Vector4(p.x, p.y, p.z, amount)
	RenderingServer.global_shader_parameter_set(uniform_name, motion_uniforms[uniform_name])

## CPU version of the contraction + long-axis part of heart_offset() (heart_common.gdshaderinc).
## w = [wRA, wLA, wRV, wLV, LAD, RCA, attach]. Ignores remodelling/fibrillation (not used in Stage 3).
func motion_offset(p: Vector3, w: Array) -> Vector3:
	if w.size() < 7 or motion_uniforms.is_empty():
		return Vector3.ZERO
	var d := Vector3.ZERO
	var lv: Vector4 = motion_uniforms.get("heart_c_lv", Vector4.ZERO)
	var rv: Vector4 = motion_uniforms.get("heart_c_rv", Vector4.ZERO)
	var la: Vector4 = motion_uniforms.get("heart_c_la", Vector4.ZERO)
	var ra: Vector4 = motion_uniforms.get("heart_c_ra", Vector4.ZERO)
	d += (Vector3(lv.x, lv.y, lv.z) - p) * lv.w * float(w[3])
	d += (Vector3(rv.x, rv.y, rv.z) - p) * rv.w * float(w[2])
	d += (Vector3(la.x, la.y, la.z) - p) * la.w * float(w[1])
	d += (Vector3(ra.x, ra.y, ra.z) - p) * ra.w * float(w[0])
	var ap: Vector4 = motion_uniforms.get("heart_apex", Vector4.ZERO)
	var apex := Vector3(ap.x, ap.y, ap.z)
	var ax := heart.get_landmark("base") - apex
	var L := maxf(ax.length(), 1e-5)
	ax /= L
	var s := (p - apex).dot(ax) / L
	var bw := clampf(s, 0.0, 1.0) if s <= 1.0 else exp(-(s - 1.0) * 2.5)
	d -= ax * ap.w * bw
	return d * float(w[6])

## Static (per-condition) remodelling, ischaemia and markers, scaled by severity.
func _apply_static() -> void:
	var rm: Dictionary = sim.get("remodel", {})
	var k := severity
	RenderingServer.global_shader_parameter_set("heart_remodel", Vector4(
		float(rm.get("lv_wall_mm", 0.0)) * 0.001 * k, float(rm.get("septum_mm", 0.0)) * 0.001 * k,
		float(rm.get("lv_dilation", 0.0)) * k, float(rm.get("rv_dilation", 0.0)) * k))
	RenderingServer.global_shader_parameter_set("heart_remodel2", Vector4(
		float(rm.get("la_dilation", 0.0)) * k, float(rm.get("ra_dilation", 0.0)) * k, float(rm.get("lv_outer", 0.0)) * k, 0.0))
	var isc: Dictionary = sim.get("ischemia", {})
	RenderingServer.global_shader_parameter_set("heart_ischemia", Vector4(
		float(isc.get("lad", 0.0)) * k, float(isc.get("rca", 0.0)) * k,
		float(isc.get("lad", 0.0)) * k, float(isc.get("rca", 0.0)) * k))
	if heart:
		var vm := heart.get_material("valve_aortic")
		if vm is ShaderMaterial:
			(vm as ShaderMaterial).set_shader_parameter("calcification", float(sim.get("av_calcification", 0.0)) * k)
		heart.hide_all_markers()
		var mk: Dictionary = sim.get("marker", {})
		if not mk.is_empty():
			heart.show_marker(mk.get("name", ""), Color(mk.get("color", "#3a0606")))

func _update_phase(tau: float, r: float, rhythm: String) -> void:
	if rhythm == "vf":
		_phase_id = "vf"; _phase = "Ventricular fibrillation — no coordinated contraction"
		return
	var ts := _systole(r)
	if tau >= 0.0 and tau < 0.05:
		_phase_id = "ivc"; _phase = "Isovolumetric contraction"
	elif tau >= 0.05 and tau < ts:
		_phase_id = "ejection"; _phase = "Ventricular ejection"
	elif tau >= ts and tau < ts + _ivr(r):
		_phase_id = "ivr"; _phase = "Isovolumetric relaxation"
	elif _a_amt > 0.02:
		_phase_id = "atrial"; _phase = "Atrial systole (atrial kick)"
	else:
		_phase_id = "filling"; _phase = "Ventricular filling (diastole)"

func get_amounts() -> Vector2:
	return Vector2(_a_amt, _v_amt)

# ------------------------------------------------------------------ ECG synthesis (vector dipole)
func _g(t: float, c: float, s: float) -> float:
	var x := (t - c) / s
	return exp(-0.5 * x * x)

func _vec3(a, fallback: Vector3) -> Vector3:
	return Vector3(a[0], a[1], a[2]) if a is Array and a.size() >= 3 else fallback

## Unit direction and gain of a lead axis in the heart frame.
static func lead_axis(lead: String) -> Vector3:
	if FRONTAL_ANGLE.has(lead):
		var th := deg_to_rad(float(FRONTAL_ANGLE[lead]))
		return Vector3(cos(th), -sin(th), 0.0)
	var ph := deg_to_rad(float(PRECORDIAL_ANGLE.get(lead, 0.0)))
	return Vector3(cos(ph), -0.12, sin(ph)).normalized()

static func lead_gain(lead: String) -> float:
	if lead in ["aVR", "aVL", "aVF"]:
		return 0.866          # Goldberger leads: keeps aVF = II - I/2 consistent with Einthoven's law
	# precordial electrodes sit close to the heart: proximity raises V2-V4 amplitudes
	return float(PRECORDIAL_GAIN.get(lead, 1.0))

## Instantaneous cardiac dipole (mV-equivalent) at simulation time t.
func ecg_vector(t: float) -> Vector3:
	var ecg: Dictionary = sim.get("ecg", {})
	var k := severity
	var rhythm := get_rhythm()
	var h := Vector3.ZERO
	if rhythm == "vf":
		var a := 0.40 + 0.25 * sin(t * 0.9) + 0.15 * sin(t * 2.3 + 1.0)
		h.x = sin(TAU * 4.6 * t + 1.7 * sin(t * 0.7)) + 0.5 * sin(TAU * 6.1 * t + 0.5)
		h.y = -sin(TAU * 5.2 * t + 0.4) + 0.4 * sin(TAU * 3.1 * t + 2.0 * sin(t * 0.5))
		h.z = sin(TAU * 3.9 * t + 2.1) + 0.5 * sin(TAU * 6.7 * t + 1.1)
		return h * a * 0.75
	var r := rr()
	# --- atrial activity
	if rhythm == "af":
		h += Vector3(0.35, -0.30, 0.85) * 0.055 * sin(TAU * 5.3 * t + 0.6 * sin(t * 1.7))
		h += Vector3(-0.5, -0.4, 0.75) * 0.045 * sin(TAU * 6.9 * t + 1.3)
		h += Vector3(0.6, -0.7, 0.2) * 0.035 * sin(TAU * 6.1 * t + 0.4 * sin(t * 3.0))
	else:
		for ta in _a_beats:
			if ta > t - 0.25 and ta < t + 0.05:
				h += V_P_RA * 0.135 * _g(t, ta + 0.035, 0.019)
				h += V_P_LA * 0.120 * _g(t, ta + 0.068, 0.020)
	# --- ventricular activity
	var w := float(ecg.get("qrs_width", 1.0))
	var qs := 1.0 + (float(ecg.get("qrs_scale", 1.0)) - 1.0) * k
	var septal := 1.0 + (float(ecg.get("septal_scale", 1.0)) - 1.0) * k
	var lvh := float(ecg.get("lvh", 0.0)) * k
	var qv := _vec3(ecg.get("q", []), Vector3.ZERO) * k
	var stv := _vec3(ecg.get("st", []), Vector3.ZERO) * k
	var tdef := V_T * 0.36
	var tv_ := _vec3(ecg.get("t", []), tdef)
	tv_ = tdef.lerp(tv_, k) * (1.0 + (float(ecg.get("t_scale", 1.0)) - 1.0) * k)
	for i in _v_beats.size():
		var q := _v_beats[i]
		if q < t - 0.75 or q > t + 0.05:
			continue
		var x := t - q
		if _v_ect[i]:
			h += _ectopic_vector(x, r)
			continue
		var qt := _qt(r) * (1.0 + 0.15 * (w - 1.0))
		h += (V_SEPTAL * 0.30 * septal + qv) * _g(x, 0.013 * w, 0.0075 * w)
		h += (V_MAIN * 1.45 * qs + Vector3(0.55, -0.15, -0.82) * lvh) * _g(x, 0.041 * w, 0.0105 * w)
		h += V_TERM * 0.42 * qs * _g(x, 0.066 * w, 0.0095 * w)
		var tpk := qt * 0.72
		var ts := (0.055 if x < tpk else 0.038) * sqrt(r / 0.8) * (1.0 + 0.2 * (w - 1.0))
		h += tv_ * _g(x, tpk, ts)
		if stv != Vector3.ZERO:
			var a0 := 0.075 * w
			h += stv * smoothstep(a0 - 0.02, a0 + 0.01, x) * (1.0 - smoothstep(tpk - 0.02, tpk + 0.07, x))
	return h

## Wide ectopic complex: activation spreads slowly from the focus through working myocardium,
## so the dipole points from the focus toward the rest of the ventricles; repolarisation is discordant.
func _ectopic_vector(x: float, r: float) -> Vector3:
	var d: Vector3 = _ect_dir.get("vt" if get_rhythm() == "vt" else "pvc", Vector3(0, -1, 0))
	var d2 := (d + Vector3(0.35, 0.0, -0.2)).normalized()
	var h := d * 1.3 * _g(x, 0.050, 0.026) + d2 * 0.8 * _g(x, 0.105, 0.026)
	var qt := clampf(_qt(r) + 0.06, 0.26, 0.48)
	h -= d * 0.42 * _g(x, qt * 0.70, 0.05)
	h -= d * 0.10 * smoothstep(0.12, 0.15, x) * (1.0 - smoothstep(qt * 0.6, qt * 0.75, x))
	return h

## Simulated ECG value (mV) at simulation time t for any of the 12 standard leads.
func ecg_value(t: float, lead: String) -> float:
	return ecg_vector(t).dot(lead_axis(lead)) * lead_gain(lead) + 0.008 * sin(TAU * 0.3 * t)

func project(h: Vector3, lead: String) -> float:
	return h.dot(lead_axis(lead)) * lead_gain(lead)

## Beats inside [t0, t1]: Array of {"t": onset, "kind": "p" | "qrs" | "ectopic", "conducted": bool}
func get_beats_between(t0: float, t1: float) -> Array:
	var out := []
	for i in _a_beats.size():
		if _a_beats[i] >= t0 and _a_beats[i] <= t1:
			out.append({"t": _a_beats[i], "kind": "p", "conducted": _a_cond[i]})
	for i in _v_beats.size():
		if _v_beats[i] >= t0 and _v_beats[i] <= t1:
			out.append({"t": _v_beats[i], "kind": "ectopic" if _v_ect[i] else "qrs", "conducted": true})
	out.sort_custom(func(a, b): return a["t"] < b["t"])
	return out

func get_qrs_onsets(t0: float, t1: float) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	for q in _v_beats:
		if q >= t0 and q <= t1:
			out.append(q)
	return out

## Interval summary for the current rate / rhythm (seconds).
func get_intervals() -> Dictionary:
	var r := rr()
	var w := float((sim.get("ecg", {}) as Dictionary).get("qrs_width", 1.0))
	var rhythm := get_rhythm()
	var ect := rhythm == "vt"
	var qrs := 0.15 if ect else 0.088 * w
	var qt := (clampf(_qt(r) + 0.06, 0.26, 0.48) if ect else _qt(r) * (1.0 + 0.15 * (w - 1.0)))
	var pr := _pr(r) if rhythm in ["sinus", "pvc"] else -1.0
	var rrs := PackedFloat32Array()
	var on := get_qrs_onsets(sim_time - 8.0, sim_time)
	for i in range(1, on.size()):
		rrs.append(on[i] - on[i - 1])
	return {"pr": pr, "qrs": qrs, "qt": qt, "qtc": qt / sqrt(r), "rr": r, "recent_rr": rrs}

# ------------------------------------------------------------------ Stage 2: electrophysiology state
func _load_conduction() -> void:
	if not FileAccess.file_exists(CONDUCTION_PATH):
		return
	var d = JSON.parse_string(FileAccess.get_file_as_string(CONDUCTION_PATH))
	if not (d is Dictionary):
		return
	_ep = d
	var src: Dictionary = d.get("sources", {})
	var centre := Vector3.ZERO
	var vs: Array = src.get("ventricular", [])
	for v in vs:
		centre += Vector3(v[0], v[1], v[2])
	centre /= maxf(vs.size(), 1)
	# shift the "centre of ventricular mass" toward the LV free wall (most myocardium lies there)
	centre += Vector3(0.006, 0.004, -0.008)
	for kind in ["pvc", "vt"]:
		var f := _vec3(src.get(kind + "_focus", []), Vector3.ZERO)
		if f != Vector3.ZERO:
			_ect_dir[kind] = (centre - f).normalized()

func his_start() -> float:
	return float((_ep.get("sources", {}) as Dictionary).get("his_start", -0.034))

func av_entry() -> float:
	return float(_ep.get("t_av_entry", 0.056))

func _av_delay() -> float:
	return maxf(_pr(rr()) - av_entry() + his_start(), 0.03)

func _is_ectopic_at(onset: float) -> bool:
	var i := _v_beats.find(onset)
	return i >= 0 and _v_ect[i]

func _ref_qrs(t: float) -> int:
	## Index of the ventricular beat the conduction system is currently working on.
	var nxt := -1
	var last := -1
	for i in _v_beats.size():
		if _v_beats[i] <= t:
			last = i
		elif nxt < 0:
			nxt = i
	var lead := -his_start() + _av_delay() + 0.015
	if nxt >= 0 and _v_beats[nxt] - t < lead and not _v_ect[nxt]:
		return nxt
	if nxt >= 0 and _v_ect[nxt] and _v_beats[nxt] - t < 0.004:
		return nxt
	return last

func _update_ep() -> void:
	var t := sim_time
	var rhythm := get_rhythm()
	var ia := -1
	for i in _a_beats.size():
		if _a_beats[i] <= t:
			ia = i
	var ta := t - _a_beats[ia] if ia >= 0 else 10.0
	var a_cond := _a_cond[ia] if ia >= 0 else false
	var iv := _ref_qrs(t)
	var tv := t - _v_beats[iv] if iv >= 0 else 10.0
	var ect := _v_ect[iv] if iv >= 0 else false
	var d := _av_delay()
	var s := -1.0
	if rhythm == "vf":
		ta = 10.0; tv = 10.0
	elif iv >= 0 and not ect and rhythm != "chb" and tv < 0.2:
		s = (tv - (his_start() - d)) / d
	if (s < 0.0 or s > 1.2) and ia >= 0 and not a_cond and rhythm != "af":
		# non-conducted P wave: the impulse dies in the (refractory or blocked) AV node
		var sb := (ta - av_entry()) / 0.07
		if sb >= 0.0 and sb < 1.0:
			s = minf(sb, 0.42)
	var apd := clampf(_qt(rr()) - 0.035, 0.16, 0.45)
	var mode := float(ep_overlay)
	if rhythm == "vf":
		mode = 0.0
	RenderingServer.global_shader_parameter_set("heart_ep", Vector4(ta, tv, s, mode))
	RenderingServer.global_shader_parameter_set("heart_ep2", Vector4(1.0 if rhythm == "af" else 0.0, 1.0 if ect else 0.0, t, apd))
	_ep_state = {"ta": ta, "tv": tv, "av": s, "ectopic": ect, "a_conducted": a_cond, "rhythm": rhythm}

## Current electrophysiology state: ta (s since SA firing), tv (s rel. QRS onset), av (AV-node fraction),
## ectopic (bool), a_conducted (bool).
func get_ep_state() -> Dictionary:
	return _ep_state

## Pushes the conduction-system geometry (sources) to the shader globals. Call once from Stage 2.
func setup_ep_sources() -> void:
	var src: Dictionary = _ep.get("sources", {})
	var at: Array = src.get("atrial", [])
	if at.size() >= 2:
		RenderingServer.global_shader_parameter_set("heart_ep_sa", Vector4(at[0][0], at[0][1], at[0][2], 1.35))
		RenderingServer.global_shader_parameter_set("heart_ep_bb", Vector4(at[1][0], at[1][1], at[1][2], at[1][3]))
	var vs: Array = src.get("ventricular", [])
	for i in 6:
		var v: Array = vs[i] if i < vs.size() else [0, 0, 0, 10]
		RenderingServer.global_shader_parameter_set("heart_ep_v%d" % i, Vector4(v[0], v[1], v[2], v[3]))
	_update_focus()

func _update_focus() -> void:
	var src: Dictionary = _ep.get("sources", {})
	var f := _vec3(src.get(("vt" if get_rhythm() == "vt" else "pvc") + "_focus", []), Vector3.ZERO)
	RenderingServer.global_shader_parameter_set("heart_ep_focus", Vector4(f.x, f.y, f.z, 0.62))

## Name of the ECG component at time t: "P", "PR", "QRS", "ST", "T", "TP", "F" (AF baseline) or "VF".
func get_ecg_segment(t: float) -> String:
	var rhythm := get_rhythm()
	if rhythm == "vf":
		return "VF"
	var r := rr()
	var w := float((sim.get("ecg", {}) as Dictionary).get("qrs_width", 1.0))
	var last_q := -1e9
	var last_ect := false
	var next_q := 1e9
	for i in _v_beats.size():
		if _v_beats[i] <= t:
			last_q = _v_beats[i]; last_ect = _v_ect[i]
		elif next_q > 1e8:
			next_q = _v_beats[i]
	var ta := -1e9
	for a in _a_beats:
		if a <= t:
			ta = a
	var x := t - last_q
	var qrs := 0.15 if last_ect else 0.088 * w
	var qt := clampf(_qt(r) + 0.06, 0.26, 0.48) if last_ect else _qt(r) * (1.0 + 0.15 * (w - 1.0))
	if x >= 0.0 and x < qrs:
		return "QRS"
	if rhythm != "af" and t - ta >= 0.0 and t - ta < 0.10:
		return "P"
	if x >= qrs and x < qt * 0.72 - 0.085:
		return "ST"
	if x >= qrs and x < qt + 0.01:
		return "T"
	if rhythm != "af" and ta > last_q and next_q - t < 0.12 and t - ta >= 0.10:
		return "PR"
	return "F" if rhythm == "af" else "TP"

# ------------------------------------------------------------------ haemodynamics (illustrative)
func get_hemodynamics() -> Dictionary:
	var h: Dictionary = sim.get("hemo", {})
	var rhythm := get_rhythm()
	if rhythm == "vf":
		return {"edv": 0, "esv": 0, "sv": 0, "ef": 0, "co": 0.0, "bp": "No pulse", "note": h.get("note", "")}
	var normal := get_condition_data("normal").get("sim", {}).get("hemo", {}) as Dictionary
	var k := severity
	var edv := lerpf(float(normal.get("edv", 120)), float(h.get("edv", 120)), k)
	var esv := lerpf(float(normal.get("esv", 50)), float(h.get("esv", 50)), k)
	# Shorter diastole at high rates reduces filling (simplified exponential filling model).
	var r := rr()
	var td := maxf(r - _systole(r) - _ivr(r), 0.02)
	var td72 := 60.0 / 72.0 - _systole(60.0 / 72.0) - _ivr(60.0 / 72.0)
	var fill := (1.0 - exp(-td / 0.16)) / (1.0 - exp(-td72 / 0.16))
	fill = clampf(fill, 0.5, 1.12)
	var ef := (edv - esv) / maxf(edv, 1.0)
	var edv_eff := edv * lerpf(1.0, fill, 0.85)
	var sv := edv_eff * ef
	var sbp := lerpf(float(normal.get("sbp", 120)), float(h.get("sbp", 120)), k)
	var dbp := lerpf(float(normal.get("dbp", 80)), float(h.get("dbp", 80)), k)
	return {"edv": edv_eff, "esv": edv_eff - sv, "sv": sv, "ef": ef * 100.0, "co": sv * hr / 1000.0,
		"bp": "%d/%d" % [int(round(sbp)), int(round(dbp))], "note": h.get("note", "")}
