## BloodFlow (Stage 1)
## Animated blood inside the beating heart: thousands of small blood "cells" stream along centrelines
## through the venae cavae / pulmonary veins → atria → AV valves → ventricles → semilunar valves →
## pulmonary trunk / aorta (data/physiology/blood_paths.json, built from the heart model by
## tools/asset_pipeline/build_blood_paths.py).
## Flow is gated by the real valve state of CardiacEngine: blood collects in the atria while the AV valves
## are shut, pours into the ventricles when they open (early filling + atrial kick), and is ejected only
## while the aortic / pulmonary valves are open; arterial run-off slows in diastole. So the pumping is
## always in sync with the ECG, the valves and the wall motion. Colours follow the teaching convention:
## oxygen-poor blood blue-violet, oxygen-rich blood red. Educational simplification (no fluid dynamics).
class_name BloodFlow
extends Node3D

const DATA := "res://data/physiology/blood_paths.json"
const STEP := 0.002
const COUNT_RIGHT := 520
const COUNT_LEFT := 620
## visual speeds (m/s at 1× time) per gate: venous, AV inflow, ventricular ejection, artery systole / diastole
const V_VENOUS := 0.035
const V_FILL := 0.16
const V_EJECT := 0.42
const V_ART_SYS := 0.34
const V_ART_DIA := 0.05

var engine: CardiacEngine
var _paths: Array = []          # {side, pts: PackedVector3Array, gate: PackedByteArray, r: PackedFloat32Array, n1, n2: PackedVector3Array, len}
var _p_path := PackedInt32Array()
var _p_s := PackedFloat32Array()
var _p_off := PackedVector2Array()
var _p_spd := PackedFloat32Array()
var _p_hold := PackedFloat32Array()
var _p_basis: Array[Basis] = []
var _mm: MultiMesh
var _mmi: MultiMeshInstance3D
var _av := 0.0
var _sl := 0.0
var _side_paths := {"right": [], "left": []}

func _ready() -> void:
	var d = JSON.parse_string(FileAccess.get_file_as_string(DATA)) if FileAccess.file_exists(DATA) else null
	if not (d is Dictionary):
		push_error("BloodFlow: missing %s" % DATA)
		return
	for p in d["paths"]:
		_paths.append(_resample(p))
		_side_paths[p["side"]].append(_paths.size() - 1)
	_build_multimesh()
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	var total := COUNT_RIGHT + COUNT_LEFT
	for i in total:
		var side := "right" if i < COUNT_RIGHT else "left"
		var opts: Array = _side_paths[side]
		var pi: int = opts[rng.randi() % opts.size()]
		_p_path.append(pi)
		_p_s.append(rng.randf() * float(_paths[pi]["len"]))
		var a := rng.randf() * TAU
		var rr := sqrt(rng.randf()) * 0.85
		_p_off.append(Vector2(cos(a), sin(a)) * rr)
		_p_spd.append(rng.randf_range(0.75, 1.25))
		_p_hold.append(rng.randf_range(0.0, 0.018))
		_p_basis.append(Basis(Vector3(rng.randf_range(-1, 1), rng.randf_range(-1, 1), rng.randf_range(-1, 1)).normalized(), rng.randf() * TAU))
		var col := Color(0.30, 0.33, 0.85) if side == "right" else Color(0.86, 0.10, 0.10)
		col = col.lerp(col.darkened(0.35), rng.randf() * 0.6)
		_mm.set_instance_color(i, col)
	_update(0.0)

func _build_multimesh() -> void:
	_mm = MultiMesh.new()
	_mm.transform_format = MultiMesh.TRANSFORM_3D
	_mm.use_colors = true
	var s := SphereMesh.new()
	s.radius = 0.0011; s.height = 0.0012; s.radial_segments = 10; s.rings = 4   # biconcave-ish flattened disc
	_mm.mesh = s
	_mm.instance_count = COUNT_RIGHT + COUNT_LEFT
	_mmi = MultiMeshInstance3D.new()
	_mmi.multimesh = _mm
	_mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = 0.35
	m.emission_enabled = true
	m.emission = Color(0.25, 0.04, 0.04)
	m.emission_energy_multiplier = 0.6
	m.render_priority = 2
	_mmi.material_override = m
	_mmi.extra_cull_margin = 0.2
	add_child(_mmi)

## Catmull-Rom resample of one centreline to STEP spacing with gate / radius per sample and a frame.
func _resample(p: Dictionary) -> Dictionary:
	var src := PackedVector3Array()
	for q in p["points"]:
		src.append(Vector3(q[0], q[1], q[2]))
	var g: Array = p["gate"]; var r: Array = p["r"]
	var pts := PackedVector3Array(); var gate := PackedByteArray(); var rad := PackedFloat32Array()
	for i in src.size() - 1:
		var p0 := src[maxi(i - 1, 0)]; var p1 := src[i]; var p2 := src[i + 1]; var p3 := src[mini(i + 2, src.size() - 1)]
		var n := maxi(int(p1.distance_to(p2) / STEP), 1)
		for k in n:
			var t := float(k) / n
			pts.append(_catmull(p0, p1, p2, p3, t))
			gate.append(int(g[i + 1]))
			rad.append(lerpf(float(r[i]), float(r[i + 1]), t))
	pts.append(src[src.size() - 1]); gate.append(int(g[g.size() - 1])); rad.append(float(r[r.size() - 1]))
	var n1 := PackedVector3Array(); var n2 := PackedVector3Array()
	var up := Vector3.UP
	for i in pts.size():
		var t := (pts[mini(i + 1, pts.size() - 1)] - pts[maxi(i - 1, 0)]).normalized()
		var a := t.cross(up)
		if a.length() < 0.2: a = t.cross(Vector3.RIGHT)
		a = a.normalized()
		n1.append(a); n2.append(t.cross(a).normalized())
	return {"side": p["side"], "pts": pts, "gate": gate, "r": rad, "n1": n1, "n2": n2, "len": float(pts.size() - 1) * STEP}

static func _catmull(p0: Vector3, p1: Vector3, p2: Vector3, p3: Vector3, t: float) -> Vector3:
	var t2 := t * t; var t3 := t2 * t
	return 0.5 * ((2.0 * p1) + (-p0 + p2) * t + (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * t2 + (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * t3)

func _process(delta: float) -> void:
	if not visible or _paths.is_empty():
		return
	var dt := delta
	if engine:
		dt *= engine.speed if (engine.beating and engine.playing) else 0.0
		var vs := engine.get_valve_states()
		var k := 1.0 - exp(-14.0 * delta)
		_av = lerpf(_av, 1.0 if vs.get("av", false) else 0.0, k)
		_sl = lerpf(_sl, 1.0 if vs.get("sl", false) else 0.0, k)
	_update(dt)

func _update(dt: float) -> void:
	for i in _p_s.size():
		var P: Dictionary = _paths[_p_path[i]]
		var gate: PackedByteArray = P["gate"]
		var n := gate.size()
		var s := _p_s[i]
		var idx := clampi(int(s / STEP), 0, n - 1)
		var g := gate[idx]
		var v := V_VENOUS
		match g:
			1: v = V_FILL * _av
			2: v = V_EJECT * _sl
			3: v = lerpf(V_ART_DIA, V_ART_SYS, _sl)
		# a closed valve ahead stops the blood that reaches it (it collects in the chamber)
		var look := clampi(idx + 1, 0, n - 1)
		var ahead := gate[look]
		if ahead != g:
			if (ahead == 1 and _av < 0.5) or (ahead == 2 and _sl < 0.5):
				v = 0.0
		var ns := s + v * dt * _p_spd[i]
		# stagger the queue at a closed valve so the cells fill the chamber instead of one point
		var nidx := clampi(int(ns / STEP), 0, n - 1)
		if gate[nidx] != g:
			var shut := (gate[nidx] == 1 and _av < 0.5) or (gate[nidx] == 2 and _sl < 0.5)
			if shut:
				ns = minf(ns, float(nidx) * STEP - _p_hold[i])
		if ns >= float(P["len"]):
			var opts: Array = _side_paths[P["side"]]
			_p_path[i] = opts[(i * 7 + int(ns * 1000.0)) % opts.size()]
			ns = fmod(ns, 0.004)
			P = _paths[_p_path[i]]
		_p_s[i] = ns
		var j := clampi(int(ns / STEP), 0, (P["pts"] as PackedVector3Array).size() - 1)
		var o := _p_off[i] * float((P["r"] as PackedFloat32Array)[j])
		var pos: Vector3 = (P["pts"] as PackedVector3Array)[j] + (P["n1"] as PackedVector3Array)[j] * o.x + (P["n2"] as PackedVector3Array)[j] * o.y
		_mm.set_instance_transform(i, Transform3D(_p_basis[i], pos))
