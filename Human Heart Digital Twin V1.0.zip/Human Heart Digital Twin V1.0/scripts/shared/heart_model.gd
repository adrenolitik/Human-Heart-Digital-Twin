## HeartModel
## Reusable anatomical heart (shared by Stage 1 and Stage 2).
## Loads the optimized GLB, applies tissue materials from data, builds picking colliders and
## exposes an API for visibility / highlight / isolate / cutaway / explode / scalpel removal,
## disease markers and anatomical landmarks. The beat and disease remodelling are driven by
## CardiacEngine through global shader uniforms (see assets/shaders/heart_common.gdshaderinc).
class_name HeartModel
extends Node3D

signal model_loaded(part_count: int)
signal part_visibility_changed(part_id: String, visible: bool)
signal removed_changed(count: int)

const PICK_LAYER := 2
const MATERIAL_DIR := "res://assets/materials/"
const MANIFEST_PATH := "res://assets/models/heart/heart_manifest.json"
const WALL_MATERIALS := ["myocardium", "septum", "papillary"]
## Explode factor per group (how far a part travels relative to its distance from the centre).
## Parts that must stay joined when the heart is exploded (vessel trees move as one piece, so branches are
## never torn apart into floating, cut-looking segments).
const EXPLODE_CLUSTERS := {
	"aorta": ["aortic_root", "ascending_aorta", "aortic_arch", "descending_aorta", "aortic_arch_branches"],
	"pulmonary": ["pulmonary_trunk_root", "pulmonary_arteries"],
	"coronary_arteries": ["rca", "rca_marginal", "rca_pda", "rca_posterolateral", "rca_septal", "left_main", "lad", "lcx", "lad_septal"],
	"cardiac_veins": ["coronary_sinus", "great_cardiac_vein", "middle_cardiac_vein", "anterior_cardiac_veins", "posterior_lv_veins"],
}
const EXPLODE_FACTOR := {
	"chambers": 1.0, "septa": 0.35, "valves": 0.55, "papillary_muscles": 0.6,
	"great_vessels": 0.9, "coronary_arteries": 1.35, "cardiac_veins": 1.35,
}

@export_file("*.glb", "*.gltf") var model_path := "res://assets/models/heart/heart.glb"
@export_file("*.json") var parts_data_path := "res://data/anatomy/heart_parts.json"
@export var build_colliders := true

var parts := {}          # id -> {mesh, body, data, visible, rest: Vector3, removed: bool}
var groups := []
var physiology := {}     # landmarks from the manifest (model space, metres)
var label_anchors := {}  # id -> Vector3 (model space)
var _materials := {}
var _ghost_mat: Material
var _highlight_mat: Material
var _hover_mat: Material
var _ghost_mat_wall: Material
var _highlight_mat_wall: Material
var _hover_mat_wall: Material
var _selected := ""
var _hovered := ""
var _isolated := PackedStringArray()
var _model_root: Node3D
var _explode := 0.0
var _removed_stack: Array[String] = []
var _markers := {}       # name -> MeshInstance3D
var _cut_enabled := false
var _cut_plane := Plane(Vector3(0, 0, 1), 0.0)

func _ready() -> void:
	_ghost_mat = _load_material("ghost")
	_highlight_mat = _load_material("highlight")
	_hover_mat = _load_material("hover")
	# Wall variants: the overlay must follow the same endocardial thickening as the tissue.
	_ghost_mat_wall = _wall_variant(_ghost_mat)
	_highlight_mat_wall = _wall_variant(_highlight_mat)
	_hover_mat_wall = _wall_variant(_hover_mat)
	reset_global_state()
	_load_manifest()
	_load_model()
	var app := get_node_or_null("/root/AppState")
	if app:
		apply_style(app.heart_style)
		app.heart_style_changed.connect(apply_style)

## Applies a heart colour style (data/anatomy/tissue_styles.json) to the shared tissue materials.
func apply_style(style_id: String) -> void:
	var app := get_node_or_null("/root/AppState")
	if app == null:
		return
	var st: Dictionary = app.get_heart_style(style_id)
	var mats: Dictionary = st.get("materials", {})
	var noise: Texture2D = load("res://assets/textures/tissue/noise_fbm.png") if ResourceLoader.exists("res://assets/textures/tissue/noise_fbm.png") else null
	for mat_name in mats:
		var m := _load_material(mat_name)
		if not (m is ShaderMaterial):
			continue
		(m as ShaderMaterial).set_shader_parameter("noise_tex", noise)
		# parameters a style does not set fall back to "off"
		for k in ["mottle_amount", "trabecula_amount"]:
			if not (mats[mat_name] as Dictionary).has(k):
				(m as ShaderMaterial).set_shader_parameter(k, 0.0)
		var params: Dictionary = mats[mat_name]
		for k in params:
			var v = params[k]
			if v is Array:
				(m as ShaderMaterial).set_shader_parameter(k, Color(v[0], v[1], v[2], v[3] if v.size() > 3 else 1.0))
			else:
				(m as ShaderMaterial).set_shader_parameter(k, float(v))

# ------------------------------------------------------------------ loading
func _load_manifest() -> void:
	var m := _read_json(MANIFEST_PATH)
	physiology = m.get("physiology", {})
	for p in m.get("parts", []):
		var a: Array = p.get("label_anchor", [])
		if a.size() == 3:
			label_anchors[p["id"]] = Vector3(a[0], a[1], a[2])
	reset_physiology_uniforms()

## Writes the landmark positions into the global shader uniforms and clears all motion/disease values.
## Clears every per-session global shader value (cutaway, motion, disease, EP overlay) and runtime
## values written into the shared tissue materials, so a new scene always starts from the normal heart.
static func reset_global_state() -> void:
	RenderingServer.global_shader_parameter_set("heart_clip_enabled", 0.0)
	for n in ["heart_remodel", "heart_remodel2", "heart_ischemia", "heart_fib", "heart_ep", "heart_ep2"]:
		RenderingServer.global_shader_parameter_set(n, Vector4.ZERO)
	for f in ["valve", "valve_aortic"]:
		var path := "res://assets/materials/%s.tres" % f
		if ResourceLoader.exists(path):
			var m = load(path)
			if m is ShaderMaterial:
				(m as ShaderMaterial).set_shader_parameter("calcification", 0.0)

func reset_physiology_uniforms() -> void:
	var c: Dictionary = physiology.get("chamber_centroids", {})
	for k in ["RA", "LA", "RV", "LV"]:
		var v := get_landmark_from(c.get(k, []))
		RenderingServer.global_shader_parameter_set("heart_c_" + k.to_lower(), Vector4(v.x, v.y, v.z, 0.0))
	var ap := get_landmark("apex")
	var ba := get_landmark("base")
	RenderingServer.global_shader_parameter_set("heart_apex", Vector4(ap.x, ap.y, ap.z, 0.0))
	RenderingServer.global_shader_parameter_set("heart_base", Vector4(ba.x, ba.y, ba.z, 0.0))
	for n in ["heart_remodel", "heart_remodel2", "heart_ischemia", "heart_fib", "heart_ep", "heart_ep2"]:
		RenderingServer.global_shader_parameter_set(n, Vector4.ZERO)

func get_landmark_from(a) -> Vector3:
	if a is Array and a.size() == 3:
		return Vector3(a[0], a[1], a[2])
	return Vector3.ZERO

## Landmark in model space: apex, base, mitral_center, tricuspid_center, aortic_valve_center,
## pulmonary_valve_center, heart_center, or chamber centroid "RA"/"LA"/"RV"/"LV".
func get_landmark(name_: String) -> Vector3:
	if physiology.has(name_):
		return get_landmark_from(physiology[name_])
	var c: Dictionary = physiology.get("chamber_centroids", {})
	if c.has(name_):
		return get_landmark_from(c[name_])
	var mk: Dictionary = physiology.get("markers", {})
	if mk.has(name_):
		return get_landmark_from(mk[name_])
	return Vector3.ZERO

func get_landmark_world(name_: String) -> Vector3:
	return global_transform * get_landmark(name_)

func _load_model() -> void:
	var data := _read_json(parts_data_path)
	groups = data.get("groups", [])
	var by_id := {}
	for p in data.get("parts", []):
		by_id[p["id"]] = p
	if not ResourceLoader.exists(model_path):
		push_error("HeartModel: model not found at %s" % model_path)
		model_loaded.emit(0)
		return
	var scene := load(model_path) as PackedScene
	if scene == null:
		push_error("HeartModel: could not load %s" % model_path)
		model_loaded.emit(0)
		return
	_model_root = scene.instantiate() as Node3D
	_model_root.name = "Model"
	add_child(_model_root)
	for mi in _model_root.find_children("*", "MeshInstance3D", true, false):
		var m := mi as MeshInstance3D
		var id := String(m.name)
		var info: Dictionary = by_id.get(id, {"id": id, "name": id.capitalize(), "group": "other", "material": "myocardium"})
		if not by_id.has(id):
			push_warning("HeartModel: mesh '%s' has no entry in %s" % [id, parts_data_path])
		var mat_name: String = info.get("material", "myocardium")
		m.material_override = _load_material(mat_name)
		m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
		# The beat deforms vertices in the shader; enlarge the culling box so parts never pop out.
		m.extra_cull_margin = 0.03
		var body: StaticBody3D = null
		if build_colliders and m.mesh:
			body = StaticBody3D.new()
			body.name = "Pick_" + id
			body.collision_layer = PICK_LAYER
			body.collision_mask = 0
			body.set_meta("part_id", id)
			var cs := CollisionShape3D.new()
			cs.shape = m.mesh.create_trimesh_shape()
			body.add_child(cs)
			m.add_child(body)
		parts[id] = {"mesh": m, "body": body, "data": info, "visible": true, "rest": m.position, "removed": false}
	for id in by_id:
		if not parts.has(id):
			push_warning("HeartModel: data entry '%s' has no mesh in the model" % id)
	model_loaded.emit(parts.size())

func _load_material(mat_name: String) -> Material:
	if _materials.has(mat_name):
		return _materials[mat_name]
	var path := MATERIAL_DIR + mat_name + ".tres"
	var mat: Material = null
	if ResourceLoader.exists(path):
		mat = load(path)
	if mat == null:
		push_warning("HeartModel: material '%s' missing, using fallback" % mat_name)
		var sm := StandardMaterial3D.new()
		sm.albedo_color = Color(0.6, 0.2, 0.2)
		mat = sm
	_materials[mat_name] = mat
	return mat

func _wall_variant(m: Material) -> Material:
	if m is ShaderMaterial:
		var d := (m as ShaderMaterial).duplicate() as ShaderMaterial
		d.set_shader_parameter("is_wall", 1.0)
		return d
	return m

func _is_wall(id: String) -> bool:
	return parts.has(id) and String(parts[id]["data"].get("material", "")) in WALL_MATERIALS

func _ov(id: String, kind: String) -> Material:
	var w := _is_wall(id)
	match kind:
		"ghost": return _ghost_mat_wall if w else _ghost_mat
		"highlight": return _highlight_mat_wall if w else _highlight_mat
		_: return _hover_mat_wall if w else _hover_mat

func get_material(mat_name: String) -> Material:
	return _load_material(mat_name)

func _read_json(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		push_error("HeartModel: data file missing: %s" % path)
		return {}
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
	return parsed if parsed is Dictionary else {}

# ------------------------------------------------------------------ queries
func has_part(id: String) -> bool:
	return parts.has(id)

func get_part_ids() -> PackedStringArray:
	return PackedStringArray(parts.keys())

func get_part_info(id: String) -> Dictionary:
	return parts[id]["data"] if parts.has(id) else {}

func get_group_name(group_id: String) -> String:
	for g in groups:
		if g["id"] == group_id:
			return g["name"]
	return group_id

func get_parts_in_group(group_id: String) -> PackedStringArray:
	var out := PackedStringArray()
	for id in parts:
		if parts[id]["data"].get("group", "") == group_id:
			out.append(id)
	return out

func is_part_visible(id: String) -> bool:
	return parts.has(id) and parts[id]["visible"] and not parts[id]["removed"]

func get_part_aabb(id: String) -> AABB:
	if not parts.has(id):
		return AABB()
	var m: MeshInstance3D = parts[id]["mesh"]
	return m.global_transform * m.get_aabb()

func get_model_aabb() -> AABB:
	var box := AABB()
	var first := true
	for id in parts:
		var m: MeshInstance3D = parts[id]["mesh"]
		var b: AABB = global_transform * (_model_root.transform * (Transform3D(Basis(), parts[id]["rest"]) * m.get_aabb()))
		box = b if first else box.merge(b)
		first = false
	return box

## World position used for 3D labels (follows explode offsets).
func get_label_anchor_world(id: String) -> Vector3:
	if not parts.has(id):
		return Vector3.ZERO
	var m: MeshInstance3D = parts[id]["mesh"]
	return m.global_transform * label_anchors.get(id, m.get_aabb().get_center())

func part_from_collider(collider: Object) -> String:
	if collider and collider.has_meta("part_id"):
		return String(collider.get_meta("part_id"))
	return ""

func get_total_triangles() -> int:
	var t := 0
	for id in parts:
		t += int(parts[id]["data"].get("triangles", 0))
	return t

# ------------------------------------------------------------------ visibility / emphasis
func set_part_visible(id: String, vis: bool) -> void:
	if not parts.has(id):
		return
	parts[id]["visible"] = vis
	_apply_visibility(id)
	part_visibility_changed.emit(id, vis)

func _apply_visibility(id: String) -> void:
	var on: bool = parts[id]["visible"] and not parts[id]["removed"]
	(parts[id]["mesh"] as MeshInstance3D).visible = on
	var body: StaticBody3D = parts[id]["body"]
	if body:
		var keep := _isolated.is_empty() or _isolated.has(id)
		body.collision_layer = PICK_LAYER if (on and keep) else 0

func set_group_visible(group_id: String, vis: bool) -> void:
	for id in get_parts_in_group(group_id):
		set_part_visible(id, vis)

func show_all() -> void:
	for id in parts:
		set_part_visible(id, true)

func set_selected(id: String) -> void:
	if _selected != "" and parts.has(_selected):
		(parts[_selected]["mesh"] as MeshInstance3D).material_overlay = _ov(_selected, "hover") if _selected == _hovered else null
	_selected = id if parts.has(id) else ""
	if _selected != "":
		(parts[_selected]["mesh"] as MeshInstance3D).material_overlay = _ov(_selected, "highlight")

func get_selected() -> String:
	return _selected

func set_hovered(id: String) -> void:
	if id == _hovered:
		return
	if _hovered != "" and parts.has(_hovered) and _hovered != _selected:
		(parts[_hovered]["mesh"] as MeshInstance3D).material_overlay = null
	_hovered = id if parts.has(id) else ""
	if _hovered != "" and _hovered != _selected:
		(parts[_hovered]["mesh"] as MeshInstance3D).material_overlay = _ov(_hovered, "hover")

## Isolate: listed parts keep their tissue material; the others become translucent context
## and are excluded from picking. Empty array = no isolation.
func isolate(ids: PackedStringArray) -> void:
	_isolated = ids
	for id in parts:
		var m: MeshInstance3D = parts[id]["mesh"]
		var keep := ids.is_empty() or ids.has(id)
		m.material_override = _load_material(parts[id]["data"].get("material", "myocardium")) if keep else _ov(id, "ghost")
		m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if keep else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_apply_visibility(id)

func get_isolated() -> PackedStringArray:
	return _isolated

func reset_view_state() -> void:
	isolate(PackedStringArray())
	restore_all_removed(false)
	show_all()
	set_selected("")
	set_hovered("")
	set_cutaway(false)
	set_explode(0.0)

# ------------------------------------------------------------------ cutaway
func set_cutaway(enabled: bool, plane := Plane(Vector3(0, 0, 1), 0.0)) -> void:
	RenderingServer.global_shader_parameter_set("heart_clip_enabled", 1.0 if enabled else 0.0)
	RenderingServer.global_shader_parameter_set("heart_clip_plane", Vector4(plane.normal.x, plane.normal.y, plane.normal.z, plane.d))
	_cut_enabled = enabled
	_cut_plane = plane

func is_cut_enabled() -> bool:
	return _cut_enabled

func get_cut_plane() -> Plane:
	return _cut_plane

func is_point_clipped(world_point: Vector3) -> bool:
	return _cut_enabled and _cut_plane.is_point_over(world_point)

# ------------------------------------------------------------------ explode
## 0 = assembled, 1 = fully exploded. Parts move away from the heart centre along the line
## through their own centre, scaled per anatomical group.
func set_explode(amount: float) -> void:
	_explode = clampf(amount, 0.0, 1.0)
	var hc := get_landmark("heart_center")
	var cluster_of := {}
	var cluster_box := {}
	for cname in EXPLODE_CLUSTERS:
		for pid in EXPLODE_CLUSTERS[cname]:
			if parts.has(pid):
				cluster_of[pid] = cname
				var bb: AABB = (parts[pid]["mesh"] as MeshInstance3D).get_aabb()
				cluster_box[cname] = bb if not cluster_box.has(cname) else (cluster_box[cname] as AABB).merge(bb)
	for id in parts:
		var m: MeshInstance3D = parts[id]["mesh"]
		var c := m.get_aabb().get_center()
		var f: float = EXPLODE_FACTOR.get(parts[id]["data"].get("group", ""), 1.0)
		if cluster_of.has(id):
			var cn: String = cluster_of[id]
			c = (cluster_box[cn] as AABB).get_center()
			# coronary trees lift off the front, veins off the back, as whole trees
			if cn == "coronary_arteries": c = hc + Vector3(0.0, 0.0, 0.025)
			elif cn == "cardiac_veins": c = hc + Vector3(0.0, -0.01, -0.025)
			f = 1.0
		var dir := c - hc
		if dir.length() < 0.004:
			dir = Vector3(0, 1, 0) * 0.004
		m.position = parts[id]["rest"] + dir * f * _explode * 1.15

func get_explode() -> float:
	return _explode

# ------------------------------------------------------------------ scalpel (remove with undo)
func remove_part(id: String, animated := true) -> void:
	if not parts.has(id) or parts[id]["removed"]:
		return
	parts[id]["removed"] = true
	_removed_stack.append(id)
	if id == _selected:
		set_selected("")
	if id == _hovered:
		set_hovered("")
	var m: MeshInstance3D = parts[id]["mesh"]
	var body: StaticBody3D = parts[id]["body"]
	if body:
		body.collision_layer = 0
	if animated:
		var dir := (m.get_aabb().get_center() - get_landmark("heart_center")).normalized()
		if dir == Vector3.ZERO:
			dir = Vector3.UP
		var start := m.position
		var t := create_tween()
		t.tween_property(m, "position", start + dir * 0.06, 0.35).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
		t.tween_callback(func():
			m.position = start
			_apply_visibility(id))
	else:
		_apply_visibility(id)
	removed_changed.emit(_removed_stack.size())

func undo_remove() -> String:
	if _removed_stack.is_empty():
		return ""
	var id: String = _removed_stack.pop_back()
	parts[id]["removed"] = false
	_apply_visibility(id)
	removed_changed.emit(_removed_stack.size())
	return id

func restore_all_removed(emit := true) -> void:
	for id in _removed_stack:
		parts[id]["removed"] = false
		_apply_visibility(id)
	_removed_stack.clear()
	if emit:
		removed_changed.emit(0)

func get_removed_count() -> int:
	return _removed_stack.size()

# ------------------------------------------------------------------ disease markers
## Shows a small marker (e.g. thrombotic occlusion) at a manifest marker position.
func show_marker(marker_name: String, color: Color, radius := 0.0032) -> void:
	hide_marker(marker_name)
	var pos := get_landmark(marker_name)
	if pos == Vector3.ZERO:
		return
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = radius; sm.height = radius * 2.0
	mi.mesh = sm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.35
	mat.emission_enabled = true
	mat.emission = color * 0.6
	mi.material_override = mat
	mi.position = pos
	add_child(mi)
	var ring := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = radius * 1.6; tm.outer_radius = radius * 2.1
	ring.mesh = tm
	var rm := StandardMaterial3D.new()
	rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rm.albedo_color = Color(1.0, 0.85, 0.2, 0.85)
	rm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rm.no_depth_test = true
	ring.material_override = rm
	mi.add_child(ring)
	var tw := ring.create_tween().set_loops()
	tw.tween_property(ring, "scale", Vector3.ONE * 1.6, 0.7)
	tw.tween_property(ring, "scale", Vector3.ONE, 0.01)
	_markers[marker_name] = mi

func hide_marker(marker_name: String) -> void:
	if _markers.has(marker_name):
		(_markers[marker_name] as Node).queue_free()
		_markers.erase(marker_name)

func hide_all_markers() -> void:
	for k in _markers.keys():
		hide_marker(k)

# ------------------------------------------------------------------ quality / valves
func set_texture_detail(amount: float) -> void:
	for mat in _materials.values():
		if mat is ShaderMaterial:
			(mat as ShaderMaterial).set_shader_parameter("detail_amount", amount)

## Aortic valve blend shape "open" (0 = closed, 1 = open).
func set_valve_open(id: String, amount: float) -> bool:
	if not parts.has(id):
		return false
	var m: MeshInstance3D = parts[id]["mesh"]
	if m.mesh == null:
		return false
	var idx := m.find_blend_shape_by_name("open")
	if idx < 0:
		return false
	m.set_blend_shape_value(idx, clampf(amount, 0.0, 1.0))
	return true
