## StudioEnvironment
## Soft three-point "medical visualization" lighting + environment reflections.
## Compatibility-renderer friendly: 3 directional lights, one shadow caster (toggled by quality).
class_name StudioEnvironment
extends Node3D

@export var background := Color("#0A111E")
@export var transparent_background := false   # for SubViewport previews with transparent_bg
var key: DirectionalLight3D
var fill: DirectionalLight3D
var rim: DirectionalLight3D
var _env: Environment
var _backdrop: MeshInstance3D
var _bg_mat: ShaderMaterial
const BG_SHADER := """
shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_never, shadows_disabled, fog_disabled;
uniform vec4 inner : source_color = vec4(0.11, 0.16, 0.27, 1.0);
uniform vec4 outer : source_color = vec4(0.03, 0.05, 0.09, 1.0);
void fragment() {
	vec2 d = (SCREEN_UV - vec2(0.5, 0.44)) * vec2(VIEWPORT_SIZE.x / VIEWPORT_SIZE.y, 1.0);
	float r = smoothstep(0.0, 0.95, length(d));
	ALBEDO = mix(inner.rgb, outer.rgb, r);
}
"""

func _ready() -> void:
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_CLEAR_COLOR if transparent_background else Environment.BG_COLOR
	env.background_color = background
	_env = env
	var sky := Sky.new()
	var psm := ProceduralSkyMaterial.new()
	psm.sky_top_color = Color(0.47, 0.46, 0.47)
	psm.sky_horizon_color = Color(0.60, 0.57, 0.55)
	psm.ground_bottom_color = Color(0.10, 0.09, 0.09)
	psm.ground_horizon_color = Color(0.36, 0.32, 0.30)
	sky.sky_material = psm
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.38
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.0
	we.environment = env
	add_child(we)

	key = _light("Key", Vector3(-38, 32, 0), Color(1.0, 0.97, 0.93), 1.15, true)
	fill = _light("Fill", Vector3(-12, -55, 0), Color(0.98, 0.95, 0.93), 0.38, false)
	rim = _light("Rim", Vector3(-25, 165, 0), Color(0.92, 0.95, 1.0), 0.55, false)
	if not transparent_background:
		_build_backdrop()
	if Engine.has_singleton("AppState") or get_node_or_null("/root/AppState"):
		AppState.quality_changed.connect(_on_quality)
		_on_quality(AppState.quality)
		if not transparent_background:
			AppState.backdrop_changed.connect(func(_id): _update_backdrop())
			_update_backdrop()

## Soft radial "studio" backdrop: a large unshaded quad kept far behind the subject, facing the
## active camera (one quad, no canvas background mode, which breaks depth in the Compatibility renderer).
func _build_backdrop() -> void:
	_backdrop = MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(1, 1)
	_backdrop.mesh = q
	_backdrop.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_backdrop.extra_cull_margin = 16384.0
	var sh := Shader.new()
	sh.code = BG_SHADER
	_bg_mat = ShaderMaterial.new()
	_bg_mat.shader = sh
	_bg_mat.render_priority = -100
	_backdrop.material_override = _bg_mat
	add_child(_backdrop)
	_update_backdrop()

func _process(_d: float) -> void:
	if _backdrop == null:
		return
	var cam := get_viewport().get_camera_3d()
	if cam == null:
		return
	var dist := minf(cam.far * 0.8, 8.0)
	var h := 2.0 * dist * tan(deg_to_rad(cam.fov) * 0.5) * 3.0
	var t := cam.get_camera_transform()
	_backdrop.global_transform = Transform3D(Basis(t.basis.x * h * 2.0, t.basis.y * h, t.basis.z), t.origin - t.basis.z * dist)

func _update_backdrop() -> void:
	var b: Array = ["studio", "", "#1B2A44", "#070C16"]
	if get_node_or_null("/root/AppState"):
		b = AppState.get_backdrop()
	if _bg_mat:
		_bg_mat.set_shader_parameter("inner", Color(b[2]))
		_bg_mat.set_shader_parameter("outer", Color(b[3]))
	if _env:
		_env.background_color = Color(b[3])

func _light(n: String, rot: Vector3, col: Color, energy: float, shadow: bool) -> DirectionalLight3D:
	var l := DirectionalLight3D.new()
	l.name = n
	l.rotation_degrees = rot
	l.light_color = col
	l.light_energy = energy
	l.shadow_enabled = shadow
	if shadow:
		l.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
		l.directional_shadow_max_distance = 2.0
		l.shadow_blur = 1.5
		l.shadow_bias = 0.02
		l.shadow_normal_bias = 1.0
	add_child(l)
	return l

func _on_quality(level: int) -> void:
	key.shadow_enabled = level >= 1
