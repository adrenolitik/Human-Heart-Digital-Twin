## EP Lab (Stage 2 — Electrophysiology & ECG)
## Built on the SAME HeartModel and CardiacEngine as Stage 1. Modes:
##   Conduction  - SA node → atria → AV node → His → bundle branches → Purkinje, animated and highlighted;
##                 myocardial depolarisation wavefront or isochrone (activation-time) map
##   ECG waves   - annotated sweep (P, PR, QRS, ST, T, RR) synchronised with the 3D events
##   12-lead     - paper-style 12-lead from one simulated heart vector, lead axes and cardiac vector in 3D
##   Rhythms     - NSR, sinus bradycardia, sinus tachycardia, AF, PVC, VT with HR control and RR display
## Every waveform is an educational simulation, labelled as such on screen.
## Developer QA: `-- --qa-shots=<dir>` renders reference screenshots and quits.
extends Node3D

const Pal := preload("res://scripts/ui/ui_palette.gd")
const Kit := preload("res://scripts/ui/ui_kit.gd")
const CONTENT_PATH := "res://data/electro/ep_content.json"
const RHYTHMS := ["r_nsr", "r_brady", "r_tachy", "r_af", "r_pvc", "r_vt"]
const MODES := [
	["conduction", "Conduction", "zap", "Conduction system and impulse propagation"],
	["waves", "ECG waves", "activity", "P, PR, QRS, ST, T and RR linked to the 3D heart"],
	["twelve", "12-lead", "grid-3x3", "Educational 12-lead viewer"],
	["rhythms", "Rhythms", "heart-pulse", "Six simulated rhythms"],
]
const SEQUENCE := ["sa_node", "internodal", "bachmann", "av_node", "his", "lbb", "rbb", "purkinje"]

var heart: HeartModel
var cam: OrbitCamera
var picker: PartPicker
var engine: CardiacEngine
var env: StudioEnvironment
var conduction: ConductionSystem
var recorder: EcgRecorder
var axes: LeadAxes3D
var content := {}
var mode := "conduction"
var rhythm_id := "r_nsr"

# UI
var _ui: Control
var _mode_tabs := {}
var _rhythm_buttons := {}
var _hr: Dictionary
var _pvc_row: Control
var _pvc_tabs: Dictionary
var _play_btn: Button
var _speed_tabs: Dictionary
var _overlay_tabs: Dictionary
var _t_conduction: CheckButton
var _t_xray: CheckButton
var _t_glass: CheckButton
var _t_cut: CheckButton
var _t_labels: CheckButton
var _t_vector: CheckButton
var _right_title: Label
var _right_sub: Label
var _right_body: VBoxContainer
var _info_text: RichTextLabel
var _seq_rows := {}
var _wave_rows := {}
var _now_label: RichTextLabel
var _interval_labels := {}
var _rr_label: RichTextLabel
var _axis_label: Label
var _lead_info: RichTextLabel
var _strip_panel: PanelContainer
var _strip: EcgStrip
var _strip_lead: OptionButton
var _twelve_panel: PanelContainer
var _twelve: TwelveLeadView
var _plane_tabs: Dictionary
var _vitals := {}
var _hint_label: Label
var _fps_label: Label
var _left_panel: Control
var _right_panel: Control
var _label_layer: Control
var _labels := {}
var _live_timer := 0.0
var _iso_legend: Control
var _selected_struct := ""
var _selected_wave := ""

func _ready() -> void:
	env = StudioEnvironment.new()
	add_child(env)
	heart = HeartModel.new()
	heart.name = "Heart"
	heart.build_colliders = true
	add_child(heart)
	conduction = ConductionSystem.new()
	conduction.name = "ConductionSystem"
	heart.add_child(conduction)
	cam = OrbitCamera.new()
	add_child(cam)
	picker = PartPicker.new()
	picker.heart = heart
	add_child(picker)
	engine = CardiacEngine.new()
	engine.heart = heart
	engine.extra_paths = PackedStringArray(["res://data/electro/rhythms.json"])
	add_child(engine)
	engine.setup_ep_sources()
	engine.ep_overlay = 1
	recorder = EcgRecorder.new()
	recorder.engine = engine
	add_child(recorder)
	axes = LeadAxes3D.new()
	axes.recorder = recorder
	axes.engine = engine
	axes.center = (heart.get_landmark("LV") * 0.6 + heart.get_landmark("RV") * 0.4)
	axes.visible = false
	heart.add_child(axes)
	var cd = JSON.parse_string(FileAccess.get_file_as_string(CONTENT_PATH)) if FileAccess.file_exists(CONTENT_PATH) else {}
	content = cd if cd is Dictionary else {}
	var box := heart.get_model_aabb()
	cam.set_home(0.0, -8.0, box.get_center(), 0.46)
	cam.reset_view(false)
	cam.clicked.connect(_on_clicked)
	AppState.quality_changed.connect(func(_q): heart.set_texture_detail(AppState.texture_detail()))
	heart.set_texture_detail(AppState.texture_detail())
	engine.rate_changed.connect(_on_rate_changed)
	_build_ui()
	_select_rhythm("r_nsr")
	_set_mode("conduction")
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--qa-shots="):
			_run_qa_shots(a.get_slice("=", 1))

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match (event as InputEventKey).keycode:
			KEY_SPACE: _toggle_play()
			KEY_R: _restart()
			KEY_F: _toggle_focus()
			KEY_1: _set_mode("conduction")
			KEY_2: _set_mode("waves")
			KEY_3: _set_mode("twelve")
			KEY_4: _set_mode("rhythms")

func _process(delta: float) -> void:
	_fps_label.text = "%d FPS" % Engine.get_frames_per_second()
	cam.frame_rect = _free_rect()
	_update_labels()
	_live_timer -= delta
	if _live_timer <= 0.0:
		_live_timer = 0.1
		_update_live()

# ================================================================== state changes
func _set_mode(m: String) -> void:
	mode = m
	for k in _mode_tabs:
		(_mode_tabs[k] as Button).set_pressed_no_signal(k == m)
	_strip_panel.visible = m != "twelve"
	_twelve_panel.visible = m == "twelve"
	axes.visible = m == "twelve"
	_strip.annotate_waves = m == "waves"
	_strip.window_s = 3.0 if m == "waves" else 6.0
	_strip.annotate_intervals = m == "waves"
	_strip.show_rr = true
	conduction.set_highlight("")
	_selected_struct = ""
	_selected_wave = ""
	match m:
		"conduction":
			_t_conduction.button_pressed = true
			_set_overlay(1)
			cam.set_view(0.0, -8.0, heart.get_model_aabb().get_center(), 0.46)
		"waves":
			_set_overlay(1)
			cam.reset_view()
			if rhythm_id in ["r_af", "r_vt"]:
				_select_rhythm("r_nsr")
		"twelve":
			_set_overlay(0)
			cam.set_view(0.0, -6.0, heart.get_model_aabb().get_center(), 0.62)
		"rhythms":
			_set_overlay(1)
			cam.reset_view()
	_build_right_panel()
	var hints := {
		"conduction": "Follow the glowing impulse · slow down to 0.1× to see each step · click a structure in the list to highlight it",
		"waves": "Each labelled band on the ECG matches what the 3D heart is doing at that moment · click a band or a wave for details",
		"twelve": "Click a lead on the paper: its axis lights up in 3D · the cyan arrow is the heart vector, green/red its projection",
		"rhythms": "Choose a rhythm and change the heart rate · RR intervals are measured live on the strip",
	}
	_hint_label.text = hints.get(m, "")

func _set_overlay(i: int) -> void:
	engine.ep_overlay = i
	if _iso_legend:
		_iso_legend.visible = i == 2
	for k in _overlay_tabs.get("buttons", {}):
		(_overlay_tabs["buttons"][k] as Button).set_pressed_no_signal(int(k) == i)

func _select_rhythm(id: String) -> void:
	rhythm_id = id
	engine.set_condition(id)
	for k in _rhythm_buttons:
		(_rhythm_buttons[k] as Button).set_pressed_no_signal(k == id)
	var r := engine.get_hr_range()
	var s: HSlider = _hr["slider"]
	s.set_block_signals(true)
	s.min_value = r.x; s.max_value = r.y; s.value = engine.hr
	s.set_block_signals(false)
	(_hr["value"] as Label).text = "%d bpm" % int(round(engine.hr))
	(_hr["range"] as Label).text = "Range for this rhythm: %d–%d bpm" % [int(r.x), int(r.y)]
	_pvc_row.visible = id == "r_pvc"
	recorder.clear()
	if mode in ["rhythms", "waves", "conduction", "twelve"]:
		_build_right_panel()

func _on_rate_changed(v: float) -> void:
	if _hr and _hr.has("value"):
		(_hr["value"] as Label).text = "%d bpm" % int(round(v))

## Focus mode: hide the side panels (the ECG panel stays) so the heart is larger.
func _toggle_focus() -> void:
	var show := not _left_panel.visible
	for p in [_left_panel, _right_panel]:
		var c: Control = p
		if show:
			c.visible = true
			c.modulate.a = 0.0
			c.create_tween().tween_property(c, "modulate:a", 1.0, 0.18)
		else:
			var tw := c.create_tween()
			tw.tween_property(c, "modulate:a", 0.0, 0.14)
			tw.tween_callback(func(): c.visible = false)

func _toggle_play() -> void:
	engine.playing = not engine.playing
	_play_btn.icon = Kit.icon("pause" if engine.playing else "play")
	_play_btn.text = "Pause" if engine.playing else "Play"

func _restart() -> void:
	engine.restart()
	recorder.clear()

func _set_speed(v: float) -> void:
	engine.speed = v

func _on_clicked(pos: Vector2) -> void:
	var hit := picker.pick(pos)
	var id: String = hit.get("id", "")
	if id != "":
		_hint_label.text = heart.get_part_info(id).get("name", id) + " — anatomy details are in Stage 1 · Heart Lab"

func _leave() -> void:
	engine.ep_overlay = 0
	heart.set_cutaway(false)
	heart.reset_physiology_uniforms()
	SceneRouter.go_home()

# ================================================================== UI construction
func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	_ui = Control.new()
	_ui.theme = load("res://assets/ui/theme.tres")
	_ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	_ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(_ui)
	_label_layer = Control.new()
	_label_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	_label_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui.add_child(_label_layer)
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, Pal.SP_M)
	_ui.add_child(margin)
	var col := VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_theme_constant_override("separation", Pal.SP_S)
	margin.add_child(col)
	col.add_child(_build_top_bar())
	var row := HBoxContainer.new()
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", Pal.SP_S)
	col.add_child(row)
	_left_panel = _build_left_panel()
	row.add_child(_left_panel)
	var centre := VBoxContainer.new()
	centre.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	centre.mouse_filter = Control.MOUSE_FILTER_IGNORE
	centre.add_theme_constant_override("separation", Pal.SP_S)
	centre.add_child(Kit.spacer(false))
	centre.add_child(_build_strip_panel())
	centre.add_child(_build_twelve_panel())
	row.add_child(centre)
	_right_panel = _build_right_shell()
	row.add_child(_right_panel)
	col.add_child(_build_bottom_bar())
	# conduction labels (drawn under the panels)
	for g in conduction.get_structure_groups():
		var l := Label.new()
		l.text = g["name"]
		l.add_theme_font_size_override("font_size", 13)
		var sb := Pal.chip(Color(g["color"]))
		sb.bg_color = Color(Pal.PANEL, 0.9)
		l.add_theme_stylebox_override("normal", sb)
		l.visible = false
		l.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_label_layer.add_child(l)
		_labels[g["id"]] = l

func _panel(min_w := 0.0) -> PanelContainer:
	var p := Kit.card(false, 0.93)
	p.custom_minimum_size.x = min_w
	return p

func _build_top_bar() -> Control:
	var p := _panel()
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", Pal.SP_M)
	p.add_child(h)
	h.add_child(Kit.icon_button("arrow-left", "Back to the dashboard", _leave))
	var tv := VBoxContainer.new(); tv.add_theme_constant_override("separation", -2)
	var t := Label.new(); t.text = "Electrophysiology Lab"; t.theme_type_variation = "HeaderMedium"
	var st := Label.new(); st.text = "Stage 2 · conduction system & ECG on the Stage 1 heart"; st.theme_type_variation = "MutedLabel"
	st.add_theme_font_size_override("font_size", 12)
	tv.add_child(t); tv.add_child(st); h.add_child(tv)
	var seg := Kit.segmented(MODES, func(id): _set_mode(id))
	_mode_tabs = seg["buttons"]
	h.add_child(seg["root"])
	h.add_child(Kit.spacer())
	h.add_child(Kit.sim_badge())
	_t_labels = Kit.toggle("Labels", false, func(on): _update_labels(), "tag", "Name the conduction structures in 3D")
	h.add_child(_t_labels)
	h.add_child(Kit.appearance_menu())
	h.add_child(Kit.icon_button("focus", "Focus mode: hide the side panels (F)", _toggle_focus))
	h.add_child(Kit.icon_button("scan-eye", "Reset camera", func(): cam.reset_view()))
	return p

func _build_left_panel() -> Control:
	var p := _panel(296)
	var sc := ScrollContainer.new()
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	p.add_child(sc)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", Pal.SP_S)
	sc.add_child(v)
	v.add_child(Kit.section("RHYTHM", "heart-pulse"))
	var group := ButtonGroup.new()
	for id in RHYTHMS:
		var c := engine.get_condition_data(id)
		var b := Kit.button("%s\n%s" % [c.get("name", id), c.get("short", "")], "", Callable(), "", "ListButton")
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.toggle_mode = true
		b.button_group = group
		b.custom_minimum_size.y = 50
		b.add_theme_font_size_override("font_size", 14)
		var rid: String = id
		b.pressed.connect(func(): _select_rhythm(rid))
		v.add_child(b)
		_rhythm_buttons[id] = b
	_hr = Kit.slider_row("Heart rate", 40, 180, 1, 72, func(x): return "%d bpm" % int(round(x)), func(x): engine.set_hr(x))
	v.add_child(_hr["root"])
	var rl := Kit.muted("", 12)
	_hr["range"] = rl
	v.add_child(rl)
	_pvc_row = VBoxContainer.new()
	_pvc_row.add_child(Kit.muted("PVC pattern", 13))
	_pvc_tabs = Kit.segmented([["5", "Isolated", ""], ["3", "Trigeminy", ""], ["2", "Bigeminy", ""]], func(id):
		engine.ep_pvc_every = int(id)
		engine.restart()
		recorder.clear(), true)
	(_pvc_tabs["buttons"]["5"] as Button).button_pressed = true
	engine.ep_pvc_every = 5
	_pvc_row.add_child(_pvc_tabs["root"])
	v.add_child(_pvc_row)
	v.add_child(HSeparator.new())
	v.add_child(Kit.section("PLAYBACK", "timer"))
	var pr := HBoxContainer.new()
	_play_btn = Kit.button("Pause", "pause", _toggle_play, "Space")
	_play_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pr.add_child(_play_btn)
	pr.add_child(Kit.icon_button("rotate-ccw", "Restart (R)", _restart))
	v.add_child(pr)
	_speed_tabs = Kit.segmented([["1.0", "1×", ""], ["0.5", "0.5×", ""], ["0.25", "0.25×", ""], ["0.1", "0.1×", ""]], func(id): _set_speed(float(id)), true)
	(_speed_tabs["buttons"]["1.0"] as Button).button_pressed = true
	v.add_child(_speed_tabs["root"])
	v.add_child(HSeparator.new())
	v.add_child(Kit.section("DISPLAY", "layers"))
	v.add_child(Kit.muted("Myocardium", 13))
	_overlay_tabs = Kit.segmented([["0", "Tissue", ""], ["1", "Wavefront", ""], ["2", "Isochrones", ""]], func(id): _set_overlay(int(id)), true)
	v.add_child(_overlay_tabs["root"])
	_iso_legend = _build_iso_legend()
	v.add_child(_iso_legend)
	_t_conduction = Kit.toggle("Conduction system", true, func(on): conduction.visible = on, "zap")
	v.add_child(_t_conduction)
	_t_xray = Kit.toggle("See through walls", true, func(on): conduction.set_xray(on), "eye", "Draw the conduction system through the myocardium")
	v.add_child(_t_xray)
	_t_glass = Kit.toggle("Translucent heart", false, func(on): heart.isolate(PackedStringArray(["__none__"]) if on else PackedStringArray()), "box")
	v.add_child(_t_glass)
	_t_cut = Kit.toggle("Four-chamber cut", false, func(on): _apply_cut(on), "scissors", "Open the heart in the four-chamber plane")
	v.add_child(_t_cut)
	_t_vector = Kit.toggle("Heart vector & lead axes", false, func(on): axes.visible = on or mode == "twelve", "move-3d")
	v.add_child(_t_vector)
	return p

## Colour scale for the isochrone map (colour + text labels, never colour alone).
func _build_iso_legend() -> Control:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 2)
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.1, 0.35, 0.55, 0.8, 1.0])
	g.colors = PackedColorArray([Color(0.95, 0.10, 0.08), Color(1.0, 0.45, 0.0), Color(0.95, 0.95, 0.2), Color(0.25, 0.95, 0.6), Color(0.1, 0.4, 1.0), Color(0.58, 0.22, 0.88)])
	var gt := GradientTexture2D.new(); gt.gradient = g; gt.width = 256; gt.height = 8
	var bar := TextureRect.new(); bar.texture = gt; bar.custom_minimum_size = Vector2(0, 10)
	bar.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; bar.stretch_mode = TextureRect.STRETCH_SCALE
	v.add_child(bar)
	var h := HBoxContainer.new()
	var a := Label.new(); a.text = "Earliest"; a.add_theme_font_size_override("font_size", 12)
	var b := Label.new(); b.text = "Latest (≈ 85 ms, ventricles)"; b.add_theme_font_size_override("font_size", 12)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL; b.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	h.add_child(a); h.add_child(b)
	v.add_child(h)
	v.add_child(Kit.muted("Lines every 10 % of the activation time. Atria use their own scale (≈ 100 ms).", 12))
	v.visible = false
	return v

func _apply_cut(on: bool) -> void:
	if not on:
		heart.set_cutaway(false)
		return
	var apex := heart.get_landmark("apex")
	var mitral := heart.get_landmark("mitral_center")
	var tric := heart.get_landmark("tricuspid_center")
	var n := (mitral - apex).cross(tric - apex).normalized()
	if n.z < 0.0:
		n = -n
	var p := (apex + mitral + tric) / 3.0
	heart.set_cutaway(true, Plane(n, n.dot(heart.global_transform * p)))
	cam.look_from_direction(n, heart.get_model_aabb().get_center(), 0.44)

func _build_strip_panel() -> Control:
	_strip_panel = _panel()
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", Pal.SP_S)
	_strip_panel.add_child(v)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", Pal.SP_M)
	v.add_child(h)
	h.add_child(Kit.section("ECG MONITOR", "audio-waveform"))
	_strip_lead = OptionButton.new()
	for l in CardiacEngine.LEAD_NAMES:
		_strip_lead.add_item(l)
	_strip_lead.select(1)
	_strip_lead.custom_minimum_size.y = 36
	_strip_lead.tooltip_text = "Lead shown on the monitor"
	_strip_lead.item_selected.connect(func(i): _strip.lead = CardiacEngine.LEAD_NAMES[i])
	h.add_child(_strip_lead)
	h.add_child(Kit.spacer())
	for k in [["hr", "HR", "bpm"], ["rr", "RR", "ms"], ["bp", "BP", "mmHg"], ["rhythm", "", ""]]:
		var vb := HBoxContainer.new()
		vb.add_theme_constant_override("separation", 4)
		if k[1] != "":
			var cap := Label.new(); cap.text = k[1]; cap.theme_type_variation = "MutedLabel"
			cap.add_theme_font_size_override("font_size", 12)
			vb.add_child(cap)
		var val := Label.new(); val.add_theme_font_size_override("font_size", 18)
		val.add_theme_color_override("font_color", Pal.SUCCESS if k[0] == "hr" else Pal.TEXT)
		vb.add_child(val)
		if k[2] != "":
			var u := Label.new(); u.text = k[2]; u.theme_type_variation = "MutedLabel"; u.add_theme_font_size_override("font_size", 12)
			vb.add_child(u)
		h.add_child(vb)
		_vitals[k[0]] = val
	_strip = EcgStrip.new()
	_strip.engine = engine
	_strip.recorder = recorder
	_strip.custom_minimum_size.y = 176
	_strip.wave_selected.connect(func(w):
		if mode != "waves": _set_mode("waves")
		_show_wave(w))
	v.add_child(_strip)
	return _strip_panel

func _build_twelve_panel() -> Control:
	_twelve_panel = _panel()
	_twelve_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var v := VBoxContainer.new()
	_twelve_panel.add_child(v)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", Pal.SP_M)
	v.add_child(h)
	h.add_child(Kit.section("12-LEAD ECG", "grid-3x3"))
	h.add_child(Kit.spacer())
	var walls := Kit.toggle("Show lead groups", false, func(on): _twelve.show_walls = on; _twelve.queue_redraw(), "layers", "Tint contiguous leads by the wall they face")
	h.add_child(walls)
	var fr := Kit.toggle("Freeze", false, func(on): recorder.frozen = on, "pause", "Stop the paper to study it")
	h.add_child(fr)
	_twelve = TwelveLeadView.new()
	_twelve.recorder = recorder
	_twelve.engine = engine
	_twelve.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_twelve.custom_minimum_size.y = 300
	_twelve.lead_selected.connect(_on_lead_selected)
	v.add_child(_twelve)
	return _twelve_panel

func _build_right_shell() -> Control:
	var p := _panel(340)
	var sc := ScrollContainer.new()
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	p.add_child(sc)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", Pal.SP_S)
	sc.add_child(v)
	_right_title = Label.new(); _right_title.theme_type_variation = "HeaderMedium"
	_right_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_right_sub = Kit.muted("", 13)
	v.add_child(_right_title); v.add_child(_right_sub)
	_right_body = VBoxContainer.new()
	_right_body.add_theme_constant_override("separation", Pal.SP_S)
	v.add_child(_right_body)
	return p

func _build_bottom_bar() -> Control:
	var p := _panel()
	var h := HBoxContainer.new()
	p.add_child(h)
	var ic := TextureRect.new(); ic.texture = Kit.icon("info"); ic.custom_minimum_size = Vector2(16, 16)
	ic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	ic.modulate = Pal.TEXT_MUTED; ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(ic)
	_hint_label = Label.new(); _hint_label.theme_type_variation = "MutedLabel"
	_hint_label.add_theme_font_size_override("font_size", 13)
	_hint_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_hint_label.clip_text = true
	h.add_child(_hint_label)
	var disc := Label.new(); disc.text = "Simulated educational signals · not a clinical recording · keys 1–4 modes, Space pause, R restart"
	disc.theme_type_variation = "MutedLabel"; disc.add_theme_font_size_override("font_size", 12)
	h.add_child(disc)
	_fps_label = Label.new(); _fps_label.theme_type_variation = "MutedLabel"; _fps_label.add_theme_font_size_override("font_size", 12)
	_fps_label.custom_minimum_size.x = 56; _fps_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	h.add_child(_fps_label)
	return p

# ================================================================== right panel per mode
func _clear_body() -> void:
	for c in _right_body.get_children():
		c.queue_free()
	_seq_rows.clear()
	_wave_rows.clear()
	_interval_labels.clear()
	_now_label = null; _rr_label = null; _axis_label = null; _lead_info = null; _info_text = null

func _rich(min_h := 0.0) -> RichTextLabel:
	var r := RichTextLabel.new()
	r.bbcode_enabled = true
	r.fit_content = true
	r.scroll_active = false
	r.custom_minimum_size.y = min_h
	r.add_theme_font_size_override("normal_font_size", 14)
	r.add_theme_font_size_override("bold_font_size", 14)
	return r

func _build_right_panel() -> void:
	_clear_body()
	match mode:
		"conduction": _right_conduction()
		"waves": _right_waves()
		"twelve": _right_twelve()
		"rhythms": _right_rhythm()

func _row_button(text: String, sub: String, color: Color, cb: Callable) -> Button:
	var b := Kit.button("", "", cb, "", "ListButton")
	b.toggle_mode = false
	b.custom_minimum_size.y = 46
	var h := HBoxContainer.new()
	h.set_anchors_preset(Control.PRESET_FULL_RECT)
	h.offset_left = 10; h.offset_right = -8
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	h.add_theme_constant_override("separation", 10)
	var sw := ColorRect.new(); sw.color = color; sw.custom_minimum_size = Vector2(4, 30)
	sw.size_flags_vertical = Control.SIZE_SHRINK_CENTER; sw.mouse_filter = Control.MOUSE_FILTER_IGNORE
	h.add_child(sw)
	var tv := VBoxContainer.new(); tv.add_theme_constant_override("separation", -2); tv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tv.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var a := Label.new(); a.text = text; a.add_theme_font_size_override("font_size", 14); a.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var s := Label.new(); s.text = sub; s.theme_type_variation = "MutedLabel"; s.add_theme_font_size_override("font_size", 12); s.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tv.add_child(a); tv.add_child(s)
	h.add_child(tv)
	b.add_child(h)
	return b

func _right_conduction() -> void:
	_right_title.text = "Conduction system"
	_right_sub.text = "Rows light up in activation order."
	_now_label = _rich(44)
	_right_body.add_child(_now_label)
	_right_body.add_child(Kit.section("SEQUENCE", "list-tree"))
	var info: Dictionary = content.get("structures", {})
	for id in SEQUENCE:
		var g := id as String
		var b := _row_button(conduction.get_group_name(g), (info.get(g, {}) as Dictionary).get("timing", ""), conduction.get_group_color(g), func(): _show_structure(g))
		_right_body.add_child(b)
		_seq_rows[g] = b
	_right_body.add_child(HSeparator.new())
	_info_text = _rich()
	_right_body.add_child(_info_text)
	_show_structure("")

func _show_structure(id: String) -> void:
	_selected_struct = "" if id == _selected_struct else id
	conduction.set_highlight(_selected_struct)
	if _info_text == null:
		return
	if _selected_struct == "":
		_info_text.text = "[color=#5B6B65]" + _bullets(["Click a row to highlight it in 3D", "Speed 0.1× + Wavefront to follow the impulse", "Isochrones: red = earliest, violet = latest"]) + "[/color]"
		return
	var d: Dictionary = (content.get("structures", {}) as Dictionary).get(_selected_struct, {})
	var c := conduction.get_group_color(_selected_struct).to_html(false)
	_info_text.text = "[b][color=#%s]%s[/color][/b]\n%s" % [c, conduction.get_group_name(_selected_struct), _bullets(["[b]When:[/b] " + str(d.get("timing", "")), "[b]What:[/b] " + _brief(d.get("text", "")), "[b]ECG:[/b] " + _brief(d.get("ecg", ""))])]
	cam.focus_on(heart.to_global(conduction.get_group_center(_selected_struct)), 0.30)

func _right_waves() -> void:
	_right_title.text = "ECG waves & intervals"
	_right_sub.text = "Each wave = one electrical event in the heart."
	_now_label = _rich(44)
	_right_body.add_child(_now_label)
	var grid := GridContainer.new(); grid.columns = 2
	grid.add_theme_constant_override("h_separation", 14); grid.add_theme_constant_override("v_separation", 2)
	for k in [["pr", "PR"], ["qrs", "QRS"], ["qt", "QT"], ["qtc", "QTc (Bazett)"], ["rr", "RR"], ["hr", "Heart rate"]]:
		var a := Label.new(); a.text = k[1]; a.theme_type_variation = "MutedLabel"; a.add_theme_font_size_override("font_size", 13)
		var b := Label.new(); b.add_theme_font_size_override("font_size", 14)
		grid.add_child(a); grid.add_child(b)
		_interval_labels[k[0]] = b
	_right_body.add_child(grid)
	_right_body.add_child(Kit.section("COMPONENTS", "activity"))
	var waves: Dictionary = content.get("waves", {})
	for w in ["P", "PR", "QRS", "ST", "T", "TP", "RR"]:
		var key := w as String
		var col: Color = EcgStrip.WAVE_COLORS.get(key, Pal.TEXT_MUTED)
		var b := _row_button((waves.get(key, {}) as Dictionary).get("name", key), (waves.get(key, {}) as Dictionary).get("normal", ""), col, func(): _show_wave(key))
		_right_body.add_child(b)
		_wave_rows[key] = b
	_right_body.add_child(HSeparator.new())
	_info_text = _rich()
	_right_body.add_child(_info_text)
	_show_wave("")

func _show_wave(w: String) -> void:
	_selected_wave = w
	if _info_text == null:
		return
	if w == "":
		_info_text.text = "[color=#5B6B65]Click a wave above or on the strip[/color]"
		return
	var d: Dictionary = (content.get("waves", {}) as Dictionary).get(w, {})
	_info_text.text = "[b]%s[/b]\n%s" % [d.get("name", w), _bullets(["[b]Normal:[/b] " + _brief(d.get("normal", "")), "[b]Meaning:[/b] " + _brief(d.get("text", "")), "[b]3D:[/b] " + _brief(str(d.get("heart", "")).trim_prefix("3D: "))])]

func _right_twelve() -> void:
	_right_title.text = "12-lead viewer"
	_right_sub.text = "12 views of one heart vector · click a lead"
	_plane_tabs = Kit.segmented([["frontal", "Limb leads", "crosshair"], ["horizontal", "Chest leads", "circle-dot"]], func(id):
		axes.plane = id
		if id == "frontal" and not (_twelve.selected in LeadAxes3D.FRONTAL): _on_lead_selected("II")
		elif id == "horizontal" and not (_twelve.selected in LeadAxes3D.PRECORDIAL): _on_lead_selected("V2"), true)
	(_plane_tabs["buttons"][axes.plane] as Button).button_pressed = true
	_right_body.add_child(_plane_tabs["root"])
	_axis_label = Label.new(); _axis_label.add_theme_font_size_override("font_size", 14)
	_axis_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_right_body.add_child(_axis_label)
	_lead_info = _rich()
	_right_body.add_child(_lead_info)
	_right_body.add_child(Kit.section("LEAD GROUPS", "layers"))
	for k in TwelveLeadView.WALLS:
		var wd: Dictionary = TwelveLeadView.WALLS[k]
		_right_body.add_child(Kit.legend_item(Color(wd["color"]), "%s — %s" % [wd["name"], ", ".join(PackedStringArray(wd["leads"]))]))
	_right_body.add_child(Kit.muted("Cyan arrow = heart vector · green/red = projection on the lead", 12))
	_on_lead_selected(_twelve.selected)

func _on_lead_selected(l: String) -> void:
	_twelve.selected = l
	axes.selected = l
	var plane := "frontal" if l in LeadAxes3D.FRONTAL else "horizontal"
	if axes.plane != plane:
		axes.plane = plane
		if _plane_tabs and _plane_tabs.has("buttons"):
			(_plane_tabs["buttons"][plane] as Button).set_pressed_no_signal(true)
	_strip_lead.select(CardiacEngine.LEAD_NAMES.find(l))
	_strip.lead = l
	if _lead_info:
		var d: Dictionary = (content.get("leads", {}) as Dictionary).get(l, {})
		var wall := _twelve.wall_of(l)
		_lead_info.text = "[b]Lead %s[/b] · %s\n[color=#5B6B65]%s · axis %s[/color]\nViews: %s%s" % [l, d.get("type", ""), d.get("electrodes", ""), d.get("angle", ""), d.get("view", ""),
			("\nGroup: " + str(TwelveLeadView.WALLS[wall]["name"])) if wall != "" else ""]
	_twelve.queue_redraw()

func _right_rhythm() -> void:
	var c := engine.get_condition_data(rhythm_id)
	_right_title.text = c.get("name", rhythm_id)
	_right_sub.text = c.get("short", "")
	_right_body.add_child(Kit.section("KEY POINTS", "activity"))
	var kp := _rich(); kp.text = _bullets(c.get("key_points", [])); _right_body.add_child(kp)
	_rr_label = _rich(64)
	_right_body.add_child(_rr_label)
	var details := VBoxContainer.new()
	details.add_theme_constant_override("separation", Pal.SP_S)
	details.visible = false
	for sec in [["ECG CRITERIA", "activity", c.get("ecg", "")], ["MECHANISM", "zap", c.get("mechanism", "")],
			["WHAT TO LOOK FOR", "eye", _bullets(c.get("look_for", []))], ["CLINICAL NOTES", "stethoscope", _bullets(c.get("clinical", []))]]:
		details.add_child(Kit.section(sec[0], sec[1]))
		var r := _rich(); r.text = str(sec[2]); details.add_child(r)
	_right_body.add_child(_details_toggle(details))
	_right_body.add_child(details)

## Bullet list in BBCode (accent dots, short lines).
func _bullets(items: Array) -> String:
	var t := ""
	for x in items:
		t += "[color=#0B7A52]•[/color]  %s\n" % str(x)
	return t.strip_edges()

## First sentence of a text, for compact panels.
func _brief(t: String, max_len := 120) -> String:
	t = t.strip_edges()
	var i := t.find(". ")
	if i > 0:
		t = t.substr(0, i)
	t = t.trim_suffix(".")
	if t.length() <= max_len:
		return t
	var c := t.substr(0, max_len).rfind(", ")
	if c < max_len * 0.5:
		c = t.substr(0, max_len).rfind(" ")
	return t.substr(0, c).strip_edges() + "…"

## "More details" button that shows / hides a container.
func _details_toggle(target: Control) -> Button:
	var b := Kit.button("More details", "chevron-right", Callable(), "Show or hide the full description", "GhostButton")
	b.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	b.pressed.connect(func():
		target.visible = not target.visible
		b.text = "Less" if target.visible else "More details"
		b.icon = Kit.icon("chevron-left" if target.visible else "chevron-right"))
	return b

# ================================================================== live updates
func _active_structures(st: Dictionary) -> Dictionary:
	var a := {}
	var ta: float = st.get("ta", 10.0)
	var tv: float = st.get("tv", 10.0)
	var av: float = st.get("av", -1.0)
	var ect: bool = st.get("ectopic", false)
	var rh: String = st.get("rhythm", "sinus")
	var hs := engine.his_start()
	if rh == "af":
		a["internodal"] = true; a["bachmann"] = true
	elif rh != "vf":
		a["sa_node"] = ta >= 0.0 and ta < 0.03
		a["internodal"] = ta >= 0.0 and ta < engine.av_entry() + 0.01
		a["bachmann"] = ta >= 0.0 and ta < 0.075
	a["av_node"] = av >= 0.0 and av <= 1.0
	if not ect and rh != "vf":
		a["his"] = tv >= hs - 0.004 and tv < hs + 0.012
		a["lbb"] = tv >= hs + 0.008 and tv < 0.012
		a["rbb"] = tv >= hs + 0.008 and tv < 0.012
		a["purkinje"] = tv >= -0.006 and tv < 0.045
	return a

func _status_text(st: Dictionary) -> String:
	var rh: String = st.get("rhythm", "sinus")
	var tv: float = st.get("tv", 10.0)
	var ta: float = st.get("ta", 10.0)
	var av: float = st.get("av", -1.0)
	var ect: bool = st.get("ectopic", false)
	var iv := engine.get_intervals()
	if rh == "vf":
		return "[color=#C2362F][b]Ventricular fibrillation[/b][/color] — chaotic activity, no organised conduction"
	if ect and tv >= 0.0 and tv < 0.16:
		return "[color=#C2362F][b]Ectopic ventricular beat[/b][/color] — starts in ventricular muscle and spreads slowly, bypassing the His–Purkinje system (wide QRS)"
	if tv >= 0.0 and tv < float(iv["qrs"]):
		return "[color=#0B7A52][b]Ventricular depolarisation[/b][/color] — Purkinje fibres → myocardium · QRS complex"
	if av >= 0.0 and av <= 1.0 and not st.get("a_conducted", true) and rh != "af":
		return "[color=#B05500][b]Impulse blocked in the AV node[/b][/color] — this P wave is not conducted"
	if av >= 0.0 and av <= 1.0:
		return "[color=#B05500][b]AV-node delay[/b][/color] — conduction slows so the ventricles can fill · PR segment"
	if tv >= engine.his_start() - 0.004 and tv < 0.0:
		return "[color=#8A6800][b]His bundle → bundle branches[/b][/color] — fast conduction down the septum · end of PR"
	if rh != "af" and ta >= 0.0 and ta < 0.10:
		return "[color=#A86400][b]SA node fires → atrial depolarisation[/b][/color] — P wave"
	if tv >= float(iv["qrs"]) and tv < float(iv["qt"]):
		return "[color=#6D3FC8][b]Plateau and repolarisation[/b][/color] — ST segment → T wave"
	if rh == "af":
		return "[color=#A86400][b]Atrial fibrillation[/b][/color] — chaotic atrial wavelets; the AV node conducts irregularly"
	return "[color=#5B6B65][b]Electrical diastole[/b][/color] — waiting for the next impulse · TP segment"

func _update_live() -> void:
	var st := engine.get_ep_state()
	var iv := engine.get_intervals()
	var rh := engine.get_rhythm()
	var hemo := engine.get_hemodynamics()
	_vitals["hr"].text = "—" if rh == "vf" else "%d" % int(round(engine.hr))
	_vitals["rr"].text = "—" if rh == "vf" else "%d" % int(round(float(iv["rr"]) * 1000.0))
	_vitals["bp"].text = str(hemo.get("bp", "—"))
	_vitals["rhythm"].text = engine.get_condition_data(rhythm_id).get("name", "")
	if _now_label:
		_now_label.text = _status_text(st)
	if mode == "conduction":
		var act := _active_structures(st)
		for g in _seq_rows:
			var b: Button = _seq_rows[g]
			var on: bool = act.get(g, false)
			b.modulate = Color(1, 1, 1, 1.0) if (on or g == _selected_struct) else Color(1, 1, 1, 0.62)
			b.set_pressed_no_signal(false)
			b.add_theme_stylebox_override("normal", _row_style(conduction.get_group_color(g), on or g == _selected_struct))
	elif mode == "waves":
		var seg := engine.get_ecg_segment(recorder.latest_time())
		for w in _wave_rows:
			var on: bool = w == seg or (w == "PR" and seg == "P")
			(_wave_rows[w] as Button).add_theme_stylebox_override("normal", _row_style(EcgStrip.WAVE_COLORS.get(w, Pal.TEXT_MUTED), on or w == _selected_wave))
			(_wave_rows[w] as Button).modulate = Color(1, 1, 1, 1.0 if on or w == _selected_wave else 0.7)
		if _interval_labels.size() > 0:
			_interval_labels["pr"].text = "—" if float(iv["pr"]) < 0.0 else "%d ms" % int(round(float(iv["pr"]) * 1000.0))
			_interval_labels["qrs"].text = "%d ms" % int(round(float(iv["qrs"]) * 1000.0))
			_interval_labels["qt"].text = "%d ms" % int(round(float(iv["qt"]) * 1000.0))
			_interval_labels["qtc"].text = "%d ms" % int(round(float(iv["qtc"]) * 1000.0))
			_interval_labels["rr"].text = "%d ms" % int(round(float(iv["rr"]) * 1000.0))
			_interval_labels["hr"].text = "%d bpm" % int(round(engine.hr))
	elif mode == "twelve" and _axis_label:
		_axis_label.text = _qrs_axis_text()
	elif mode == "rhythms" and _rr_label:
		_rr_label.text = _rr_text(iv)

func _row_style(c: Color, on: bool) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = Color(c, 0.16) if on else Color(Pal.PANEL_RAISED, 0.55)
	s.border_color = Color(c, 0.9) if on else Color(0, 0, 0, 0)
	s.set_border_width_all(1)
	s.set_corner_radius_all(8)
	s.set_content_margin_all(8)
	return s

func _rr_text(iv: Dictionary) -> String:
	var rrs: PackedFloat32Array = iv.get("recent_rr", PackedFloat32Array())
	if engine.get_rhythm() == "vf" or rrs.size() < 2:
		return "[color=#5B6B65]Measuring RR intervals…[/color]"
	var parts := PackedStringArray()
	var mn := 9.0; var mx := 0.0
	for i in range(maxi(0, rrs.size() - 7), rrs.size()):
		parts.append("%d" % int(round(rrs[i] * 1000.0)))
		mn = minf(mn, rrs[i]); mx = maxf(mx, rrs[i])
	var spread := (mx - mn) * 1000.0
	var verdict := "regular" if spread < 40.0 else ("regularly irregular (premature beats)" if engine.get_rhythm() == "pvc" else "irregular")
	return "[b]Last RR intervals (ms)[/b]\n[color=#15241F]%s[/color]\n[color=#5B6B65]Spread %d ms → %s · mean rate %d bpm[/color]" % [
		"  ·  ".join(parts), int(round(spread)), verdict, int(round(60.0 / maxf(_mean(rrs), 0.01)))]

func _mean(a: PackedFloat32Array) -> float:
	var s := 0.0
	for x in a:
		s += x
	return s / maxf(a.size(), 1)

## Mean frontal QRS axis from the recorded heart vector over the most recent normally-conducted QRS.
func _qrs_axis_text() -> String:
	var now := recorder.latest_time()
	var qs := engine.get_qrs_onsets(now - 3.0, now - 0.12)
	if qs.is_empty() or engine.get_rhythm() == "vf":
		return "Frontal QRS axis: —"
	var q := qs[qs.size() - 1]
	var sx := 0.0; var sy := 0.0
	var t := q
	var dur := float(engine.get_intervals()["qrs"])
	while t < q + dur:
		var h := recorder.vector_at(t)
		if h != Vector3.INF:
			sx += h.x; sy += h.y
		t += 0.004
	var ang := rad_to_deg(atan2(-sy, sx))
	var cls := "normal (−30° to +90°)"
	if ang < -30.0 and ang >= -90.0: cls = "left axis deviation"
	elif ang > 90.0 and ang <= 180.0: cls = "right axis deviation"
	elif ang < -90.0: cls = "extreme axis"
	return "Frontal QRS axis ≈ %+d° · %s" % [int(round(ang)), cls]

## Screen area not covered by the panels (the 3D heart is centred in it).
func _free_rect() -> Rect2:
	if _left_panel == null or _right_panel == null:
		return Rect2()
	var l := _left_panel.get_global_rect(); var r := _right_panel.get_global_rect()
	var vp := get_viewport().get_visible_rect().size
	var x0 := l.end.x + 4 if _left_panel.visible else 12.0
	var x1 := r.position.x - 4 if _right_panel.visible else vp.x - 12.0
	var bottom := (_strip_panel.get_global_rect().position.y if _strip_panel.visible else _twelve_panel.get_global_rect().position.y)
	return Rect2(Vector2(x0, l.position.y), Vector2(x1 - x0, bottom - l.position.y - 4))

func _update_labels() -> void:
	var on := _t_labels != null and _t_labels.button_pressed and conduction.visible
	var cam3d := get_viewport().get_camera_3d()
	if cam3d == null:
		return
	var safe := _free_rect()
	if not safe.has_area():
		return
	for id in _labels:
		var lb: Label = _labels[id]
		if not on:
			lb.visible = false
			continue
		var wp := heart.to_global(conduction.get_group_center(id))
		if cam3d.is_position_behind(wp):
			lb.visible = false
			continue
		var sp := cam3d.unproject_position(wp)
		lb.reset_size()
		var pos := sp + Vector2(10, -lb.size.y * 0.5)
		lb.visible = safe.has_point(sp)
		lb.position = pos.clamp(safe.position, safe.end - lb.size)

# ================================================================== QA screenshots
func _settle(frames := 40) -> void:
	for i in frames:
		await get_tree().process_frame

## Fast-forwards the simulation so 10 s of ECG are recorded, then pauses at `offset` after a QRS onset.
func _warm_and_pause(offset: float) -> void:
	engine.playing = true
	engine.speed = 6.0
	while recorder.available_seconds() < 10.5:
		await get_tree().process_frame
	engine.playing = false
	engine.speed = 1.0
	await get_tree().process_frame
	var qs := engine.get_qrs_onsets(engine.sim_time - 3.0, engine.sim_time + 1.0)
	for q in qs:
		if q + offset > engine.sim_time:
			engine.sim_time = q + offset   # deterministic pause point (software rendering is slow)
			break
	await get_tree().process_frame

func _shot(dir: String, name_: String) -> void:
	await _settle(12)
	var img := get_viewport().get_texture().get_image()
	img.save_png(dir.path_join(name_ + ".png"))
	print("QA shot: ", name_)

func _run_qa_shots(dir: String) -> void:
	DirAccess.make_dir_recursive_absolute(dir)
	await _settle(30)
	_set_mode("conduction"); _select_rhythm("r_nsr"); _t_labels.button_pressed = true
	await _warm_and_pause(-0.022)
	await _shot(dir, "01_conduction_his")
	_t_labels.button_pressed = false; _t_cut.button_pressed = true
	await _warm_and_pause(0.03)
	await _shot(dir, "02_conduction_qrs_4ch")
	_set_overlay(2); _t_conduction.button_pressed = false
	await _shot(dir, "03_isochrones")
	_t_cut.button_pressed = false; _t_conduction.button_pressed = true; cam.reset_view(false)
	_set_mode("waves"); _show_wave("QRS")
	await _warm_and_pause(0.25)
	await _shot(dir, "04_ecg_waves")
	_set_mode("twelve")
	await _warm_and_pause(0.04)
	await _shot(dir, "05_twelve_lead")
	_set_mode("rhythms"); _select_rhythm("r_af")
	await _warm_and_pause(0.02)
	await _shot(dir, "06_rhythm_af")
	engine.ep_pvc_every = 3; _select_rhythm("r_pvc")
	await _warm_and_pause(0.06)
	await _shot(dir, "07_rhythm_pvc")
	_select_rhythm("r_vt")
	await _warm_and_pause(0.05)
	await _shot(dir, "08_rhythm_vt")
	_set_mode("twelve"); engine.set_condition("anterior_stemi"); recorder.clear(); _twelve.show_walls = true
	await _warm_and_pause(0.1)
	await _shot(dir, "09_twelve_stemi_walls")
	get_tree().quit()
