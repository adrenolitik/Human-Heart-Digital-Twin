## EcgRecorder (Stage 2)
## Samples the simulated cardiac dipole (CardiacEngine.ecg_vector) at a fixed rate in simulation time
## and keeps the last `history_s` seconds. Every ECG view reads from this one buffer, so all leads are
## computed from the same heart vector and switching leads is instant.
class_name EcgRecorder
extends Node

const RATE := 250.0                # samples per simulated second (1 sample = 4 ms = 0.1 mm at 25 mm/s)

var engine: CardiacEngine
var history_s := 12.0
var frozen := false                # when true the buffer stops updating (study a still tracing)
var _h := PackedVector3Array()     # ring buffer of dipole samples
var _n := 0                        # number of valid samples
var _head := 0                     # index of the next write
var _t := 0.0                      # simulation time of the next sample

func _ready() -> void:
	clear()

func clear() -> void:
	_h.resize(int(history_s * RATE))
	_n = 0
	_head = 0
	_t = engine.sim_time if engine else 0.0

func _process(_d: float) -> void:
	if engine == null or frozen:
		return
	var now := engine.sim_time
	if now < _t - 0.05:
		clear()
	var count := int((now - _t) * RATE)
	if count > _h.size():
		_t = now - float(_h.size()) / RATE
		count = _h.size()
	for i in count:
		_h[_head] = engine.ecg_vector(_t)
		_head = (_head + 1) % _h.size()
		_n = mini(_n + 1, _h.size())
		_t += 1.0 / RATE

## Simulation time of the newest sample.
func latest_time() -> float:
	return _t - 1.0 / RATE

func available_seconds() -> float:
	return _n / RATE

## Dipole at absolute simulation time t (nearest sample); Vector3.INF if not recorded.
func vector_at(t: float) -> Vector3:
	var back := int(round((latest_time() - t) * RATE))
	if back < 0 or back >= _n:
		return Vector3.INF
	return _h[(_head - 1 - back + _h.size()) % _h.size()]

## Lead voltages for the window [t0, t0 + dur] at `step` samples.
func lead_samples(lead: String, t0: float, dur: float, step := 1) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	var ax := CardiacEngine.lead_axis(lead) * CardiacEngine.lead_gain(lead)
	var n := int(dur * RATE)
	var i := 0
	while i < n:
		var h := vector_at(t0 + i / RATE)
		out.append(NAN if h == Vector3.INF else h.dot(ax))
		i += step
	return out
