## LeadAxes3D (Stage 2)
## Shows, around the beating heart, (a) the axes of the ECG leads and (b) the instantaneous cardiac
## vector (dipole) with its recent loop (a vectorcardiogram). A lead records a positive deflection when
## the vector points toward its positive end — the core idea behind why the 12 leads look different.
## Lives in HeartModel space (x = patient's left, y = superior, z = anterior).
class_name LeadAxes3D
extends Node3D

const Pal := preload("res://scripts/ui/ui_palette.gd")
const FRONTAL := ["I", "II", "III", "aVR", "aVL", "aVF"]
const PRECORDIAL := ["V1", "V2", "V3", "V4", "V5", "V6"]

var recorder: EcgRecorder
var engine: CardiacEngine
var center := Vector3.ZERO
var axis_len := 0.085
var vec_scale := 0.030         # metres per mV-equivalent
var plane := "frontal"         # "frontal" | "horizontal" | "none"
var selected := "II"
var show_vector := true
var show_loop := true

var _lines: MeshInstance3D
var _im: ImmediateMesh
var _labels := {}
var _arrow: MeshInstance3D
var _arrow_shaft: CylinderMesh
var _arrow_head: MeshInstance3D
var _mat_lines: StandardMaterial3D
var _mat_arrow: StandardMaterial3D

func _ready() -> void:
	_im = ImmediateMesh.new()
	_lines = MeshInstance3D.new()
	_lines.mesh = _im
	_lines.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_mat_lines = StandardMaterial3D.new()
	_mat_lines.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_mat_lines.vertex_color_use_as_albedo = true
	_mat_lines.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_mat_lines.no_depth_test = true
	_mat_lines.render_priority = 5
	_lines.material_override = _mat_lines
	add_child(_lines)
	for l in FRONTAL + PRECORDIAL:
		var lb := Label3D.new()
		lb.text = l
		lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		lb.no_depth_test = true
		lb.fixed_size = true
		lb.pixel_size = 0.0005
		lb.font_size = 26
		lb.outline_size = 8
		lb.outline_modulate = Color(0, 0, 0, 0.85)
		lb.render_priority = 6
		add_child(lb)
		_labels[l] = lb
	_mat_arrow = StandardMaterial3D.new()
	_mat_arrow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_mat_arrow.albedo_color = Color("#4FE3FF")
	_mat_arrow.no_depth_test = true
	_mat_arrow.render_priority = 7
	_arrow = MeshInstance3D.new()
	_arrow_shaft = CylinderMesh.new()
	_arrow_shaft.top_radius = 0.0011; _arrow_shaft.bottom_radius = 0.0011; _arrow_shaft.height = 1.0
	_arrow_shaft.radial_segments = 8; _arrow_shaft.rings = 1
	_arrow.mesh = _arrow_shaft
	_arrow.material_override = _mat_arrow
	add_child(_arrow)
	_arrow_head = MeshInstance3D.new()
	var cone := CylinderMesh.new()
	cone.top_radius = 0.0; cone.bottom_radius = 0.0035; cone.height = 0.008; cone.radial_segments = 10; cone.rings = 1
	_arrow_head.mesh = cone
	_arrow_head.material_override = _mat_arrow
	add_child(_arrow_head)

func _process(_d: float) -> void:
	if not visible:
		return
	_im.clear_surfaces()
	_im.surface_begin(Mesh.PRIMITIVE_LINES)
	var leads: Array = FRONTAL if plane == "frontal" else (PRECORDIAL if plane == "horizontal" else [])
	for l in _labels:
		(_labels[l] as Label3D).visible = l in leads
	for l in leads:
		var ax := CardiacEngine.lead_axis(l)
		var sel: bool = l == selected
		var c := Color("#22B8D9") if sel else Color(0.80, 0.86, 0.95, 0.55)
		var neg := Color(c, 0.18)
		# positive half solid, negative half faint (dashed)
		_seg(center, center + ax * axis_len, c)
		var n := 8
		for i in n:
			if i % 2 == 0:
				_seg(center - ax * axis_len * float(i) / n, center - ax * axis_len * float(i + 1) / n, neg)
		var lb: Label3D = _labels[l]
		lb.position = center + ax * (axis_len + 0.008)
		lb.modulate = Color("#4FE3FF") if sel else Color(0.86, 0.90, 0.97, 0.9)
		lb.font_size = 30 if sel else 24
	var h := Vector3.ZERO
	if recorder and recorder.available_seconds() > 0.1:
		h = recorder.vector_at(recorder.latest_time())
		if show_loop:
			var prev := Vector3.INF
			var t := recorder.latest_time() - 0.5
			while t <= recorder.latest_time():
				var v := recorder.vector_at(t)
				if v != Vector3.INF:
					var p := center + v * vec_scale
					if prev != Vector3.INF:
						var age := (recorder.latest_time() - t) / 0.5
						_seg(prev, p, Color(0.31, 0.89, 1.0, 0.85 * (1.0 - age)))
					prev = p
				t += 0.008
		# projection of the vector on the selected lead axis
		if selected in leads:
			var ax := CardiacEngine.lead_axis(selected)
			var proj := h.dot(ax)
			var c := Color("#3DDC84") if proj >= 0.0 else Color("#F05D5E")
			_seg(center, center + ax * proj * vec_scale, c)
			_seg(center + h * vec_scale, center + ax * proj * vec_scale, Color(1, 1, 1, 0.25))
	_im.surface_end()
	var vlen := h.length() * vec_scale
	_arrow.visible = show_vector and vlen > 0.002
	_arrow_head.visible = _arrow.visible
	if _arrow.visible:
		var dir := h.normalized()
		var basis := _basis_from_y(dir)
		var shaft := maxf(vlen - 0.006, 0.001)
		_arrow.transform = Transform3D(Basis(basis.x, basis.y * shaft, basis.z), center + dir * shaft * 0.5)
		_arrow_head.transform = Transform3D(basis, center + dir * (shaft + 0.004))

func _seg(a: Vector3, b: Vector3, c: Color) -> void:
	_im.surface_set_color(c); _im.surface_add_vertex(a)
	_im.surface_set_color(c); _im.surface_add_vertex(b)

func _basis_from_y(y: Vector3) -> Basis:
	var x := y.cross(Vector3.FORWARD if absf(y.dot(Vector3.FORWARD)) < 0.95 else Vector3.RIGHT).normalized()
	var z := x.cross(y).normalized()
	return Basis(x, y, z)
