## TwelveLeadView (Stage 2)
## Paper-style educational 12-lead ECG: standard 3 × 4 layout (2.5 s per column) plus a 10 s lead II
## rhythm strip, drawn to the real paper scale (25 mm/s, 10 mm/mV, 1 mm / 5 mm grid). All leads are
## projections of the same simulated heart vector (EcgRecorder). Clicking a lead selects it.
## Lead groups can be tinted to show which wall of the heart each lead "looks at".
class_name TwelveLeadView
extends Control

signal lead_selected(lead: String)

const LAYOUT := [["I", "aVR", "V1", "V4"], ["II", "aVL", "V2", "V5"], ["III", "aVF", "V3", "V6"]]
## Contiguous lead groups and the region they face (standard teaching grouping).
const WALLS := {
	"inferior": {"name": "Inferior", "leads": ["II", "III", "aVF"], "color": "#F5B841"},
	"lateral": {"name": "Lateral", "leads": ["I", "aVL", "V5", "V6"], "color": "#5EE6C1"},
	"septal": {"name": "Septal", "leads": ["V1", "V2"], "color": "#7FB2FF"},
	"anterior": {"name": "Anterior", "leads": ["V3", "V4"], "color": "#FF8FA3"},
	"cavity": {"name": "Right upper / cavity view", "leads": ["aVR"], "color": "#B0B8C8"},
}

var recorder: EcgRecorder
var engine: CardiacEngine
var selected := "II"
var show_walls := false
var refresh_hz := 6.0
var _acc := 0.0
var _t_end := 0.0
var _cells := {}      # lead -> Rect2

func _ready() -> void:
	custom_minimum_size = Vector2(560, 260)
	mouse_filter = Control.MOUSE_FILTER_STOP

func _process(d: float) -> void:
	if not is_visible_in_tree() or recorder == null:
		return
	_acc += d
	if _acc >= 1.0 / refresh_hz:
		_acc = 0.0
		queue_redraw()

func wall_of(lead: String) -> String:
	for k in WALLS:
		if lead in WALLS[k]["leads"]:
			return k
	return ""

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		for l in _cells:
			if (_cells[l] as Rect2).has_point(event.position):
				selected = l
				lead_selected.emit(l)
				queue_redraw()
				accept_event()
				return

func _draw() -> void:
	_cells.clear()
	var paper := Color("#FBF3EE")
	draw_rect(Rect2(Vector2.ZERO, size), Color("#1A1416"))
	if recorder == null:
		return
	# 10 s = 250 mm wide (+6 mm margin for calibration); 4 rows of 22 mm (+8 mm header)
	var mm := minf(size.x / 258.0, size.y / 98.0)
	var w := 258.0 * mm
	var h := 98.0 * mm
	var o := Vector2((size.x - w) * 0.5, (size.y - h) * 0.5)
	draw_rect(Rect2(o, Vector2(w, h)), paper)
	var minor := Color(0.94, 0.62, 0.62, 0.35)
	var major := Color(0.86, 0.36, 0.38, 0.55)
	var gx := 0
	while gx <= 258:
		var c := major if gx % 5 == 0 else minor
		if mm >= 2.2 or gx % 5 == 0:
			draw_line(o + Vector2(gx * mm, 8 * mm), o + Vector2(gx * mm, h), c, 1.0)
		gx += 1
	var gy := 8
	while gy <= 98:
		var c := major if (gy - 8) % 5 == 0 else minor
		if mm >= 2.2 or (gy - 8) % 5 == 0:
			draw_line(o + Vector2(0, gy * mm), o + Vector2(w, gy * mm), c, 1.0)
		gy += 1
	var f := get_theme_default_font()
	var ink := Color("#1C1C24")
	var now := recorder.latest_time()
	var avail := recorder.available_seconds()
	var t_start := now - 10.0
	if avail < 10.0:
		draw_string(f, o + Vector2(w * 0.5 - 40 * mm, h * 0.5), "Recording… %.0f s" % avail, HORIZONTAL_ALIGNMENT_CENTER, int(80 * mm), 16, ink)
	for row in 4:
		var base := o + Vector2(0, (8.0 + 22.0 * row + 13.0) * mm)
		# calibration pulse: 1 mV (10 mm) for 0.2 s (5 mm)
		var cal := PackedVector2Array([base + Vector2(0.5 * mm, 0), base + Vector2(1.5 * mm, 0), base + Vector2(1.5 * mm, -10 * mm),
			base + Vector2(6.5 * mm, -10 * mm), base + Vector2(6.5 * mm, 0), base + Vector2(7.5 * mm, 0)])
		draw_polyline(cal, ink, 1.4)
		if row < 3:
			for col in 4:
				var lead: String = LAYOUT[row][col]
				var x0 := 8.0 + 62.5 * col
				var cell := Rect2(o + Vector2(x0 * mm, (8.0 + 22.0 * row) * mm), Vector2(62.5 * mm, 22.0 * mm))
				_cells[lead] = cell
				if show_walls and wall_of(lead) != "":
					draw_rect(cell, Color(Color(WALLS[wall_of(lead)]["color"]), 0.16))
				_trace(lead, t_start + 2.5 * col, 2.5, base + Vector2(x0 * mm, 0), mm, ink)
				if lead == selected:
					draw_rect(cell.grow(-1), Color("#0E8FB0"), false, 2.0)
				draw_string(f, cell.position + Vector2(1.5 * mm, 4.2 * mm), lead, HORIZONTAL_ALIGNMENT_LEFT, -1, maxi(12, int(3.2 * mm)), ink)
				if col > 0:
					draw_line(cell.position + Vector2(0, 6 * mm), cell.position + Vector2(0, 16 * mm), ink, 1.2)
		else:
			var cell := Rect2(o + Vector2(8.0 * mm, (8.0 + 66.0) * mm), Vector2(250.0 * mm, 22.0 * mm))
			_trace("II", t_start, 10.0, base + Vector2(8.0 * mm, 0), mm, ink)
			draw_string(f, cell.position + Vector2(1.5 * mm, 4.2 * mm), "II  (rhythm strip, 10 s)", HORIZONTAL_ALIGNMENT_LEFT, -1, maxi(12, int(3.0 * mm)), ink)
	# header band drawn last so tall complexes never cover the caption
	draw_rect(Rect2(o, Vector2(w, 7.6 * mm)), paper)
	draw_string(f, o + Vector2(2 * mm, 5.6 * mm), "SIMULATED EDUCATIONAL 12-LEAD ECG — not a patient recording, not diagnostic", HORIZONTAL_ALIGNMENT_LEFT, -1, maxi(12, int(2.6 * mm)), Color("#8A2B2B"))
	var info := "25 mm/s   10 mm/mV"
	if engine:
		var iv := engine.get_intervals()
		info += "   HR %d /min" % int(round(60.0 / maxf(float(iv["rr"]), 0.01)))
	draw_string(f, o + Vector2(w - 70 * mm, 5.6 * mm), info, HORIZONTAL_ALIGNMENT_RIGHT, int(68 * mm), maxi(12, int(2.6 * mm)), ink)

func _trace(lead: String, t0: float, dur: float, origin: Vector2, mm: float, ink: Color) -> void:
	var step := 1 if mm >= 3.0 else 2
	var s := recorder.lead_samples(lead, t0, dur, step)
	var pts := PackedVector2Array()
	var dx := 25.0 * mm / EcgRecorder.RATE * step
	for i in s.size():
		if is_nan(s[i]):
			if pts.size() > 1:
				draw_polyline(pts, ink, 1.3, true)
			pts.clear()
			continue
		pts.append(origin + Vector2(i * dx, -s[i] * 10.0 * mm))
	if pts.size() > 1:
		draw_polyline(pts, ink, 1.3, true)
