## EcgStrip (Stage 2)
## Bedside-monitor sweep of one lead with optional teaching annotations:
##   * wave bands (P, QRS, ST, T) with text labels — colour is never the only cue
##   * PR / QRS / QT interval brackets and RR intervals (ms) between consecutive beats
##   * the component under the sweep cursor is emphasised, in sync with the 3D heart
## Clicking a band emits `wave_selected` so the explanation panel can follow the student.
class_name EcgStrip
extends Control

signal wave_selected(wave: String)

const Pal := preload("res://scripts/ui/ui_palette.gd")
const WAVE_COLORS := {
	"P": Color("#F5B841"), "PR": Color("#C9A86A"), "QRS": Color("#22B8D9"),
	"ST": Color("#8C9AB3"), "T": Color("#B58CFF"), "RR": Color("#E6EDF5"), "ECT": Color("#F05D5E"),
}

var engine: CardiacEngine
var recorder: EcgRecorder
var lead := "II"
var window_s := 6.0
var annotate_waves := true
var annotate_intervals := true
var show_rr := true
var trace_color := Color("#3DDC84")
var _bands: Array = []       # [Rect2, wave] for hit testing

func _ready() -> void:
	custom_minimum_size = Vector2(320, 170)
	mouse_filter = Control.MOUSE_FILTER_STOP
	tooltip_text = "Click a labelled wave to read about it"

func _process(_d: float) -> void:
	if is_visible_in_tree():
		queue_redraw()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		for b in _bands:
			if (b[0] as Rect2).has_point(event.position):
				wave_selected.emit(b[1])
				accept_event()
				return

func _x(t: float) -> float:
	return fposmod(t, window_s) / window_s * size.x

func _draw() -> void:
	_bands.clear()
	var r := Rect2(Vector2.ZERO, size)
	draw_rect(r, Color("#06100D"))
	if engine == null or recorder == null:
		return
	var f := get_theme_default_font()
	var top := 24.0
	var bottom := size.y - (34.0 if annotate_intervals else 10.0)
	var base_y := top + (bottom - top) * 0.62
	var px_mv := (bottom - top) * 0.36
	# grid: 0.2 s / 0.5 mV major, 0.04 s minor
	var px_s := size.x / window_s
	var minor := Color(0.16, 0.36, 0.26, 0.16)
	var major := Color(0.18, 0.42, 0.30, 0.38)
	var x := 0.0
	var k := 0
	while x <= size.x:
		draw_line(Vector2(x, top - 6), Vector2(x, bottom), major if k % 5 == 0 else minor, 1.0)
		x += px_s * 0.04
		k += 1
	var y := base_y
	while y > top - 6:
		draw_line(Vector2(0, y), Vector2(size.x, y), major, 1.0)
		y -= px_mv * 0.5
	y = base_y + px_mv * 0.5
	while y < bottom:
		draw_line(Vector2(0, y), Vector2(size.x, y), major, 1.0)
		y += px_mv * 0.5
	var now := recorder.latest_time()
	var t0 := now - window_s + 0.12
	var iv := engine.get_intervals()
	var seg_now := engine.get_ecg_segment(now)
	# --- annotation bands (behind the trace)
	var beats := engine.get_beats_between(t0 - 0.6, now)
	var rhythm := engine.get_rhythm()
	var qt: float = iv["qt"]
	if annotate_waves and rhythm != "vf":
		for b in beats:
			var tb: float = b["t"]
			if b["kind"] == "p" and rhythm != "af":
				_band(tb, tb + 0.10, "P", top, bottom, now, seg_now, f, t0)
			elif b["kind"] != "p":
				var ect: bool = b["kind"] == "ectopic"
				var qrs := 0.15 if ect else float(iv["qrs"]) * (1.0 if rhythm != "vt" else 1.0)
				var qt_b := clampf(qt, 0.2, 0.5)
				var t_on := tb + qt_b * 0.72 - 0.085
				_band(tb, tb + qrs, "QRS" if not ect else "QRS*", top, bottom, now, seg_now, f, t0)
				if t_on > tb + qrs + 0.01:
					_band(tb + qrs, t_on, "ST", top, bottom, now, seg_now, f, t0)
				_band(t_on, tb + qt_b + 0.01, "T", top, bottom, now, seg_now, f, t0)
	# --- trace (sweep: newest at the cursor, a short erase gap ahead of it)
	var pts := PackedVector2Array()
	var ax := CardiacEngine.lead_axis(lead) * CardiacEngine.lead_gain(lead)
	var step := 1.0 / EcgRecorder.RATE * 2.0
	var t := t0
	var last_x := -1.0
	while t <= now:
		var h := recorder.vector_at(t)
		var px := _x(t)
		if h == Vector3.INF or px < last_x:
			if pts.size() > 1:
				draw_polyline(pts, trace_color, 1.8, true)
			pts.clear()
		if h != Vector3.INF:
			pts.append(Vector2(px, base_y - h.dot(ax) * px_mv))
		last_x = px
		t += step
	if pts.size() > 1:
		draw_polyline(pts, trace_color, 1.8, true)
	var cx := _x(now)
	draw_line(Vector2(cx, top - 6), Vector2(cx, bottom), Color(1, 1, 1, 0.25), 1.0)
	if pts.size() > 0:
		draw_circle(pts[pts.size() - 1], 3.0, Color(0.85, 1.0, 0.92))
	# --- RR intervals (top) and PR / QT brackets (bottom)
	var qs := engine.get_qrs_onsets(t0, now)
	if show_rr:
		for i in range(1, qs.size()):
			var xa := _x(qs[i - 1]); var xb := _x(qs[i])
			if xb <= xa:
				continue
			var rr_ms := (qs[i] - qs[i - 1]) * 1000.0
			_bracket(xa, xb, top - 2, "RR %d ms" % int(round(rr_ms)), WAVE_COLORS["RR"], f, true)
	if annotate_intervals and rhythm != "vf":
		var last_p := -1e9
		for b in beats:
			if b["kind"] == "p":
				last_p = b["t"]
			elif b["kind"] == "qrs" and b["t"] >= t0:
				var tb: float = b["t"]
				var yb := bottom + 14
				if last_p > tb - 0.32 and last_p >= t0 and rhythm in ["sinus", "pvc"]:
					var xa := _x(last_p); var xq := _x(tb)
					if xq > xa:
						_bracket(xa, xq, yb, "PR %d" % int(round((tb - last_p) * 1000.0)), WAVE_COLORS["P"], f, false, true)
				var xe := _x(tb + qt)
				if xe > _x(tb) and tb + qt <= now:
					_bracket(_x(tb), xe, yb + 14, "QT %d" % int(round(qt * 1000.0)), WAVE_COLORS["T"], f, false, true)
	# --- captions
	draw_string(f, Vector2(10, 16), lead, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, trace_color)
	draw_string(f, Vector2(44, 16), "25 mm/s · 0.2 s per large square", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(0.62, 0.78, 0.70))
	draw_string(f, Vector2(size.x - 230, 16), "SIMULATED · not diagnostic", HORIZONTAL_ALIGNMENT_RIGHT, 220, 12, Color(0.96, 0.72, 0.25))
	draw_line(Vector2(6, base_y), Vector2(6, base_y - px_mv), trace_color, 2.0)
	draw_string(f, Vector2(10, base_y - px_mv + 12), "1 mV", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(0.62, 0.78, 0.70))

func _band(ta: float, tb: float, wave: String, top: float, bottom: float, now: float, seg_now: String, f: Font, t0: float) -> void:
	if tb < t0 or ta > now:
		return
	ta = maxf(ta, t0)
	tb = minf(tb, now)
	var xa := _x(ta); var xb := _x(tb)
	if xb <= xa + 1.0:
		return
	var key := "QRS" if wave == "QRS*" else wave
	var c: Color = WAVE_COLORS["ECT"] if wave == "QRS*" else WAVE_COLORS.get(key, Color.WHITE)
	var active := seg_now == key and now - tb < 0.02
	draw_rect(Rect2(xa, top, xb - xa, bottom - top), Color(c, 0.22 if active else 0.08))
	if active:
		draw_rect(Rect2(xa, top, xb - xa, bottom - top), Color(c, 0.8), false, 1.5)
	var label := "PVC" if (wave == "QRS*" and engine.get_rhythm() == "pvc") else ("QRS" if wave == "QRS*" else wave)
	var ly := top + (30.0 if wave == "ST" else 14.0)
	if (wave != "ST" or xb - xa > 16.0):
		draw_string(f, Vector2((xa + xb) * 0.5 - 30, ly), label, HORIZONTAL_ALIGNMENT_CENTER, 60, 12, c.lightened(0.2))
	_bands.append([Rect2(xa, top, maxf(xb - xa, 10.0), bottom - top), key])

func _bracket(xa: float, xb: float, y: float, text: String, c: Color, f: Font, up: bool, force := false) -> void:
	var d := 4.0 if up else -4.0
	draw_line(Vector2(xa, y), Vector2(xb, y), Color(c, 0.7), 1.0)
	draw_line(Vector2(xa, y), Vector2(xa, y + d), Color(c, 0.7), 1.0)
	draw_line(Vector2(xb, y), Vector2(xb, y + d), Color(c, 0.7), 1.0)
	var tw := f.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, 12).x
	if xb - xa > tw + 12.0 or (force and xb - xa > 20.0):
		var mid := (xa + xb) * 0.5
		draw_rect(Rect2(mid - tw * 0.5 - 3, y - 7, tw + 6, 14), Color("#06100D"))
		draw_string(f, Vector2(mid - tw * 0.5, y + 4), text, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, c)
