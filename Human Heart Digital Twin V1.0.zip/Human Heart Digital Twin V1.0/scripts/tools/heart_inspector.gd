## Legacy redirect: the Milestone-1 model inspector was replaced by the Heart Lab (Update 2).
## This file only exists so an older copy of the project folder keeps working; it can be deleted
## together with scenes/tools/heart_inspector.tscn.
extends Node

func _ready() -> void:
	get_tree().change_scene_to_file.call_deferred("res://scenes/stage1/heart_lab.tscn")
