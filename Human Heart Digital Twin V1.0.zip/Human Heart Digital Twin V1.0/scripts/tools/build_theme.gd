## Generates res://assets/ui/theme.tres (run headless, see docs/02_Architecture.md):
##   godot --headless --path . -s res://scripts/tools/build_theme.gd
extends SceneTree

const P := preload("res://scripts/ui/ui_palette.gd")

func _init() -> void:
	var th := Theme.new()
	var regular: FontFile = load("res://assets/fonts/Inter-Regular.ttf")
	var medium: FontFile = load("res://assets/fonts/Inter-Medium.ttf")
	var semibold: FontFile = load("res://assets/fonts/Inter-SemiBold.ttf")
	th.default_font = regular
	th.default_font_size = 16

	# --- Panels
	var panel := _box(P.PANEL, P.BORDER, P.RADIUS, P.SP_L)
	th.set_stylebox("panel", "PanelContainer", panel)
	th.set_stylebox("panel", "Panel", panel)

	# --- Labels
	th.set_color("font_color", "Label", P.TEXT)
	th.set_type_variation("HeaderLarge", "Label")
	th.set_font("font", "HeaderLarge", semibold); th.set_font_size("font_size", "HeaderLarge", 30)
	th.set_type_variation("HeaderMedium", "Label")
	th.set_font("font", "HeaderMedium", semibold); th.set_font_size("font_size", "HeaderMedium", 20)
	th.set_type_variation("HeaderSmall", "Label")
	th.set_font("font", "HeaderSmall", medium); th.set_font_size("font_size", "HeaderSmall", 13)
	th.set_color("font_color", "HeaderSmall", P.TEXT_MUTED)
	th.set_type_variation("MutedLabel", "Label")
	th.set_color("font_color", "MutedLabel", P.TEXT_MUTED); th.set_font_size("font_size", "MutedLabel", 14)
	th.set_color("default_color", "RichTextLabel", P.TEXT)
	th.set_font("bold_font", "RichTextLabel", semibold)

	# --- Buttons
	var b_normal := _box(P.PANEL_RAISED, P.BORDER, 8, 0); _pad(b_normal, 14, 8)
	var b_hover := _box(P.ACCENT_TINT, P.ACCENT, 8, 0); _pad(b_hover, 14, 8)
	var b_pressed := _box(P.ACCENT_TINT.darkened(0.04), P.ACCENT, 8, 0); _pad(b_pressed, 14, 8)
	var b_disabled := _box(Color(P.PANEL, 0.6), Color(P.BORDER, 0.5), 8, 0); _pad(b_disabled, 14, 8)
	var b_focus := _box(Color(0, 0, 0, 0), P.ACCENT, 8, 0); b_focus.set_border_width_all(2); b_focus.draw_center = false
	for t in ["Button", "OptionButton", "MenuButton"]:
		th.set_stylebox("normal", t, b_normal); th.set_stylebox("hover", t, b_hover)
		th.set_stylebox("pressed", t, b_pressed); th.set_stylebox("disabled", t, b_disabled)
		th.set_stylebox("focus", t, b_focus)
		th.set_color("font_color", t, P.TEXT); th.set_color("font_hover_color", t, P.ACCENT_HOVER)
		th.set_color("font_pressed_color", t, P.ACCENT); th.set_color("font_disabled_color", t, Color(P.TEXT_MUTED, 0.6))
		th.set_font("font", t, medium); th.set_font_size("font_size", t, 15)
	th.set_stylebox("hover_pressed", "Button", b_pressed)
	# SVG icons are white; tint them through the theme so they follow the button state.
	for t in ["Button", "OptionButton", "MenuButton", "CheckButton", "CheckBox"]:
		th.set_constant("icon_max_width", t, 18)
		th.set_constant("h_separation", t, 8)
		th.set_color("icon_normal_color", t, P.TEXT_MUTED)
		th.set_color("icon_hover_color", t, P.ACCENT)
		th.set_color("icon_pressed_color", t, P.ACCENT)
		th.set_color("icon_hover_pressed_color", t, P.ACCENT)
		th.set_color("icon_focus_color", t, P.ACCENT)
		th.set_color("icon_disabled_color", t, Color(P.TEXT_MUTED, 0.4))
	# Segmented-control button: transparent until selected, then an accent-tinted fill.
	th.set_type_variation("SegmentButton", "Button")
	var sg := StyleBoxEmpty.new(); _pad_empty(sg, 12, 6)
	var sgh := _box(Color(P.ACCENT, 0.06), Color(0, 0, 0, 0), 7, 0); _pad(sgh, 12, 6)
	var sgp := _box(P.ACCENT, P.ACCENT, 7, 0); _pad(sgp, 12, 6)
	th.set_stylebox("normal", "SegmentButton", sg); th.set_stylebox("hover", "SegmentButton", sgh)
	th.set_stylebox("pressed", "SegmentButton", sgp); th.set_stylebox("hover_pressed", "SegmentButton", sgp)
	th.set_color("font_color", "SegmentButton", P.TEXT_MUTED); th.set_color("font_hover_color", "SegmentButton", P.TEXT)
	th.set_color("font_pressed_color", "SegmentButton", Color.WHITE); th.set_color("font_hover_pressed_color", "SegmentButton", Color.WHITE)
	th.set_color("icon_pressed_color", "SegmentButton", Color.WHITE); th.set_color("icon_hover_pressed_color", "SegmentButton", Color.WHITE)
	th.set_font("font", "SegmentButton", medium); th.set_font_size("font_size", "SegmentButton", 14)
	# Ghost button: outlined, for secondary actions in cards.
	th.set_type_variation("GhostButton", "Button")
	var gb := _box(Color(0, 0, 0, 0), P.BORDER, 8, 0); _pad(gb, 12, 6)
	var gbh := _box(Color(P.ACCENT, 0.08), P.ACCENT_DIM, 8, 0); _pad(gbh, 12, 6)
	th.set_stylebox("normal", "GhostButton", gb); th.set_stylebox("hover", "GhostButton", gbh)
	th.set_stylebox("pressed", "GhostButton", _box(Color(P.ACCENT, 0.16), P.ACCENT, 8, 0))
	th.set_stylebox("hover_pressed", "GhostButton", _box(Color(P.ACCENT, 0.16), P.ACCENT, 8, 0))
	th.set_font_size("font_size", "GhostButton", 14)
	# Card-like list button (rhythm / condition pickers): left aligned, raised when selected.
	th.set_type_variation("ListButton", "Button")
	var lb := _box(P.PANEL_RAISED, Color(0, 0, 0, 0), 8, 0); _pad(lb, 12, 8)
	var lbh := _box(Color(P.ACCENT, 0.07), P.BORDER, 8, 0); _pad(lbh, 12, 8)
	var lbp := _box(P.ACCENT_TINT, P.ACCENT, 8, 0); _pad(lbp, 12, 8)
	th.set_stylebox("normal", "ListButton", lb); th.set_stylebox("hover", "ListButton", lbh)
	th.set_stylebox("pressed", "ListButton", lbp); th.set_stylebox("hover_pressed", "ListButton", lbp)
	th.set_color("font_pressed_color", "ListButton", P.ACCENT_HOVER); th.set_color("font_hover_pressed_color", "ListButton", P.ACCENT_HOVER)
	th.set_font_size("font_size", "ListButton", 14)
	# Primary (accent) button variation
	th.set_type_variation("PrimaryButton", "Button")
	var pb := _box(P.ACCENT_DIM, P.ACCENT, 8, 0); _pad(pb, 18, 10)
	var pbh := _box(P.ACCENT_HOVER, P.ACCENT_HOVER, 8, 0); _pad(pbh, 18, 10)
	th.set_stylebox("normal", "PrimaryButton", pb); th.set_stylebox("hover", "PrimaryButton", pbh)
	th.set_stylebox("pressed", "PrimaryButton", pb)
	th.set_color("font_color", "PrimaryButton", Color.WHITE); th.set_color("font_pressed_color", "PrimaryButton", Color.WHITE)
	th.set_color("font_hover_color", "PrimaryButton", Color.WHITE); th.set_color("font_hover_pressed_color", "PrimaryButton", Color.WHITE)
	for ic in ["icon_normal_color", "icon_hover_color", "icon_pressed_color", "icon_hover_pressed_color", "icon_focus_color"]:
		th.set_color(ic, "PrimaryButton", Color.WHITE)
	th.set_font("font", "PrimaryButton", semibold)
	# Flat tool button
	th.set_type_variation("FlatButton", "Button")
	var fb := StyleBoxEmpty.new(); fb.content_margin_left = 8; fb.content_margin_right = 8; fb.content_margin_top = 6; fb.content_margin_bottom = 6
	var fbh := _box(Color(P.ACCENT, 0.10), Color(0, 0, 0, 0), 6, 0); _pad(fbh, 8, 6)
	th.set_stylebox("normal", "FlatButton", fb); th.set_stylebox("hover", "FlatButton", fbh); th.set_stylebox("pressed", "FlatButton", fbh)
	th.set_color("font_color", "FlatButton", P.TEXT_MUTED); th.set_color("font_hover_color", "FlatButton", P.TEXT)

	# --- CheckBox / CheckButton
	for t in ["CheckBox", "CheckButton"]:
		th.set_color("font_color", t, P.TEXT); th.set_color("font_hover_color", t, P.ACCENT_HOVER)
		th.set_color("font_pressed_color", t, P.TEXT); th.set_font_size("font_size", t, 14)
		var e := StyleBoxEmpty.new(); e.content_margin_top = 2; e.content_margin_bottom = 2
		for st in ["normal", "pressed", "hover", "hover_pressed", "focus"]:
			th.set_stylebox(st, t, e)
	# Light-theme switch / checkbox icons (Godot's defaults are pale grey and vanish on white)
	var sw_off := _switch_icon(false, false); var sw_on := _switch_icon(true, false)
	for nm in ["unchecked", "unchecked_mirrored"]:
		th.set_icon(nm, "CheckButton", sw_off)
	for nm in ["checked", "checked_mirrored"]:
		th.set_icon(nm, "CheckButton", sw_on)
	th.set_icon("unchecked_disabled", "CheckButton", _switch_icon(false, true))
	th.set_icon("checked_disabled", "CheckButton", _switch_icon(true, true))
	th.set_icon("unchecked", "CheckBox", _check_icon(false)); th.set_icon("checked", "CheckBox", _check_icon(true))
	th.set_icon("radio_unchecked", "CheckBox", _radio_icon(false)); th.set_icon("radio_checked", "CheckBox", _radio_icon(true))

	# --- Sliders / progress
	var track := _box(P.BORDER, Color(0, 0, 0, 0), 4, 0); track.content_margin_top = 3; track.content_margin_bottom = 3
	var fill := _box(P.ACCENT, Color(0, 0, 0, 0), 4, 0); fill.content_margin_top = 3; fill.content_margin_bottom = 3
	th.set_stylebox("slider", "HSlider", track)
	th.set_stylebox("grabber_area", "HSlider", fill); th.set_stylebox("grabber_area_highlight", "HSlider", fill)
	var pbg := _box(P.BORDER, Color(0, 0, 0, 0), 4, 0); var pfg := _box(P.ACCENT, Color(0, 0, 0, 0), 4, 0)
	pbg.content_margin_top = 3; pbg.content_margin_bottom = 3
	th.set_stylebox("background", "ProgressBar", pbg); th.set_stylebox("fill", "ProgressBar", pfg)
	th.set_constant("outline_size", "ProgressBar", 0)

	# --- Tree (part list)
	var tree_bg := StyleBoxEmpty.new()
	th.set_stylebox("panel", "Tree", tree_bg); th.set_stylebox("focus", "Tree", StyleBoxEmpty.new())
	th.set_color("font_color", "Tree", P.TEXT); th.set_color("font_selected_color", "Tree", P.ACCENT_HOVER)
	th.set_color("guide_color", "Tree", Color(0, 0, 0, 0)); th.set_color("relationship_line_color", "Tree", Color(0, 0, 0, 0))
	var sel := _box(Color(P.ACCENT, 0.18), Color(P.ACCENT, 0.5), 6, 0)
	th.set_stylebox("selected", "Tree", sel); th.set_stylebox("selected_focus", "Tree", sel)
	th.set_stylebox("cursor", "Tree", StyleBoxEmpty.new()); th.set_stylebox("cursor_unfocused", "Tree", StyleBoxEmpty.new())
	var hov := _box(Color(P.ACCENT, 0.06), Color(0, 0, 0, 0), 6, 0)
	th.set_stylebox("hovered", "Tree", hov)
	th.set_constant("v_separation", "Tree", 6); th.set_constant("item_margin", "Tree", 14)
	th.set_font_size("font_size", "Tree", 14)
	th.set_font("title_button_font", "Tree", semibold)

	# --- Tooltip / popup / scroll
	th.set_stylebox("panel", "TooltipPanel", _box(P.PANEL_RAISED, P.BORDER, 6, 8))
	th.set_color("font_color", "TooltipLabel", P.TEXT)
	th.set_stylebox("panel", "PopupPanel", _box(P.PANEL, P.BORDER, P.RADIUS, P.SP_L))
	th.set_stylebox("panel", "PopupMenu", _box(P.PANEL_RAISED, P.BORDER, 8, 6))
	th.set_stylebox("hover", "PopupMenu", _box(Color(P.ACCENT, 0.15), Color(0, 0, 0, 0), 6, 0))
	th.set_color("font_color", "PopupMenu", P.TEXT); th.set_color("font_hover_color", "PopupMenu", P.ACCENT_HOVER)
	var sb := _box(Color(0, 0, 0, 0.03), Color(0, 0, 0, 0), 4, 0); var gr := _box(P.BORDER.darkened(0.08), Color(0, 0, 0, 0), 4, 0)
	var grh := _box(P.ACCENT_DIM, Color(0, 0, 0, 0), 4, 0)
	for t in ["VScrollBar", "HScrollBar"]:
		th.set_stylebox("scroll", t, sb); th.set_stylebox("grabber", t, gr)
		th.set_stylebox("grabber_highlight", t, grh); th.set_stylebox("grabber_pressed", t, grh)
	th.set_stylebox("panel", "AcceptDialog", _box(P.PANEL, P.BORDER, P.RADIUS, P.SP_L))
	th.set_stylebox("embedded_border", "Window", _box(P.PANEL, P.BORDER, P.RADIUS, P.SP_S))
	th.set_color("title_color", "Window", P.TEXT)
	th.set_constant("separation", "HBoxContainer", P.SP_S)
	th.set_constant("separation", "VBoxContainer", P.SP_S)
	var sep := StyleBoxLine.new(); sep.color = P.BORDER; sep.thickness = 1
	th.set_stylebox("separator", "HSeparator", sep)

	var err := ResourceSaver.save(th, "res://assets/ui/theme.tres")
	print("theme saved: ", error_string(err))
	quit()

func _pad_empty(s: StyleBoxEmpty, h: int, v: int) -> void:
	s.content_margin_left = h; s.content_margin_right = h; s.content_margin_top = v; s.content_margin_bottom = v

func _box(bg: Color, border: Color, radius: int, margin: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg; s.border_color = border
	s.set_border_width_all(1 if border.a > 0.0 else 0)
	s.set_corner_radius_all(radius)
	s.set_content_margin_all(margin)
	s.anti_aliasing = true
	return s

func _pad(s: StyleBoxFlat, h: int, v: int) -> void:
	s.content_margin_left = h; s.content_margin_right = h
	s.content_margin_top = v; s.content_margin_bottom = v

## Anti-aliased signed-distance drawing helpers for the generated icons (2x for crisp scaling).
static func _cov(d: float) -> float:
	return clampf(0.5 - d, 0.0, 1.0)

static func _blend(img: Image, x: int, y: int, c: Color, a: float) -> void:
	if a <= 0.0:
		return
	var o := img.get_pixel(x, y)
	var na := a * c.a + o.a * (1.0 - a * c.a)
	if na <= 0.0:
		return
	var rgb := (Color(c.r, c.g, c.b) * (a * c.a) + Color(o.r, o.g, o.b) * (o.a * (1.0 - a * c.a))) / na
	img.set_pixel(x, y, Color(rgb.r, rgb.g, rgb.b, na))

static func _capsule_d(p: Vector2, a: Vector2, b: Vector2, r: float) -> float:
	var pa := p - a; var ba := b - a
	var h := clampf(pa.dot(ba) / ba.dot(ba), 0.0, 1.0)
	return (pa - ba * h).length() - r

static func _switch_icon(on: bool, disabled: bool) -> ImageTexture:
	var w := 40; var h := 22
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var track := P.ACCENT if on else Color("#B9C7BF")
	var a0 := Vector2(11, 11); var b0 := Vector2(29, 11)
	var knob := b0 if on else a0
	var alpha := 0.45 if disabled else 1.0
	for y in h:
		for x in w:
			var p := Vector2(x + 0.5, y + 0.5)
			_blend(img, x, y, Color(track, alpha), _cov(_capsule_d(p, a0, b0, 10.5)))
			_blend(img, x, y, Color(0.05, 0.2, 0.14, 0.18 * alpha), _cov((p - knob - Vector2(0, 0.8)).length() - 8.4))
			_blend(img, x, y, Color(1, 1, 1, alpha), _cov((p - knob).length() - 8.0))
	return ImageTexture.create_from_image(img)

static func _check_icon(on: bool) -> ImageTexture:
	var s := 18
	var img := Image.create(s, s, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	for y in s:
		for x in s:
			var p := Vector2(x + 0.5, y + 0.5) - Vector2(9, 9)
			var q := Vector2(absf(p.x), absf(p.y)) - Vector2(5.5, 5.5)
			var d := Vector2(maxf(q.x, 0), maxf(q.y, 0)).length() + minf(maxf(q.x, q.y), 0.0) - 2.5
			if on:
				_blend(img, x, y, P.ACCENT, _cov(d))
				var pp := Vector2(x + 0.5, y + 0.5)
				var dc := minf(_capsule_d(pp, Vector2(5, 9.5), Vector2(8, 12.5), 1.1), _capsule_d(pp, Vector2(8, 12.5), Vector2(13.2, 6), 1.1))
				_blend(img, x, y, Color.WHITE, _cov(dc))
			else:
				_blend(img, x, y, Color.WHITE, _cov(d))
				_blend(img, x, y, Color("#8FA39A"), _cov(absf(d + 0.75) - 0.75))
	return ImageTexture.create_from_image(img)

static func _radio_icon(on: bool) -> ImageTexture:
	var s := 18
	var img := Image.create(s, s, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	for y in s:
		for x in s:
			var r := (Vector2(x + 0.5, y + 0.5) - Vector2(9, 9)).length()
			_blend(img, x, y, Color.WHITE, _cov(r - 8.0))
			_blend(img, x, y, P.ACCENT if on else Color("#8FA39A"), _cov(absf(r - 7.25) - 0.75))
			if on:
				_blend(img, x, y, P.ACCENT, _cov(r - 4.0))
	return ImageTexture.create_from_image(img)
