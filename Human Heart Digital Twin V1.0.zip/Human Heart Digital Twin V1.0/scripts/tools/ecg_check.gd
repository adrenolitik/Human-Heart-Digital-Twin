## Developer check: prints per-lead extrema of the simulated 12-lead ECG for each rhythm.
##   godot --headless --path . -s res://scripts/tools/ecg_check.gd
extends SceneTree

func _init() -> void:
	var e := CardiacEngine.new()
	e.extra_paths = PackedStringArray(["res://data/electro/rhythms.json"])
	root.add_child(e)
	await process_frame
	for id in ["r_nsr", "r_pvc", "r_vt", "r_af", "anterior_stemi", "inferior_stemi", "hcm"]:
		e.set_condition(id)
		e.playing = false
		e.sim_time = 0.0
		e.restart()
		e._schedule(12.0)
		var line: String = str(id) + ": "
		for lead in CardiacEngine.LEAD_NAMES:
			var mx := -9.0; var mn := 9.0
			var t := 2.0
			while t < 6.0:
				var v := e.ecg_value(t, lead)
				mx = maxf(mx, v); mn = minf(mn, v)
				t += 0.002
			line += "%s %+.2f/%+.2f  " % [lead, mx, mn]
		print(line)
		var segs := {}
		var t2 := 2.0
		while t2 < 4.0:
			var sname: String = e.get_ecg_segment(t2)
			segs[sname] = segs.get(sname, 0) + 1
			t2 += 0.01
		print("   segments: ", segs, "  intervals: ", e.get_intervals())
	quit()
