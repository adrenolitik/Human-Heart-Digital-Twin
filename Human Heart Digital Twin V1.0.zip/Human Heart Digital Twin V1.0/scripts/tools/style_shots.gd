## Developer QA: renders the heart in every colour style (anterior, posterior and four-chamber cut).
##   godot --path . res://scenes/tools/style_shots.tscn -- --out=<dir>
extends Node3D

func _ready() -> void:
	var out := "user://style_shots"
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--out="): out = a.get_slice("=", 1)
	DirAccess.make_dir_recursive_absolute(out)
	var env := StudioEnvironment.new(); add_child(env)
	var heart := HeartModel.new(); add_child(heart)
	var cam := OrbitCamera.new(); add_child(cam)
	var c := heart.get_model_aabb().get_center()
	for st in ["lifelike", "realistic", "atlas", "specimen"]:
		AppState.set_heart_style(st)
		heart.set_cutaway(false)
		cam.set_view(0.0, -8.0, c, 0.34, false)
		await _shot(out, st + "_anterior")
		cam.set_view(200.0, 10.0, c, 0.34, false)
		await _shot(out, st + "_posterior")
		var apex := heart.get_landmark("apex"); var mi := heart.get_landmark("mitral_center"); var tr := heart.get_landmark("tricuspid_center")
		var n := (mi - apex).cross(tr - apex).normalized()
		if n.z < 0.0: n = -n
		heart.set_cutaway(true, Plane(n, n.dot((apex + mi + tr) / 3.0)))
		cam.look_from_direction(n, c, 0.32, false)
		await _shot(out, st + "_4ch")
	AppState.set_heart_style("lifelike")
	get_tree().quit()

func _shot(out: String, n: String) -> void:
	for i in 14:
		await get_tree().process_frame
	get_viewport().get_texture().get_image().save_png(out.path_join(n + ".png"))
