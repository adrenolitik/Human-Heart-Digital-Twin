## Developer QA: renders the heart from fixed angles (used to check floating parts / open vessels).
##   godot --path . res://scenes/tools/view_shots.tscn -- --out=<dir>
extends Node3D

const VIEWS := [["anterior", 0.0, -8.0], ["anterior_left", 35.0, 5.0], ["left", 80.0, 0.0], ["posterior", 185.0, 5.0], ["right", -80.0, 0.0], ["superior", 20.0, 60.0], ["inferior", 0.0, -60.0]]

func _ready() -> void:
	var out := "user://view_shots"
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--out="): out = a.get_slice("=", 1)
	DirAccess.make_dir_recursive_absolute(out)
	add_child(StudioEnvironment.new())
	var heart := HeartModel.new(); add_child(heart)
	var cam := OrbitCamera.new(); add_child(cam)
	var c := heart.get_model_aabb().get_center()
	for v in VIEWS:
		cam.set_view(v[1], v[2], c, 0.30, false)
		for i in 14: await get_tree().process_frame
		get_viewport().get_texture().get_image().save_png(out.path_join(v[0] + ".png"))
	get_tree().quit()
