## EcgMonitor
## Bedside-monitor style sweeping ECG trace, sampled from CardiacEngine.ecg_value() in simulation
## time (so slow-motion and pause behave like the 3D heart). Clearly labelled as simulated.
class_name EcgMonitor
extends Control

const RATE := 200.0              # samples per simulated second
var engine: CardiacEngine
var lead := "II":
	set(v):
		lead = v
		_clear()
var window_s := 6.0
var trace_color := Color("#3DDC84")
var _buf := PackedFloat32Array()
var _valid := PackedByteArray()
var _cursor := 0
var _t := 0.0

func _ready() -> void:
	custom_minimum_size = Vector2(260, 110)
	_clear()

func _clear() -> void:
	var n := int(window_s * RATE)
	_buf.resize(n); _buf.fill(0.0)
	_valid.resize(n); _valid.fill(0)
	_cursor = 0
	if engine:
		_t = engine.sim_time

func _process(_d: float) -> void:
	if engine == null or not is_visible_in_tree():
		return
	var now := engine.sim_time
	if now < _t - 0.01:
		_clear()
	var n := int((now - _t) * RATE)
	n = mini(n, _buf.size())
	for i in n:
		_t += 1.0 / RATE
		_buf[_cursor] = engine.ecg_value(_t, lead)
		_valid[_cursor] = 1
		_cursor = (_cursor + 1) % _buf.size()
	if now - _t > 1.0:
		_t = now
	queue_redraw()

func _draw() -> void:
	var r := Rect2(Vector2.ZERO, size)
	draw_rect(r, Color("#050C0A"))
	# grid: major lines every 0.2 s and 0.5 mV
	var px_per_s := size.x / window_s
	var px_per_mv := size.y * 0.30
	var base_y := size.y * 0.58
	var gc := Color(0.15, 0.35, 0.25, 0.35)
	var x := 0.0
	while x < size.x:
		draw_line(Vector2(x, 0), Vector2(x, size.y), gc, 1.0)
		x += px_per_s * 0.2
	var y := base_y
	while y > 0:
		draw_line(Vector2(0, y), Vector2(size.x, y), gc, 1.0)
		y -= px_per_mv * 0.5
	y = base_y + px_per_mv * 0.5
	while y < size.y:
		draw_line(Vector2(0, y), Vector2(size.x, y), gc, 1.0)
		y += px_per_mv * 0.5
	var n := _buf.size()
	if n < 2:
		return
	var gap := int(RATE * 0.08)
	# Sweep display: new samples [0, cursor) on the left of the cursor, older ones after the gap.
	_draw_segment(0, _cursor, n, base_y, px_per_mv)
	_draw_segment(mini(_cursor + gap, n), n, n, base_y, px_per_mv)
	var cx := float(_cursor) / n * size.x
	draw_circle(Vector2(cx, base_y - _buf[(_cursor - 1 + n) % n] * px_per_mv), 2.5, Color(0.8, 1, 0.9))
	var f := get_theme_default_font()
	draw_string(f, Vector2(8, 16), lead, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, trace_color)
	draw_string(f, Vector2(size.x - 170, 16), "SIMULATED · not diagnostic", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(0.6, 0.75, 0.68))
	draw_line(Vector2(8, base_y), Vector2(8, base_y - px_per_mv), trace_color, 2.0)
	draw_string(f, Vector2(12, base_y - px_per_mv + 10), "1 mV", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(0.6, 0.75, 0.68))

func _draw_segment(from: int, to: int, n: int, base_y: float, px_per_mv: float) -> void:
	var pts := PackedVector2Array()
	for idx in range(from, to):
		if _valid[idx] == 0:
			if pts.size() > 1:
				draw_polyline(pts, trace_color, 1.6, true)
			pts.clear()
			continue
		pts.append(Vector2(float(idx) / n * size.x, base_y - _buf[idx] * px_per_mv))
	if pts.size() > 1:
		draw_polyline(pts, trace_color, 1.6, true)
