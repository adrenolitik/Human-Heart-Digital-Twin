## Central colour/spacing tokens for the CardioCath 3D interface.
class_name UiPalette
extends RefCounted

## Light clinical theme (Update 7): white surfaces, green as the single accent.
## All text colours meet WCAG AA (≥ 4.5:1) on PANEL and BG.
const BG := Color("#EEF3F0")            # app background: very light green-grey
const BG_ALT := Color("#E4ECE7")
const PANEL := Color("#FFFFFF")         # cards / panels: white
const PANEL_RAISED := Color("#F4F8F5")  # inputs, list rows, raised areas
const BORDER := Color("#D3DED7")
const ACCENT := Color("#0B7A52")        # medical green: interactive / selected only (5.4:1 on white)
const ACCENT_DIM := Color("#0B7A52")    # primary-button fill (white text 5.4:1)
const ACCENT_HOVER := Color("#08643F")
const ACCENT_TINT := Color("#E3F2EA")   # selected backgrounds
const BLUE := Color("#2563EB")
const TEXT := Color("#15241F")          # 16:1 on white
const TEXT_MUTED := Color("#5B6B65")    # 5.6:1 on white
const SUCCESS := Color("#0F7A45")
const WARNING := Color("#A86400")
const DANGER := Color("#C2362F")

const SP_XS := 4
const SP_S := 8
const SP_M := 12
const SP_L := 16
const SP_XL := 24
const RADIUS := 10

## Small rounded "chip" style used for status labels.
static func chip(color: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = Color(color, 0.16)
	s.border_color = Color(color, 0.55)
	s.set_border_width_all(1)
	s.set_corner_radius_all(20)
	s.content_margin_left = 10; s.content_margin_right = 10
	s.content_margin_top = 3; s.content_margin_bottom = 3
	return s

static func card(raised := false) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = PANEL_RAISED if raised else PANEL
	s.border_color = BORDER
	s.set_border_width_all(1)
	s.set_corner_radius_all(RADIUS + 2)
	s.set_content_margin_all(SP_L + 4)
	s.shadow_color = Color(0.06, 0.2, 0.14, 0.10)
	s.shadow_size = 8
	return s
