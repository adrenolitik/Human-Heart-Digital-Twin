## Main dashboard: three stages with status/progress, rotating heart preview,
## graphics quality setting and credits. Built from containers (no fixed pixel layout).
extends Control

const Pal := preload("res://scripts/ui/ui_palette.gd")
const Kit := preload("res://scripts/ui/ui_kit.gd")
const STAGE_ICONS := {"stage1": "heart", "stage2": "activity", "stage3": "stethoscope"}
const HeartModelScript := preload("res://scripts/shared/heart_model.gd")
const StudioEnvScript := preload("res://scripts/shared/studio_environment.gd")

var _hero_pivot: Node3D
var _credits: AcceptDialog

func _ready() -> void:
	theme = load("res://assets/ui/theme.tres")
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_build_background()
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 40 if side in ["left", "right"] else 28)
	add_child(margin)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", Pal.SP_XL)
	margin.add_child(root)
	root.add_child(_build_header())
	var middle := HBoxContainer.new()
	middle.size_flags_vertical = Control.SIZE_EXPAND_FILL
	middle.add_theme_constant_override("separation", Pal.SP_XL)
	root.add_child(middle)
	var intro := _build_intro()
	intro.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	intro.size_flags_stretch_ratio = 1.0
	middle.add_child(intro)
	var hero := _build_hero()
	hero.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hero.size_flags_stretch_ratio = 1.1
	middle.add_child(hero)
	root.add_child(_build_stage_cards())
	root.add_child(_build_footer())
	_build_credits_dialog()
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--qa-shot="):
			_qa_shot(a.get_slice("=", 1))

## Developer QA: save a screenshot of the dashboard and quit.
func _qa_shot(path: String) -> void:
	for i in 40:
		await get_tree().process_frame
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(path)
	get_tree().quit()

func _process(delta: float) -> void:
	if _hero_pivot:
		_hero_pivot.rotate_y(delta * 0.25)

# ------------------------------------------------------------------ sections
func _build_background() -> void:
	var bg := TextureRect.new()
	var gt := GradientTexture2D.new()
	var g := Gradient.new()
	g.set_color(0, Color("#FFFFFF")); g.set_color(1, Pal.BG)
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.72, 0.38); gt.fill_to = Vector2(1.25, 1.1)
	gt.width = 512; gt.height = 512
	bg.texture = gt
	bg.stretch_mode = TextureRect.STRETCH_SCALE
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

func _build_header() -> Control:
	var h := HBoxContainer.new()
	var logo := TextureRect.new()
	logo.texture = Kit.icon("heart-pulse")
	logo.custom_minimum_size = Vector2(40, 40)
	logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	logo.modulate = Pal.ACCENT
	logo.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(logo)
	var titles := VBoxContainer.new()
	titles.add_theme_constant_override("separation", 0)
	var t := Label.new(); t.text = AppState.APP_NAME; t.theme_type_variation = "HeaderLarge"
	var s := Label.new(); s.text = "Interactive Virtual Cardiac Anatomy, Physiology, Electrophysiology & Catheterization Simulator"
	s.theme_type_variation = "MutedLabel"
	titles.add_child(t); titles.add_child(s)
	h.add_child(titles)
	var sp := Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; h.add_child(sp)
	var ver := Label.new(); ver.text = "v" + AppState.APP_VERSION
	ver.add_theme_stylebox_override("normal", Pal.chip(Pal.ACCENT))
	ver.add_theme_color_override("font_color", Pal.ACCENT)
	ver.add_theme_font_size_override("font_size", 13)
	ver.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(ver)
	return h

func _build_intro() -> Control:
	var v := VBoxContainer.new()
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", Pal.SP_M)
	var k := Label.new(); k.text = "LEARNING PATH"; k.theme_type_variation = "HeaderSmall"
	v.add_child(k)
	var h := Label.new(); h.text = "From whole-heart anatomy to the ECG"
	h.theme_type_variation = "HeaderMedium"; h.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	h.add_theme_font_size_override("font_size", 26)
	v.add_child(h)
	var p := RichTextLabel.new()
	p.bbcode_enabled = true; p.fit_content = true; p.scroll_active = false
	p.add_theme_color_override("default_color", Pal.TEXT_MUTED)
	p.add_theme_font_size_override("normal_font_size", 16)
	p.text = "Two stages are available, both built on the same anatomically derived 3D heart model. Stage 3 (catheterization) is coming in a future release.\n\n[b]Stage 1:[/b] beating heart with heart-rate control, dissection (four-chamber, long- and short-axis cuts, scalpel, exploded view), nine simulated diseases, a quiz and animated blood flow through the chambers and valves.\n[b]Stage 2:[/b] the conduction system on the same heart, animated impulse and depolarisation wavefront, annotated ECG waves, an educational 12-lead viewer and six simulated rhythms.\n[b]New look:[/b] three heart colour styles matched to atlas, 3D and specimen references (Realistic, Atlas, Specimen) — choose below or in any lab.\n\n[color=#5B6B65]3D heart derived from [b]BodyParts3D[/b] (CC BY-SA 2.1 JP). Drag to rotate the preview.[/color]"
	v.add_child(p)
	var warn := Label.new()
	warn.text = "Educational simulator only — not a clinical device, diagnostic tool or substitute for supervised clinical training."
	warn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	warn.add_theme_color_override("font_color", Pal.WARNING)
	warn.add_theme_font_size_override("font_size", 13)
	v.add_child(warn)
	return v

func _build_hero() -> Control:
	var c := SubViewportContainer.new()
	c.stretch = true
	c.custom_minimum_size = Vector2(380, 300)
	c.mouse_filter = Control.MOUSE_FILTER_STOP
	var vp := SubViewport.new()
	vp.own_world_3d = true
	vp.transparent_bg = true
	vp.msaa_3d = Viewport.MSAA_2X
	c.add_child(vp)
	var env := StudioEnvScript.new()
	env.transparent_background = true
	vp.add_child(env)
	_hero_pivot = Node3D.new()
	vp.add_child(_hero_pivot)
	var heart := HeartModelScript.new()
	heart.build_colliders = false
	_hero_pivot.add_child(heart)
	var cam := Camera3D.new()
	cam.fov = 30
	cam.position = Vector3(0, 0.012, 0.36)
	vp.add_child(cam)
	cam.current = true
	c.gui_input.connect(func(e: InputEvent):
		if e is InputEventMouseMotion and (e.button_mask & MOUSE_BUTTON_MASK_LEFT):
			_hero_pivot.rotate_y(e.relative.x * 0.01))
	return c

func _build_stage_cards() -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", Pal.SP_L)
	for s in AppState.stages:
		var card := PanelContainer.new()
		card.add_theme_stylebox_override("panel", Pal.card(s["status"] != "locked"))
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", Pal.SP_S)
		card.add_child(v)
		var top := HBoxContainer.new()
		var ic := TextureRect.new(); ic.texture = Kit.icon(STAGE_ICONS.get(s["id"], "circle-dot"))
		ic.custom_minimum_size = Vector2(18, 18); ic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED; ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		ic.modulate = Pal.ACCENT if s["status"] != "locked" else Pal.TEXT_MUTED
		top.add_child(ic)
		var num := Label.new(); num.text = "STAGE %d" % s["number"]; num.theme_type_variation = "HeaderSmall"
		top.add_child(num)
		var sp := Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; top.add_child(sp)
		top.add_child(_status_chip(s["status"]))
		v.add_child(top)
		var t := Label.new(); t.text = s["title"]; t.theme_type_variation = "HeaderMedium"
		t.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		v.add_child(t)
		var d := Label.new(); d.text = s["summary"]; d.theme_type_variation = "MutedLabel"
		d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		d.custom_minimum_size.y = 64
		v.add_child(d)
		var prow := HBoxContainer.new()
		var pb := ProgressBar.new(); pb.min_value = 0; pb.max_value = 1; pb.value = s["progress"]
		pb.show_percentage = false; pb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		pb.size_flags_vertical = Control.SIZE_SHRINK_CENTER; pb.custom_minimum_size.y = 6
		prow.add_child(pb)
		var pl := Label.new(); pl.text = "%d%%" % int(round(s["progress"] * 100)); pl.theme_type_variation = "MutedLabel"
		prow.add_child(pl)
		v.add_child(prow)
		var note := Label.new(); note.text = s["milestone_note"]; note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		note.add_theme_font_size_override("font_size", 13); note.add_theme_color_override("font_color", Pal.TEXT_MUTED)
		v.add_child(note)
		var brow := HBoxContainer.new()
		brow.alignment = BoxContainer.ALIGNMENT_END
		if s.has("extra_scene") and s["status"] != "locked":
			var epath: String = s["extra_scene"]
			brow.add_child(Kit.button(s.get("extra_label", "More"), s.get("extra_icon", "microscope"), func(): SceneRouter.goto(epath), "", "GhostButton"))
		var btn: Button
		if s["status"] == "coming_soon":
			btn = Kit.button("Coming soon", "timer", Callable(), "This stage is in development and will be added in a future release.")
			btn.disabled = true
		elif s["status"] == "locked":
			btn = Kit.button("Locked", "eye-off", Callable(), "Stages unlock in order after the previous stage is approved.")
			btn.disabled = true
		else:
			var path: String = s["scene"]
			btn = Kit.button(s.get("open_label", "Open"), "chevron-right", func(): SceneRouter.goto(path), "", "PrimaryButton")
			btn.icon_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		brow.add_child(btn)
		v.add_child(brow)
		row.add_child(card)
	return row

func _status_chip(status: String) -> Label:
	var l := Label.new()
	var col := Pal.TEXT_MUTED
	match status:
		"available": l.text = "Available"; col = Pal.SUCCESS
		"in_development": l.text = "In development"; col = Pal.ACCENT
		"coming_soon": l.text = "Coming soon"; col = Pal.WARNING
		_: l.text = "Locked"; col = Pal.TEXT_MUTED
	l.add_theme_stylebox_override("normal", Pal.chip(col))
	l.add_theme_color_override("font_color", col)
	l.add_theme_font_size_override("font_size", 12)
	return l

func _build_footer() -> Control:
	var h := HBoxContainer.new()
	var q := Label.new(); q.text = "Graphics quality"; q.theme_type_variation = "MutedLabel"
	h.add_child(q)
	var ob := OptionButton.new()
	ob.custom_minimum_size.y = 40
	for i in AppState.QUALITY_NAMES.size():
		ob.add_item(AppState.QUALITY_NAMES[i], i)
	ob.select(AppState.quality)
	ob.item_selected.connect(func(i: int): AppState.set_quality(i))
	h.add_child(ob)
	var hc := Label.new(); hc.text = "Heart colours"; hc.theme_type_variation = "MutedLabel"
	h.add_child(hc)
	var so := OptionButton.new()
	so.custom_minimum_size.y = 40
	so.tooltip_text = "Colour style of the 3D heart in every lab (saved)"
	var sids := []
	for st in AppState.get_heart_styles():
		so.add_icon_item(Kit.icon(st.get("icon", "heart")), "%s — %s" % [st["name"], st.get("tagline", "")])
		sids.append(st["id"])
	so.select(maxi(sids.find(AppState.heart_style), 0))
	so.item_selected.connect(func(i: int): AppState.set_heart_style(sids[i]))
	h.add_child(so)
	var sp := Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; h.add_child(sp)
	h.add_child(Kit.button("Credits & licenses", "book-open", func(): _credits.popup_centered(Vector2i(720, 460)), "", "FlatButton"))
	h.add_child(Kit.button("Quit", "x", func(): get_tree().quit(), "", "FlatButton"))
	return h

func _build_credits_dialog() -> void:
	_credits = AcceptDialog.new()
	_credits.title = "Credits & licenses"
	var txt := RichTextLabel.new()
	txt.bbcode_enabled = true
	txt.custom_minimum_size = Vector2(660, 360)
	var path := "res://data/credits.json"
	var body := ""
	if FileAccess.file_exists(path):
		var d = JSON.parse_string(FileAccess.get_file_as_string(path))
		if d is Dictionary:
			for e in d.get("entries", []):
				body += "[b]%s[/b]\n%s\n[color=#5B6B65]%s[/color]\n\n" % [e.get("title", ""), e.get("text", ""), e.get("license", "")]
	txt.text = body if body != "" else "Credits file missing."
	_credits.add_child(txt)
	add_child(_credits)
