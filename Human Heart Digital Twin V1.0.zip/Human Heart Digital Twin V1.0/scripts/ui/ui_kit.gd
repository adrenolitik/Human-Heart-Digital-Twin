## UiKit
## Small component kit shared by every CardioCath 3D screen so all stages look and behave the same:
## SVG icon buttons (Lucide, ISC licence) instead of text glyphs, ≥ 40 px hit targets, segmented
## tabs, status badges, labelled sliders and toggles. Colours always come from UiPalette tokens.
class_name UiKit
extends RefCounted

const Pal := preload("res://scripts/ui/ui_palette.gd")
const ICON_DIR := "res://assets/ui/icons/"
const TARGET := 40.0          # minimum control height (px)

static var _icons := {}

static func icon(icon_name: String) -> Texture2D:
	if _icons.has(icon_name):
		return _icons[icon_name]
	var path := ICON_DIR + icon_name + ".svg"
	var tex: Texture2D = load(path) if ResourceLoader.exists(path) else null
	if tex == null:
		push_warning("UiKit: missing icon %s" % path)
	_icons[icon_name] = tex
	return tex

## Text button with an optional leading icon. variant: "" | "PrimaryButton" | "FlatButton" | "SegmentButton" | "GhostButton"
static func button(text: String, icon_name := "", cb := Callable(), tip := "", variant := "") -> Button:
	var b := Button.new()
	b.text = text
	if icon_name != "":
		b.icon = icon(icon_name)
	b.tooltip_text = tip
	b.custom_minimum_size.y = TARGET
	if variant != "":
		b.theme_type_variation = variant
	if cb.is_valid():
		b.pressed.connect(cb)
	b.focus_mode = Control.FOCUS_ALL
	return b

## Square icon-only button; `tip` doubles as the accessible name (tooltip).
static func icon_button(icon_name: String, tip: String, cb := Callable(), variant := "") -> Button:
	var b := button("", icon_name, cb, tip, variant)
	b.custom_minimum_size = Vector2(TARGET, TARGET)
	b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return b

## Segmented control (exclusive toggle buttons). options: Array of [id, label, icon].
## Returns {"root": HBoxContainer, "buttons": {id: Button}}.
static func segmented(options: Array, cb: Callable, expand := false) -> Dictionary:
	var wrap := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(Pal.PANEL, 0.9)
	sb.border_color = Pal.BORDER
	sb.set_border_width_all(1)
	sb.set_corner_radius_all(10)
	sb.set_content_margin_all(3)
	wrap.add_theme_stylebox_override("panel", sb)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 2)
	wrap.add_child(h)
	var group := ButtonGroup.new()
	var buttons := {}
	for o in options:
		var b := button(str(o[1]), str(o[2]) if o.size() > 2 else "", Callable(), str(o[3]) if o.size() > 3 else "", "SegmentButton")
		b.toggle_mode = true
		b.button_group = group
		b.custom_minimum_size.y = TARGET - 4
		if expand:
			b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var id: String = str(o[0])
		b.pressed.connect(func(): cb.call(id))
		h.add_child(b)
		buttons[id] = b
	return {"root": wrap, "buttons": buttons}

## Pill-shaped status badge, optionally with an icon.
static func badge(text: String, color: Color, icon_name := "") -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", Pal.chip(color))
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 6)
	p.add_child(h)
	if icon_name != "":
		var tr := TextureRect.new()
		tr.texture = icon(icon_name)
		tr.custom_minimum_size = Vector2(14, 14)
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		tr.modulate = color.darkened(0.05)
		tr.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		h.add_child(tr)
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", 12)
	l.add_theme_color_override("font_color", color.darkened(0.12))
	h.add_child(l)
	p.set_meta("label", l)
	return p

## The mandatory "simulated" notice used on every Stage 2 / 3 screen.
static func sim_badge(text := "SIMULATED · EDUCATIONAL · NOT DIAGNOSTIC") -> PanelContainer:
	return badge(text, Pal.WARNING, "triangle-alert")

static func section(text: String, icon_name := "") -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 6)
	if icon_name != "":
		var tr := TextureRect.new()
		tr.texture = icon(icon_name)
		tr.custom_minimum_size = Vector2(16, 16)
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		tr.modulate = Pal.TEXT_MUTED
		tr.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		h.add_child(tr)
	var l := Label.new()
	l.text = text
	l.theme_type_variation = "HeaderSmall"
	h.add_child(l)
	return h

static func muted(text: String, size := 13) -> Label:
	var l := Label.new()
	l.text = text
	l.theme_type_variation = "MutedLabel"
	l.add_theme_font_size_override("font_size", maxi(size, 12))
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

## Toggle switch row with optional icon.
static func toggle(text: String, on: bool, cb: Callable, icon_name := "", tip := "") -> CheckButton:
	var c := CheckButton.new()
	c.text = text
	c.button_pressed = on
	c.tooltip_text = tip
	c.custom_minimum_size.y = 36
	if icon_name != "":
		c.icon = icon(icon_name)
	c.toggled.connect(cb)
	return c

## Labelled slider: header row (label + live value) above the slider.
## Returns {"root": VBoxContainer, "slider": HSlider, "value": Label}
static func slider_row(text: String, min_v: float, max_v: float, step: float, value: float, fmt: Callable, cb: Callable) -> Dictionary:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 2)
	var h := HBoxContainer.new()
	var l := Label.new(); l.text = text
	l.add_theme_font_size_override("font_size", 14)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var val := Label.new()
	val.add_theme_font_size_override("font_size", 14)
	val.add_theme_color_override("font_color", Pal.ACCENT)
	h.add_child(l); h.add_child(val)
	var s := HSlider.new()
	s.min_value = min_v; s.max_value = max_v; s.step = step; s.value = value
	s.custom_minimum_size.y = 28
	s.focus_mode = Control.FOCUS_ALL
	val.text = fmt.call(value)
	s.value_changed.connect(func(x: float):
		val.text = fmt.call(x)
		cb.call(x))
	v.add_child(h); v.add_child(s)
	return {"root": v, "slider": s, "value": val}

## Rounded card panel.
static func card(raised := false, alpha := 0.94, pad := Pal.SP_M) -> PanelContainer:
	var p := PanelContainer.new()
	var sb := Pal.card(raised)
	sb.bg_color = Color(sb.bg_color, alpha)
	sb.set_content_margin_all(pad)
	sb.shadow_size = 6
	p.add_theme_stylebox_override("panel", sb)
	return p

## Vertical spacer / expanding filler.
static func spacer(expand_h := true) -> Control:
	var c := Control.new()
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if expand_h:
		c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	else:
		c.size_flags_vertical = Control.SIZE_EXPAND_FILL
	return c

## Small colour swatch used in legends (shape + text, never colour alone).
static func legend_item(color: Color, text: String) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 6)
	var sw := ColorRect.new()
	sw.color = color
	sw.custom_minimum_size = Vector2(12, 12)
	sw.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(sw)
	var l := Label.new(); l.text = text
	l.add_theme_font_size_override("font_size", 13)
	h.add_child(l)
	return h

## "Appearance" menu shared by the labs: heart colour style + viewport backdrop (saved in settings).
static func appearance_menu(show_text := false) -> MenuButton:
	var mb := MenuButton.new()
	mb.text = "Appearance" if show_text else ""
	mb.icon = icon("sliders-horizontal")
	mb.flat = false
	mb.custom_minimum_size = Vector2(TARGET, TARGET)
	mb.tooltip_text = "Appearance: heart colours and background"
	var pm := mb.get_popup()
	var app = Engine.get_main_loop().root.get_node_or_null("/root/AppState")
	if app == null:
		return mb
	pm.add_separator("Heart colours")
	var ids := []
	for st in app.get_heart_styles():
		pm.add_radio_check_item("%s — %s" % [st["name"], st.get("tagline", "")])
		pm.set_item_tooltip(pm.item_count - 1, st.get("description", ""))
		ids.append(["style", st["id"], pm.item_count - 1])
	pm.add_separator("Background")
	for b in app.BACKDROPS:
		pm.add_radio_check_item(b[1])
		ids.append(["backdrop", b[0], pm.item_count - 1])
	var sync := func():
		for e in ids:
			pm.set_item_checked(e[2], (app.heart_style if e[0] == "style" else app.backdrop) == e[1])
	sync.call()
	pm.index_pressed.connect(func(i: int):
		for e in ids:
			if e[2] == i:
				if e[0] == "style": app.set_heart_style(e[1])
				else: app.set_backdrop(e[1])
		sync.call())
	return mb

const LEGEND_KEYS := [["myocardium", "albedo", "Myocardium"], ["myocardium", "fat_color", "Epicardial fat"],
	["coronary_artery", "albedo", "Coronary arteries"], ["cardiac_vein", "albedo", "Cardiac veins"],
	["vessel_artery", "albedo", "Aorta"], ["vessel_pulmonary_artery", "albedo", "Pulmonary trunk"],
	["vessel_vein", "albedo", "Venae cavae"], ["valve", "albedo", "Valves"]]

## Colour key for the active heart style (rebuilds itself when the style changes).
static func style_legend() -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	var app = Engine.get_main_loop().root.get_node_or_null("/root/AppState")
	var fill := func():
		if not is_instance_valid(v):
			return
		for c in v.get_children():
			c.queue_free()
		if app == null:
			return
		var st: Dictionary = app.get_heart_style()
		var head := HBoxContainer.new()
		head.add_child(section("COLOUR KEY", st.get("icon", "heart")))
		var nm := Label.new(); nm.text = "· " + str(st.get("name", "")); nm.theme_type_variation = "MutedLabel"
		nm.add_theme_font_size_override("font_size", 12)
		head.add_child(nm)
		v.add_child(head)
		var grid := GridContainer.new(); grid.columns = 2
		grid.add_theme_constant_override("h_separation", 12); grid.add_theme_constant_override("v_separation", 4)
		var mats: Dictionary = st.get("materials", {})
		for k in LEGEND_KEYS:
			var a = (mats.get(k[0], {}) as Dictionary).get(k[1], null)
			if a is Array:
				grid.add_child(legend_item(Color(a[0], a[1], a[2]), k[2]))
		v.add_child(grid)
	fill.call()
	if app:
		var cb := func(_id): fill.call()
		app.heart_style_changed.connect(cb)
		v.tree_exiting.connect(func():
			if app.heart_style_changed.is_connected(cb):
				app.heart_style_changed.disconnect(cb))
	return v

## Short-lived notification pill (top centre of `host`), e.g. "Previous changes were reset".
static func toast(host: Control, text: String, icon_name := "rotate-ccw", seconds := 2.4) -> void:
	if host == null or not host.is_inside_tree():
		return
	var old := host.get_node_or_null("Toast")
	if old:
		old.queue_free()
	var p := badge(text, Pal.ACCENT, icon_name)
	p.name = "Toast"
	var sb := Pal.chip(Pal.ACCENT)
	sb.bg_color = Color(Pal.PANEL_RAISED, 0.96)
	sb.set_content_margin_all(10)
	sb.shadow_size = 8
	sb.shadow_color = Color(0.06, 0.2, 0.14, 0.12)
	p.add_theme_stylebox_override("panel", sb)
	(p.get_meta("label") as Label).add_theme_font_size_override("font_size", 14)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.set_anchors_preset(Control.PRESET_CENTER_TOP)
	p.position = Vector2(host.size.x * 0.5 - 160, 92)
	p.modulate.a = 0.0
	host.add_child(p)
	p.reset_size()
	p.position.x = (host.size.x - p.size.x) * 0.5
	var tw := p.create_tween()
	tw.tween_property(p, "modulate:a", 1.0, 0.16)
	tw.tween_interval(seconds)
	tw.tween_property(p, "modulate:a", 0.0, 0.25)
	tw.tween_callback(p.queue_free)
