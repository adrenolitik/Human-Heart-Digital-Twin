## PartLabels
## Screen-space anatomical labels with leader lines for visible heart structures.
## Labels hide when the anchor point is occluded by another structure (physics ray test),
## so they stay readable in cut, exploded and isolated views.
class_name PartLabels
extends Control

const Pal := preload("res://scripts/ui/ui_palette.gd")
var heart: HeartModel
var picker: PartPicker
var priority := PackedStringArray()
var safe_rect := Rect2()     # screen area labels may use (between UI panels)
var _labels := {}        # id -> Label
var _occluded := {}      # id -> bool
var _anchors := {}       # id -> Vector2 (screen)
var _timer := 0.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)

func _make_label(id: String) -> Label:
	var l := Label.new()
	l.text = heart.get_part_info(id).get("name", id)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(Pal.PANEL, 0.82); sb.border_color = Color(Pal.ACCENT, 0.45)
	sb.set_border_width_all(1); sb.set_corner_radius_all(5)
	sb.content_margin_left = 6; sb.content_margin_right = 6; sb.content_margin_top = 2; sb.content_margin_bottom = 2
	l.add_theme_stylebox_override("normal", sb)
	l.add_theme_font_size_override("font_size", 12)
	l.add_theme_color_override("font_color", Pal.TEXT)
	add_child(l)
	return l

func _is_candidate(id: String) -> bool:
	if not heart.is_part_visible(id):
		return false
	var iso := heart.get_isolated()
	return iso.is_empty() or iso.has(id)

func _process(delta: float) -> void:
	if heart == null or not visible:
		return
	var cam := get_viewport().get_camera_3d()
	if cam == null:
		return
	_timer -= delta
	var do_occ := _timer <= 0.0
	if do_occ:
		_timer = 0.15
	var centre := cam.unproject_position(heart.get_landmark_world("heart_center"))
	var placed: Array[Rect2] = []
	_anchors.clear()
	for id in priority:
		if not heart.has_part(id):
			continue
		var l: Label = _labels.get(id)
		var cand := _is_candidate(id)
		var wp := heart.get_label_anchor_world(id)
		if cand and cam.is_position_behind(wp):
			cand = false
		if cand and do_occ:
			_occluded[id] = picker != null and picker.is_occluded(id, wp)
		if cand and _occluded.get(id, false):
			cand = false
		if cand and heart.is_point_clipped(wp):
			cand = false
		if not cand:
			if l: l.visible = false
			continue
		if l == null:
			l = _make_label(id)
			_labels[id] = l
		var sp := cam.unproject_position(wp)
		var dir := (sp - centre).normalized()
		if dir == Vector2.ZERO:
			dir = Vector2.RIGHT
		var sz := l.get_combined_minimum_size()
		var pos := sp + dir * 46.0 - Vector2(sz.x * (0.5 - 0.5 * signf(dir.x)) , sz.y * 0.5)
		var area := safe_rect if safe_rect.size.x > 50.0 else get_viewport_rect()
		pos.x = clampf(pos.x, area.position.x + 4, area.end.x - sz.x - 4)
		pos.y = clampf(pos.y, area.position.y + 4, area.end.y - sz.y - 4)
		var rect := Rect2(pos, sz)
		for k in 8:
			var hit := false
			for o in placed:
				if o.grow(2).intersects(rect):
					hit = true
					break
			if not hit:
				break
			rect.position.y += sz.y + 3
		placed.append(rect)
		l.position = rect.position
		l.size = sz
		l.visible = true
		_anchors[id] = sp
	queue_redraw()

func _draw() -> void:
	for id in _anchors:
		var l: Label = _labels[id]
		var sp: Vector2 = _anchors[id]
		var r := Rect2(l.position, l.size)
		var tgt := Vector2(clampf(sp.x, r.position.x, r.end.x), clampf(sp.y, r.position.y, r.end.y))
		draw_line(sp, tgt, Color(Pal.ACCENT, 0.7), 1.2, true)
		draw_circle(sp, 2.6, Pal.ACCENT)

func clear_all() -> void:
	for l in _labels.values():
		(l as Label).visible = false
	_anchors.clear()
	queue_redraw()
