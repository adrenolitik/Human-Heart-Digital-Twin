## Heart Lab (Stage 1)
## Interactive 3D heart for medical students. Modes:
##   Explore     - structure tree, selection, info (location / structure / function / relations / clinical)
##   Dissect     - anatomical cut planes (four-chamber, long axis, short axis, valve plane...), free and
##                 view-aligned cuts, scalpel removal with undo, exploded view
##   Physiology  - beating heart with heart-rate control, speed, cycle phases, valve states, ECG + vitals
##   Diseases    - 9 conditions with 3D effects, simulated ECG and illustrative haemodynamics
##   Quiz        - identify structures by clicking them
## Developer QA: run with `-- --qa-shots=<dir>` to render reference screenshots and quit.
extends Node3D

const Pal := preload("res://scripts/ui/ui_palette.gd")
const Kit := preload("res://scripts/ui/ui_kit.gd")
const MODE_ICONS := {"explore": "scan-eye", "dissect": "scissors", "physiology": "heart-pulse", "diseases": "stethoscope", "quiz": "graduation-cap"}
const MODES := ["explore", "dissect", "physiology", "diseases", "quiz"]
const MODE_NAMES := {"explore": "Explore", "dissect": "Dissect", "physiology": "Physiology", "diseases": "Diseases", "quiz": "Quiz"}
const RECOMMENDED_VIEW := {
	"hcm": "four_chamber", "dcm": "four_chamber", "aortic_stenosis": "valve_plane",
	"anterior_stemi": "short_axis", "inferior_stemi": "inferior", "af": "posterior",
	"chb": "anterior", "vf": "anterior", "normal": "anterior",
}

var heart: HeartModel
var cam: OrbitCamera
var picker: PartPicker
var engine: CardiacEngine
var env: StudioEnvironment
var mode := "explore"
var phases := {}

# UI references
var _ui: Control
var _mode_buttons := {}
var _left_pages := {}
var _info_header: Label
var _info_title: Label
var _info_chip: Label
var _info_body: RichTextLabel
var _info_actions: HBoxContainer
var _info_back: Button
var _monitor: PanelContainer
var _ecg: EcgMonitor
var _vitals := {}
var _phase_label: Label
var _monitor_phase: Label
var _labels: PartLabels
var _labels_toggle: CheckButton
var _hover_label: Label
var _fps_label: Label
var _hint_label: Label
# explore
var _tree: Tree
var _tree_items := {}
var _syncing := false
# physiology
var _play_btn: Button
var _hr_slider: HSlider
var _speed_option: OptionButton
var _info_more: Button
var _details_open := false
var _info_kind := "part"
var _info_id := ""
var _hr_value: Label
var _phase_title: Label
var _phase_text: Label
var _valve_av: Label
var _valve_sl: Label
var _cycle_bar: ProgressBar
var _beat_toggle: CheckButton
# diseases
var _cond_buttons := {}
var _sev_slider: HSlider
var _sev_label: Label
var _dis_hr_slider: HSlider
var _dis_hr_value: Label
var _showing_condition := true
# dissect
var _cut_name := ""
var _cut_n := Vector3.FORWARD
var _cut_point := Vector3.ZERO
var _cut_depth: HSlider
var _cut_tilt_a: HSlider
var _cut_tilt_b: HSlider
var _cut_flip: CheckBox
var _cut_status: Label
var _scalpel: CheckButton
var _removed_label: Label
var _explode: HSlider
# quiz
var _quiz_q: Label
var _quiz_feedback: Label
var _quiz_score: Label
var _quiz_target := ""
var _quiz_n := 0
var _quiz_correct := 0
var _quiz_active := false
var _vitals_timer := 0.0
var _left_panel: Control
var _right_panel: Control
var blood: BloodFlow
var _blood_toggle: CheckButton
var _see_toggle: CheckButton
const SEE_THROUGH_KEEP := ["tricuspid_valve", "mitral_valve", "pulmonary_valve", "aortic_valve", "papillary_muscles_rv", "papillary_muscles_lv"]

func _ready() -> void:
	env = StudioEnvironment.new()
	add_child(env)
	heart = HeartModel.new()
	heart.name = "Heart"
	add_child(heart)
	cam = OrbitCamera.new()
	add_child(cam)
	picker = PartPicker.new()
	add_child(picker)
	picker.heart = heart
	engine = CardiacEngine.new()
	engine.heart = heart
	add_child(engine)
	var box := heart.get_model_aabb()
	cam.set_home(0.0, -8.0, box.get_center(), 0.46)
	cam.reset_view(false)
	cam.clicked.connect(_on_clicked)
	cam.hovered.connect(_on_hover)
	AppState.quality_changed.connect(func(_q): heart.set_texture_detail(AppState.texture_detail()))
	heart.set_texture_detail(AppState.texture_detail())
	var pd = JSON.parse_string(FileAccess.get_file_as_string("res://data/physiology/phases.json")) if FileAccess.file_exists("res://data/physiology/phases.json") else {}
	phases = (pd as Dictionary).get("phases", {}) if pd is Dictionary else {}
	blood = BloodFlow.new()
	blood.name = "BloodFlow"
	blood.engine = engine
	blood.visible = false
	heart.add_child(blood)
	engine.condition_changed.connect(_on_condition_changed)
	engine.rate_changed.connect(_on_rate_changed)
	heart.removed_changed.connect(func(c): if _removed_label: _removed_label.text = "%d structure(s) removed" % c)
	_build_ui()
	_on_rate_changed(engine.hr)
	_set_mode("explore")
	_show_part_info("")
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--qa-shots="):
			_run_qa_shots(a.get_slice("=", 1))

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match (event as InputEventKey).keycode:
			KEY_SPACE: _toggle_play()
			KEY_ESCAPE: _select("")
			KEY_F: _toggle_focus()
			KEY_Z:
				if (event as InputEventKey).ctrl_pressed: heart.undo_remove()

func _process(delta: float) -> void:
	_fps_label.text = "%d FPS" % Engine.get_frames_per_second()
	var free := _free_rect()
	cam.frame_rect = free
	if _labels.visible:
		_labels.safe_rect = free
	_vitals_timer -= delta
	if _vitals_timer <= 0.0:
		_vitals_timer = 0.12
		_update_live_panels()

# ================================================================== interaction
func _on_clicked(pos: Vector2) -> void:
	var hit := picker.pick(pos)
	var id: String = hit.get("id", "")
	if mode == "dissect" and _scalpel and _scalpel.button_pressed and id != "":
		heart.remove_part(id)
		_hint("Removed: %s  ·  Undo with the button or Ctrl+Z" % heart.get_part_info(id).get("name", id))
		return
	if mode == "quiz" and _quiz_active:
		_quiz_answer(id)
		return
	_select(id)

func _on_hover(pos: Vector2) -> void:
	var hit := picker.pick(pos)
	var id: String = hit.get("id", "")
	if mode == "quiz" and _quiz_active:
		id = ""   # no name tooltips during the quiz
	heart.set_hovered(id)
	if id == "":
		_hover_label.visible = false
	else:
		var prefix := "Remove: " if (mode == "dissect" and _scalpel and _scalpel.button_pressed) else ""
		_hover_label.text = prefix + heart.get_part_info(id).get("name", id)
		_hover_label.visible = true
		_hover_label.reset_size()
		_hover_label.position = pos + Vector2(16, 14)
	Input.set_default_cursor_shape(Input.CURSOR_POINTING_HAND if id != "" else Input.CURSOR_ARROW)

func _clear_hover() -> void:
	heart.set_hovered("")
	_hover_label.visible = false
	Input.set_default_cursor_shape(Input.CURSOR_ARROW)

func _select(id: String) -> void:
	heart.set_selected(id)
	if id != "":
		_show_part_info(id)
		if _tree_items.has(id):
			_syncing = true
			(_tree_items[id] as TreeItem).select(0)
			_tree.scroll_to_item(_tree_items[id])
			_syncing = false
	else:
		if _tree: _tree.deselect_all()
		if mode == "diseases":
			_show_condition_info()
		else:
			_show_part_info("")

func _focus_part(id: String) -> void:
	var box := heart.get_part_aabb(id)
	cam.focus_on(box.get_center(), clampf(box.size.length() * 2.6, 0.14, 0.6))

func _hint(t: String) -> void:
	_hint_label.text = t

## Screen area left free by the panels (the heart is centred in it; labels stay inside it).
func _free_rect() -> Rect2:
	var lr := _left_panel.get_global_rect(); var rr_ := _right_panel.get_global_rect()
	var vp := get_viewport().get_visible_rect().size
	var x0 := lr.end.x + 4 if _left_panel.visible else 12.0
	var x1 := rr_.position.x - 4 if _right_panel.visible else vp.x - 12.0
	var bot := _monitor.get_global_rect().position.y if _monitor.visible else rr_.end.y
	return Rect2(Vector2(x0, lr.position.y), Vector2(x1 - x0, bot - lr.position.y - 4))

## Focus mode: fade the side panels out so the heart fills the screen.
func _toggle_focus() -> void:
	var show := not _left_panel.visible
	for p in [_left_panel, _right_panel]:
		var c: Control = p
		if show:
			c.visible = true
			c.modulate.a = 0.0
			c.create_tween().tween_property(c, "modulate:a", 1.0, 0.18)
		else:
			var tw := c.create_tween()
			tw.tween_property(c, "modulate:a", 0.0, 0.14)
			tw.tween_callback(func(): c.visible = false)
	_hint("Focus mode — press F or the focus button to bring the panels back" if not show else "")

func _toggle_play() -> void:
	engine.playing = not engine.playing
	if _play_btn:
		_play_btn.text = "Pause" if engine.playing else "Play"
		_play_btn.icon = Kit.icon("pause" if engine.playing else "play")

# ================================================================== modes
func _set_mode(m: String) -> void:
	# Each tab starts from the normal heart: changes made in the previous tab (removed parts, cuts,
	# explode, isolation, disease, heart rate, speed) are undone when the student switches tab.
	if m != mode and _mode_buttons.size() > 0:
		_reset_session(false)
		Kit.toast(_ui, "Normal heart restored for this tab")
	mode = m
	for k in _mode_buttons:
		(_mode_buttons[k] as Button).set_pressed_no_signal(k == m)
	for k in _left_pages:
		(_left_pages[k] as Control).visible = k == m
	_monitor.visible = m in ["physiology", "diseases"]
	_set_blood(m == "physiology", m == "physiology")
	if m != "quiz":
		_quiz_active = false
	if m == "diseases":
		_select("")
		_show_condition_info()
	elif heart.get_selected() == "":
		_show_part_info("")
	var hints := {
		"explore": "Click a structure to learn about it · tick boxes to show/hide · Labels shows names in 3D",
		"dissect": "Choose a cut, then rotate the heart · Scalpel removes what you click · Explode separates the parts",
		"physiology": "Watch the cardiac cycle · change the heart rate · slow down to follow each phase (Space = play/pause)",
		"diseases": "Choose a condition and compare it with the normal heart · use the recommended view",
		"quiz": "Click the structure named in the question",
	}
	_hint(hints.get(m, ""))

# ================================================================== UI construction
func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	_ui = Control.new()
	_ui.theme = load("res://assets/ui/theme.tres")
	_ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	_ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(_ui)
	_labels = PartLabels.new()
	_labels.heart = heart
	_labels.picker = picker
	var pdata = JSON.parse_string(FileAccess.get_file_as_string(heart.parts_data_path))
	_labels.priority = PackedStringArray((pdata as Dictionary).get("label_priority", [])) if pdata is Dictionary else heart.get_part_ids()
	_labels.visible = false

	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, Pal.SP_M)
	_ui.add_child(margin)
	var col := VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_theme_constant_override("separation", Pal.SP_S)
	margin.add_child(col)
	col.add_child(_build_top_bar())
	var row := HBoxContainer.new()
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", Pal.SP_S)
	col.add_child(row)
	_left_panel = _build_left_panel()
	row.add_child(_left_panel)
	var centre := VBoxContainer.new()
	centre.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	centre.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sp := Control.new(); sp.size_flags_vertical = Control.SIZE_EXPAND_FILL; sp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	centre.add_child(sp)
	centre.add_child(_build_monitor())
	row.add_child(centre)
	_right_panel = _build_info_panel()
	row.add_child(_right_panel)
	col.add_child(_build_bottom_bar())
	_ui.add_child(_labels)   # above the panels, but confined to the free 3D area (safe_rect)
	_hover_label = Label.new()
	_hover_label.add_theme_stylebox_override("normal", Pal.chip(Pal.TEXT))
	_hover_label.add_theme_font_size_override("font_size", 13)
	_hover_label.visible = false
	_hover_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui.add_child(_hover_label)

func _panel(min_w: float) -> PanelContainer:
	var p := PanelContainer.new()
	p.mouse_entered.connect(_clear_hover)
	var sb := Pal.card()
	sb.bg_color = Color(Pal.PANEL, 0.93)
	sb.set_content_margin_all(Pal.SP_M)
	sb.shadow_size = 6
	p.add_theme_stylebox_override("panel", sb)
	p.custom_minimum_size.x = min_w
	return p

func _h(text: String) -> Label:
	var l := Label.new(); l.text = text; l.theme_type_variation = "HeaderSmall"
	return l

func _muted(text: String, size := 13) -> Label:
	var l := Label.new(); l.text = text; l.theme_type_variation = "MutedLabel"
	l.add_theme_font_size_override("font_size", size)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

func _btn(text: String, cb: Callable, tip := "", primary := false) -> Button:
	var b := Button.new(); b.text = text; b.tooltip_text = tip
	b.custom_minimum_size.y = 38
	if primary: b.theme_type_variation = "PrimaryButton"
	b.pressed.connect(cb)
	return b

func _build_top_bar() -> Control:
	var p := _panel(0)
	var h := HBoxContainer.new()
	p.add_child(h)
	h.add_child(Kit.icon_button("arrow-left", "Back to the dashboard", func(): _leave()))
	var tv := VBoxContainer.new(); tv.add_theme_constant_override("separation", -2)
	var t := Label.new(); t.text = "Heart Lab"; t.theme_type_variation = "HeaderMedium"
	var st := Label.new(); st.text = "Stage 1 · anatomy, physiology & disease"; st.theme_type_variation = "MutedLabel"
	st.add_theme_font_size_override("font_size", 12)
	tv.add_child(t); tv.add_child(st); h.add_child(tv)
	var opts := []
	for m in MODES:
		opts.append([m, MODE_NAMES[m], MODE_ICONS[m]])
	var seg := Kit.segmented(opts, func(id): _set_mode(id))
	_mode_buttons = seg["buttons"]
	h.add_child(seg["root"])
	var sp := Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; h.add_child(sp)
	_labels_toggle = CheckButton.new(); _labels_toggle.text = "Labels"; _labels_toggle.icon = Kit.icon("tag")
	_labels_toggle.toggled.connect(func(on): _labels.visible = on; if not on: _labels.clear_all())
	h.add_child(_labels_toggle)
	var vm := MenuButton.new(); vm.text = "View"; vm.icon = Kit.icon("eye"); vm.flat = false; vm.custom_minimum_size.y = 40
	var pm := vm.get_popup()
	for v in ["anterior", "posterior", "left", "right", "superior", "inferior"]:
		pm.add_item(v.capitalize() + " view")
	pm.add_separator()
	pm.add_item("Focus selected structure")
	pm.add_item("Reset camera")
	pm.id_pressed.connect(func(i: int):
		var names := ["anterior", "posterior", "left", "right", "superior", "inferior"]
		if i < names.size(): cam.set_preset(names[i])
		elif i == 7 and heart.get_selected() != "": _focus_part(heart.get_selected())
		elif i == 8: cam.reset_view())
	h.add_child(vm)
	h.add_child(Kit.appearance_menu())
	h.add_child(Kit.icon_button("focus", "Focus mode: hide the side panels (F)", _toggle_focus))
	h.add_child(Kit.button("EP Lab", "zap", func(): _leave_to("res://scenes/stage2/ep_lab.tscn"), "Stage 2: conduction system & ECG on this heart", "GhostButton"))
	h.add_child(Kit.button("Reset all", "rotate-ccw", _reset_all, "Show everything, clear cuts, removals, isolation and disease; reset the camera", "PrimaryButton"))
	return p

func _leave() -> void:
	heart.set_cutaway(false)
	heart.reset_physiology_uniforms()
	SceneRouter.go_home()

func _leave_to(path: String) -> void:
	heart.set_cutaway(false)
	heart.reset_physiology_uniforms()
	SceneRouter.goto(path)

func _build_left_panel() -> Control:
	var p := _panel(336)
	p.custom_minimum_size.x = 336
	var stack := Control.new()
	stack.size_flags_vertical = Control.SIZE_EXPAND_FILL
	p.add_child(stack)
	var builders := {"explore": _page_explore, "dissect": _page_dissect, "physiology": _page_physiology, "diseases": _page_diseases, "quiz": _page_quiz}
	for m in MODES:
		var sc := ScrollContainer.new()
		sc.set_anchors_preset(Control.PRESET_FULL_RECT)
		sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		var v := VBoxContainer.new()
		v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		v.add_theme_constant_override("separation", Pal.SP_S)
		sc.add_child(v)
		(builders[m] as Callable).call(v)
		stack.add_child(sc)
		_left_pages[m] = sc
	return p

# ------------------------------------------------------------------ Explore page
func _page_explore(v: VBoxContainer) -> void:
	v.add_child(_h("STRUCTURES"))
	v.add_child(_muted("Tick = show · click name = details", 12))
	_tree = Tree.new()
	_tree.hide_root = true
	_tree.custom_minimum_size.y = 440
	_tree.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_tree.select_mode = Tree.SELECT_ROW
	v.add_child(_tree)
	var root := _tree.create_item()
	for g in heart.groups:
		var gi := _tree.create_item(root)
		gi.set_cell_mode(0, TreeItem.CELL_MODE_CHECK); gi.set_checked(0, true); gi.set_editable(0, true)
		gi.set_text(0, g["name"]); gi.set_metadata(0, {"type": "group", "id": g["id"]})
		gi.collapsed = g["id"] in ["coronary_arteries", "cardiac_veins", "great_vessels"]
		_tree_items[g["id"]] = gi
		for id in heart.get_parts_in_group(g["id"]):
			var it := _tree.create_item(gi)
			it.set_cell_mode(0, TreeItem.CELL_MODE_CHECK); it.set_checked(0, true); it.set_editable(0, true)
			var info := heart.get_part_info(id)
			it.set_text(0, info.get("name", id) + ("  *" if info.get("reconstructed", false) else ""))
			it.set_metadata(0, {"type": "part", "id": id})
			_tree_items[id] = it
	_tree.item_edited.connect(func():
		var it := _tree.get_edited()
		if it == null: return
		var md: Dictionary = it.get_metadata(0)
		if md["type"] == "group": heart.set_group_visible(md["id"], it.is_checked(0))
		else: heart.set_part_visible(md["id"], it.is_checked(0))
		_sync_checks())
	_tree.item_selected.connect(func():
		if _syncing: return
		var it := _tree.get_selected()
		if it and (it.get_metadata(0) as Dictionary)["type"] == "part":
			var id: String = (it.get_metadata(0) as Dictionary)["id"]
			_select(id); _focus_part(id))
	var row := HBoxContainer.new()
	var a := _btn("Show all", func(): heart.show_all(); _sync_checks()); a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var b := _btn("Hide all", func():
		for id in heart.get_part_ids(): heart.set_part_visible(id, false)
		_sync_checks()); b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(a); row.add_child(b); v.add_child(row)
	v.add_child(_muted("* reconstructed (illustrative) geometry", 12))
	v.add_child(HSeparator.new())
	v.add_child(Kit.style_legend())

func _sync_checks() -> void:
	for g in heart.groups:
		var all_on := true
		for id in heart.get_parts_in_group(g["id"]):
			var vis: bool = heart.parts[id]["visible"]
			(_tree_items[id] as TreeItem).set_checked(0, vis)
			all_on = all_on and vis
		(_tree_items[g["id"]] as TreeItem).set_checked(0, all_on)

# ------------------------------------------------------------------ Dissect page
func _page_dissect(v: VBoxContainer) -> void:
	v.add_child(_h("ANATOMICAL CUTS"))
	v.add_child(_muted("Pick a standard section", 12))
	var grid := GridContainer.new(); grid.columns = 2
	var cuts := [["Four-chamber", "four_chamber", "Plane through the apex and both AV valves: all four chambers, both AV valves and the septa"],
		["Long axis (LVOT)", "long_axis", "Plane through the apex, mitral and aortic valves: LV inflow and outflow"],
		["Short axis", "short_axis", "Cross-section of both ventricles at mid-ventricular level"],
		["Valve plane", "valve_plane", "Removes the atria and great vessels to show the cardiac base and valves"],
		["Coronal", "coronal", "Frontal section"], ["Sagittal", "sagittal", "Side-to-side section"],
		["Transverse", "transverse", "Horizontal (axial) section"], ["Cut along my view", "view", "Cuts perpendicular to the current viewing direction"]]
	for c in cuts:
		var nm: String = c[1]
		var b := _btn(c[0], func(): _apply_cut(nm, true), c[2])
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.add_child(b)
	v.add_child(grid)
	_cut_status = _muted("No cut", 12)
	v.add_child(_cut_status)
	v.add_child(_slider_row("Depth", -1.0, 1.0, 0.0, func(x): _update_cut()))
	_cut_depth = v.get_child(v.get_child_count() - 1).get_meta("slider")
	v.add_child(_slider_row("Tilt (vertical)", -45.0, 45.0, 0.0, func(x): _update_cut()))
	_cut_tilt_a = v.get_child(v.get_child_count() - 1).get_meta("slider")
	v.add_child(_slider_row("Tilt (horizontal)", -45.0, 45.0, 0.0, func(x): _update_cut()))
	_cut_tilt_b = v.get_child(v.get_child_count() - 1).get_meta("slider")
	var r := HBoxContainer.new()
	_cut_flip = CheckBox.new(); _cut_flip.text = "Flip side"; _cut_flip.toggled.connect(func(_on): _update_cut())
	r.add_child(_cut_flip)
	var rm := _btn("Remove cut", func(): _cut_name = ""; heart.set_cutaway(false); _cut_status.text = "No cut")
	rm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	r.add_child(rm)
	v.add_child(r)
	v.add_child(HSeparator.new())
	v.add_child(_h("SCALPEL"))
	_scalpel = CheckButton.new(); _scalpel.text = "Scalpel: click to remove a structure"
	v.add_child(_scalpel)
	var r2 := HBoxContainer.new()
	var u := _btn("Undo", func():
		var id := heart.undo_remove()
		if id != "": _hint("Restored: " + heart.get_part_info(id).get("name", id)))
	u.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var ra := _btn("Restore all", func(): heart.restore_all_removed()); ra.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	r2.add_child(u); r2.add_child(ra); v.add_child(r2)
	_removed_label = _muted("0 structure(s) removed", 12)
	v.add_child(_removed_label)
	v.add_child(_muted("Quick dissection steps", 12))
	var steps := [["Remove coronary vessels", ["coronary_arteries", "cardiac_veins"]],
		["Remove great vessels", ["great_vessels"]],
		["Remove atria (show valves)", ["_atria"]],
		["Remove RV wall (show septum)", ["_rv"]]]
	for s in steps:
		var targets: Array = s[1]
		var b := _btn(s[0], func(): _dissect_step(targets))
		v.add_child(b)
	v.add_child(HSeparator.new())
	v.add_child(_h("EXPLODED VIEW"))
	v.add_child(_slider_row("Separate", 0.0, 1.0, 0.0, func(x): heart.set_explode(x)))
	_explode = v.get_child(v.get_child_count() - 1).get_meta("slider")
	v.add_child(_muted("Tip: cut + Labels", 12))

func _dissect_step(targets: Array) -> void:
	var ids := PackedStringArray()
	for t in targets:
		match t:
			"_atria": ids.append_array(["right_atrium", "left_atrium", "interatrial_septum", "superior_vena_cava", "inferior_vena_cava", "pulmonary_veins"])
			"_rv": ids.append_array(["right_ventricle", "pulmonary_trunk_root"])
			_: ids.append_array(heart.get_parts_in_group(t))
	for id in ids:
		heart.remove_part(id)

func _slider_row(label: String, mn: float, mx: float, val: float, cb: Callable) -> HBoxContainer:
	var r := HBoxContainer.new()
	var l := Label.new(); l.text = label; l.theme_type_variation = "MutedLabel"; l.custom_minimum_size.x = 64
	l.add_theme_font_size_override("font_size", 13)
	r.add_child(l)
	var s := HSlider.new(); s.min_value = mn; s.max_value = mx; s.step = (mx - mn) / 200.0; s.value = val
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL; s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	s.value_changed.connect(cb)
	r.add_child(s)
	r.set_meta("slider", s)
	return r

## Cut presets. The plane removes the half-space on the side of the normal; the camera views from that side.
func _apply_cut(name_: String, move_camera: bool) -> void:
	var apex := heart.get_landmark("apex")
	var mitral := heart.get_landmark("mitral_center")
	var tric := heart.get_landmark("tricuspid_center")
	var aov := heart.get_landmark("aortic_valve_center")
	var base := heart.get_landmark("base")
	var hc := heart.get_landmark("heart_center")
	var axis := (base - apex).normalized()
	var n := Vector3.BACK
	var p := hc
	var label := name_
	match name_:
		"four_chamber":
			n = (mitral - apex).cross(tric - apex).normalized()
			if n.z < 0.0: n = -n
			p = (apex + mitral + tric) / 3.0; label = "Four-chamber section"
		"long_axis":
			n = (mitral - apex).cross(aov - apex).normalized()
			if n.dot(heart.get_landmark("RV") - apex) < 0.0: n = -n
			p = (apex + mitral + aov) / 3.0; label = "Long-axis (LVOT) section"
		"short_axis":
			n = axis; p = apex + (base - apex) * 0.5; label = "Short-axis section (mid-ventricle)"
		"valve_plane":
			n = axis; p = base + axis * 0.010; label = "Valve plane (base of the heart)"
		"coronal":
			n = Vector3(0, 0, 1); label = "Coronal section"
		"sagittal":
			n = Vector3(-1, 0, 0); label = "Sagittal section"
		"transverse":
			n = Vector3(0, 1, 0); p = hc + Vector3(0, -0.012, 0); label = "Transverse section"
		"view":
			n = cam.get_view_direction(); p = cam.get_target(); label = "Section along the current view"
	_cut_name = name_
	_cut_n = n
	_cut_point = p
	_cut_depth.set_value_no_signal(0.0)
	_cut_tilt_a.set_value_no_signal(0.0)
	_cut_tilt_b.set_value_no_signal(0.0)
	_cut_flip.set_pressed_no_signal(false)
	_cut_status.text = label
	_update_cut()
	if move_camera:
		cam.look_from_direction(n, hc, 0.27)

func _update_cut() -> void:
	if _cut_name == "":
		return
	var n := _cut_n
	var ref := Vector3.UP if absf(n.y) < 0.9 else Vector3.RIGHT
	var u := n.cross(ref).normalized()
	var w := n.cross(u).normalized()
	n = n.rotated(u, deg_to_rad(_cut_tilt_a.value)).rotated(w, deg_to_rad(_cut_tilt_b.value)).normalized()
	if _cut_flip.button_pressed:
		n = -n
	var d := n.dot(heart.global_transform * _cut_point) + float(_cut_depth.value) * 0.04
	heart.set_cutaway(true, Plane(n, d))

# ------------------------------------------------------------------ Physiology page
func _page_physiology(v: VBoxContainer) -> void:
	v.add_child(_h("CARDIAC CYCLE"))
	var r := HBoxContainer.new()
	_play_btn = Kit.button("Pause", "pause", _toggle_play, "Space"); _play_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	r.add_child(_play_btn)
	var rs := _btn("Restart", func(): engine.restart()); r.add_child(rs)
	v.add_child(r)
	_beat_toggle = CheckButton.new(); _beat_toggle.text = "Beating animation"; _beat_toggle.button_pressed = true
	_beat_toggle.toggled.connect(func(on): engine.set_beating(on))
	v.add_child(_beat_toggle)
	var hr_row := HBoxContainer.new()
	var hl := Label.new(); hl.text = "Heart rate"; hl.theme_type_variation = "MutedLabel"
	hr_row.add_child(hl)
	var sp := Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; hr_row.add_child(sp)
	_hr_value = Label.new(); _hr_value.add_theme_font_size_override("font_size", 22); _hr_value.add_theme_color_override("font_color", Pal.ACCENT)
	hr_row.add_child(_hr_value)
	var bpm := Label.new(); bpm.text = "bpm"; bpm.theme_type_variation = "MutedLabel"; hr_row.add_child(bpm)
	v.add_child(hr_row)
	_hr_slider = HSlider.new(); _hr_slider.min_value = 40; _hr_slider.max_value = 180; _hr_slider.step = 1; _hr_slider.value = 72
	_hr_slider.value_changed.connect(func(x): if not _syncing_hr: engine.set_hr(x))
	v.add_child(_hr_slider)
	var pr := GridContainer.new()   # 2 x 2 so the presets fit the 300 px panel
	pr.columns = 2
	for spec in [["Sleep 50", 50], ["Rest 72", 72], ["Walk 110", 110], ["Exercise 160", 160]]:
		var val: float = spec[1]
		var b := _btn(spec[0], func():
			if engine.condition.get("id", "") != "normal": engine.set_condition("normal")
			engine.set_hr(val))
		b.add_theme_font_size_override("font_size", 12); b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		pr.add_child(b)
	v.add_child(pr)
	var sr := HBoxContainer.new()
	var sl := Label.new(); sl.text = "Speed"; sl.theme_type_variation = "MutedLabel"; sl.custom_minimum_size.x = 64; sr.add_child(sl)
	var ob := OptionButton.new()
	_speed_option = ob
	for s in ["1× real time", "0.5× slow", "0.25× slower", "0.1× slow motion"]:
		ob.add_item(s)
	ob.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ob.item_selected.connect(func(i): engine.speed = [1.0, 0.5, 0.25, 0.1][i])
	sr.add_child(ob); v.add_child(sr)
	v.add_child(_slider_row("Motion", 0.5, 2.0, 1.0, func(x): engine.motion_scale = x))
	v.add_child(_muted("Motion: exaggerates wall movement", 12))
	v.add_child(HSeparator.new())
	v.add_child(_h("CURRENT PHASE"))
	_phase_title = Label.new(); _phase_title.theme_type_variation = "HeaderMedium"
	_phase_title.add_theme_font_size_override("font_size", 17); _phase_title.add_theme_color_override("font_color", Pal.ACCENT)
	_phase_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(_phase_title)
	_cycle_bar = ProgressBar.new(); _cycle_bar.show_percentage = false; _cycle_bar.max_value = 1.0; _cycle_bar.custom_minimum_size.y = 6
	v.add_child(_cycle_bar)
	_phase_text = _muted("", 13)
	_phase_text.custom_minimum_size.y = 90
	v.add_child(_phase_text)
	_valve_av = Label.new(); _valve_sl = Label.new()
	for l in [_valve_av, _valve_sl]:
		l.add_theme_font_size_override("font_size", 12)
		l.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		v.add_child(l)
	v.add_child(_muted("Tip: 0.1× speed to follow the valves", 12))
	v.add_child(HSeparator.new())
	v.add_child(_h("BLOOD FLOW"))
	_blood_toggle = CheckButton.new(); _blood_toggle.text = "Show blood"; _blood_toggle.button_pressed = true
	_blood_toggle.toggled.connect(func(on): _set_blood(on, on and _see_toggle.button_pressed))
	v.add_child(_blood_toggle)
	_see_toggle = CheckButton.new(); _see_toggle.text = "See-through walls"; _see_toggle.button_pressed = true
	_see_toggle.toggled.connect(func(on): _set_blood(_blood_toggle.button_pressed, on))
	v.add_child(_see_toggle)
	var lg := VBoxContainer.new(); lg.add_theme_constant_override("separation", 4)
	lg.add_child(Kit.legend_item(Color(0.30, 0.33, 0.85), "Oxygen-poor → lungs"))
	lg.add_child(Kit.legend_item(Color(0.86, 0.10, 0.10), "Oxygen-rich → body"))
	v.add_child(lg)
	v.add_child(_muted("Blood waits in the atria while the AV valves are shut, fills the ventricles when they open and is ejected through the aortic and pulmonary valves.", 12))

## Blood flow in the Physiology tab: cells stream through the chambers in time with the valves.
## See-through ghosts the walls (valves and papillary muscles stay solid) so the blood can be followed.
func _set_blood(on: bool, see_through: bool) -> void:
	if blood == null:
		return
	blood.visible = on
	if _blood_toggle: _blood_toggle.set_pressed_no_signal(on)
	if _see_toggle: _see_toggle.set_pressed_no_signal(on and see_through)
	if on and see_through:
		heart.isolate(PackedStringArray(SEE_THROUGH_KEEP))
	elif mode == "physiology" or not on:
		heart.isolate(PackedStringArray())

func _update_live_panels() -> void:
	# physiology page
	if _phase_title and _left_pages["physiology"].visible:
		var pid := engine.get_phase_id()
		var ph: Dictionary = phases.get(pid, {})
		_phase_title.text = ph.get("name", engine.get_phase())
		var pts: Array = ph.get("points", [])
		_phase_text.text = "\n".join(pts.map(func(x): return "•  " + str(x))) if pts.size() > 0 else ph.get("text", "")
		var vs := engine.get_valve_states()
		_set_valve_chip(_valve_av, "Mitral & tricuspid", vs["av"])
		_set_valve_chip(_valve_sl, "Aortic & pulmonary", vs["sl"])
		var r := engine.rr()
		_cycle_bar.value = fposmod(engine.sim_time, r) / r if engine.get_rhythm() == "sinus" else 0.0
	if _monitor.visible:
		var h := engine.get_hemodynamics()
		var rh := engine.get_rhythm()
		_vitals["hr"].text = "—" if rh == "vf" else "%d" % int(round(engine.hr))
		_vitals["bp"].text = String(h["bp"])
		_vitals["sv"].text = "%d mL" % int(round(h["sv"]))
		_vitals["ef"].text = "%d %%" % int(round(h["ef"]))
		_vitals["co"].text = "%.1f L/min" % h["co"]
		_vitals["rhythm"].text = {"sinus": "Sinus", "af": "AF (irregular)", "chb": "AV dissociation", "vf": "VF"}.get(rh, rh)
		_monitor_phase.text = engine.get_phase()

func _set_valve_chip(l: Label, name_: String, open: bool) -> void:
	l.text = "%s: %s" % [name_, "OPEN" if open else "CLOSED"]
	var c := Pal.SUCCESS if open else Pal.TEXT_MUTED
	l.add_theme_stylebox_override("normal", Pal.chip(c))
	l.add_theme_color_override("font_color", c)

var _syncing_hr := false

func _on_rate_changed(hr: float) -> void:
	_syncing_hr = true
	var r := engine.get_hr_range()
	for pair in [[_hr_slider, _hr_value], [_dis_hr_slider, _dis_hr_value]]:
		var s: HSlider = pair[0]
		var l: Label = pair[1]
		if s == null: continue
		s.min_value = r.x; s.max_value = maxf(r.y, r.x + 1)
		s.editable = r.y > r.x
		s.set_value_no_signal(hr)
		l.text = "—" if engine.get_rhythm() == "vf" else "%d" % int(round(hr))
	_syncing_hr = false

# ------------------------------------------------------------------ Diseases page
func _page_diseases(v: VBoxContainer) -> void:
	v.add_child(_h("CONDITIONS"))
	v.add_child(_muted("Pick a condition · compare with normal", 12))
	var group := ButtonGroup.new()
	var last_cat := ""
	for c in engine.conditions:
		if c.get("category", "") != last_cat:
			last_cat = c.get("category", "")
			var cl := Label.new(); cl.text = last_cat.to_upper(); cl.add_theme_font_size_override("font_size", 12)
			cl.add_theme_color_override("font_color", Pal.TEXT_MUTED)
			v.add_child(cl)
		var b := Button.new(); b.toggle_mode = true; b.button_group = group
		b.text = c["name"]; b.tooltip_text = c.get("short", "")
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		var cid: String = c["id"]
		b.pressed.connect(func(): engine.set_condition(cid))
		v.add_child(b)
		_cond_buttons[cid] = b
	v.add_child(HSeparator.new())
	var sr := HBoxContainer.new()
	var sl := Label.new(); sl.text = "Severity"; sl.theme_type_variation = "MutedLabel"; sr.add_child(sl)
	var sp := Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; sr.add_child(sp)
	_sev_label = Label.new(); _sev_label.text = "Severe"; _sev_label.add_theme_color_override("font_color", Pal.ACCENT); sr.add_child(_sev_label)
	v.add_child(sr)
	_sev_slider = HSlider.new(); _sev_slider.min_value = 0.15; _sev_slider.max_value = 1.0; _sev_slider.step = 0.01; _sev_slider.value = 1.0
	_sev_slider.value_changed.connect(func(x):
		engine.set_severity(x)
		_sev_label.text = "Mild" if x < 0.45 else ("Moderate" if x < 0.8 else "Severe"))
	v.add_child(_sev_slider)
	var hr_row := HBoxContainer.new()
	var hl := Label.new(); hl.text = "Ventricular rate"; hl.theme_type_variation = "MutedLabel"; hr_row.add_child(hl)
	var sp2 := Control.new(); sp2.size_flags_horizontal = Control.SIZE_EXPAND_FILL; hr_row.add_child(sp2)
	_dis_hr_value = Label.new(); _dis_hr_value.add_theme_color_override("font_color", Pal.ACCENT); hr_row.add_child(_dis_hr_value)
	v.add_child(hr_row)
	_dis_hr_slider = HSlider.new(); _dis_hr_slider.step = 1
	_dis_hr_slider.value_changed.connect(func(x): if not _syncing_hr: engine.set_hr(x))
	v.add_child(_dis_hr_slider)
	v.add_child(_btn("Show recommended view", func(): _recommended_view(), "Camera / cut that best shows this condition", true))
	v.add_child(_btn("Back to normal heart", func(): engine.set_condition("normal")))
	v.add_child(_muted("Simulated · illustrative · not diagnostic", 12))

func _recommended_view() -> void:
	var id: String = engine.condition.get("id", "normal")
	var vname: String = RECOMMENDED_VIEW.get(id, "anterior")
	heart.isolate(PackedStringArray())
	if vname in ["four_chamber", "short_axis", "valve_plane", "long_axis"]:
		_apply_cut(vname, true)
	else:
		_cut_name = ""
		heart.set_cutaway(false)
		cam.set_preset(vname)
	if id == "aortic_stenosis":
		heart.isolate(PackedStringArray(["aortic_valve", "aortic_root", "mitral_valve", "left_ventricle", "interventricular_septum"]))

func _on_condition_changed(c: Dictionary) -> void:
	var id: String = c.get("id", "")
	if _cond_buttons.has(id):
		(_cond_buttons[id] as Button).set_pressed_no_signal(true)
	if _sev_slider:
		_sev_slider.set_value_no_signal(engine.severity)
	if mode == "diseases":
		_show_condition_info()

# ------------------------------------------------------------------ Quiz page
func _page_quiz(v: VBoxContainer) -> void:
	v.add_child(_h("IDENTIFY THE STRUCTURE"))
	v.add_child(_muted("10 questions · click the named structure", 12))
	v.add_child(_btn("Start new quiz", _quiz_start, "", true))
	_quiz_q = Label.new(); _quiz_q.theme_type_variation = "HeaderMedium"; _quiz_q.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_quiz_q.add_theme_color_override("font_color", Pal.ACCENT)
	v.add_child(_quiz_q)
	_quiz_feedback = _muted("", 14)
	v.add_child(_quiz_feedback)
	_quiz_score = Label.new(); v.add_child(_quiz_score)
	var r := HBoxContainer.new()
	var sk := _btn("Skip", func(): if _quiz_active: _quiz_answer("__skip__")); sk.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var hint := _btn("Hint", func():
		if _quiz_active:
			_quiz_feedback.text = "Group: " + heart.get_group_name(heart.get_part_info(_quiz_target).get("group", "")) + " · " + heart.get_part_info(_quiz_target).get("location", ""))
	hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	r.add_child(sk); r.add_child(hint); v.add_child(r)

func _quiz_start() -> void:
	_quiz_n = 0; _quiz_correct = 0; _quiz_active = true
	_select("")
	_quiz_next()

func _quiz_next() -> void:
	if _quiz_n >= 10:
		_quiz_active = false
		_quiz_q.text = "Finished!"
		_quiz_feedback.text = "Score: %d / 10. Start again to get a new set." % _quiz_correct
		return
	var pool: Array = []
	for id in _labels.priority:
		if id != _quiz_target and heart.has_part(id):
			pool.append(id)
	_quiz_target = pool[randi() % pool.size()]
	_quiz_n += 1
	_quiz_q.text = "%d. Click: %s" % [_quiz_n, heart.get_part_info(_quiz_target).get("name", _quiz_target)]
	_quiz_score.text = "Correct: %d / %d" % [_quiz_correct, _quiz_n - 1]

func _quiz_answer(id: String) -> void:
	var tname: String = heart.get_part_info(_quiz_target).get("name", _quiz_target)
	if id == _quiz_target:
		_quiz_correct += 1
		_quiz_feedback.text = "Correct — " + tname
		_quiz_feedback.add_theme_color_override("font_color", Pal.SUCCESS)
	elif id == "__skip__":
		_quiz_feedback.text = "Skipped — it was highlighted: " + tname
		_quiz_feedback.add_theme_color_override("font_color", Pal.WARNING)
	elif id == "":
		return
	else:
		_quiz_feedback.text = "Not quite — that was the %s. Highlighted: %s" % [heart.get_part_info(id).get("name", id), tname]
		_quiz_feedback.add_theme_color_override("font_color", Pal.DANGER)
	heart.set_selected(_quiz_target)
	_quiz_active = false
	await get_tree().create_timer(1.6).timeout
	heart.set_selected("")
	_quiz_active = true
	_quiz_next()

# ================================================================== info panel (right)
func _build_info_panel() -> Control:
	var p := _panel(340)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", Pal.SP_S)
	p.add_child(v)
	_info_back = Kit.button("Back to condition", "chevron-left", func(): _select(""), "", "GhostButton")
	_info_back.theme_type_variation = "FlatButton"
	_info_back.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	v.add_child(_info_back)
	_info_header = _h("SELECTION")
	v.add_child(_info_header)
	_info_title = Label.new(); _info_title.theme_type_variation = "HeaderMedium"; _info_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(_info_title)
	_info_chip = Label.new(); _info_chip.add_theme_font_size_override("font_size", 12)
	_info_chip.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	v.add_child(_info_chip)
	_info_body = RichTextLabel.new(); _info_body.bbcode_enabled = true
	_info_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_info_body.add_theme_font_size_override("normal_font_size", 14)
	_info_body.add_theme_font_size_override("bold_font_size", 14)
	_info_body.add_theme_constant_override("line_separation", 3)
	v.add_child(_info_body)
	_info_more = Kit.button("More details", "chevron-right", func():
		_details_open = not _details_open
		_refresh_info(), "Show or hide the full description", "GhostButton")
	_info_more.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	v.add_child(_info_more)
	_info_actions = HBoxContainer.new()
	for spec in [["Focus", "Centre the camera on this structure"], ["Isolate", "Show this structure; ghost all others"], ["Hide", "Hide this structure"], ["Clear", "Clear selection and isolation"]]:
		var act: String = spec[0]
		var b := _btn(act, func(): _info_action(act), spec[1])
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_info_actions.add_child(b)
	v.add_child(_info_actions)
	return p

func _info_action(act: String) -> void:
	var id := heart.get_selected()
	match act:
		"Focus": if id != "": _focus_part(id)
		"Isolate": if id != "": heart.isolate(PackedStringArray([id])); _focus_part(id)
		"Hide":
			if id != "":
				heart.set_part_visible(id, false); _sync_checks(); _select("")
		"Clear": heart.isolate(PackedStringArray()); _select("")

func _section(t: String, body: String) -> String:
	if body.strip_edges() == "":
		return ""
	return "[color=#0B7A52][b]%s[/b][/color]\n%s\n\n" % [t, body]

## First sentence of a text, shortened for a bullet point.
func _brief(t: String, max_len := 130) -> String:
	t = t.strip_edges()
	var cut := -1
	for sep in [". ", "; "]:
		var i := t.find(sep)
		if i > 0 and (cut < 0 or i < cut):
			cut = i
	if cut > 0:
		t = t.substr(0, cut)
	t = t.trim_suffix(".")
	if t.length() > max_len:
		var cut2 := t.substr(0, max_len).rfind(", ")
		if cut2 < max_len * 0.5:
			cut2 = t.substr(0, max_len).rfind(" ")
		t = t.substr(0, cut2).strip_edges() + "…"
	return t

func _bullets(items: Array, color := "#15241F") -> String:
	var t := ""
	for x in items:
		if str(x).strip_edges() != "":
			t += "[color=%s]•[/color]  %s\n" % ["#0B7A52", str(x)]
	return "[color=%s]%s[/color]\n" % [color, t.strip_edges()] if t != "" else ""

func _refresh_info() -> void:
	if _info_kind == "condition":
		_show_condition_info()
	else:
		_show_part_info(_info_id)

func _show_part_info(id: String) -> void:
	if id != _info_id:
		_details_open = false
	_info_kind = "part"
	_info_id = id
	_info_back.visible = mode == "diseases" and id != ""
	_info_actions.visible = true
	_info_header.text = "SELECTION"
	for b in _info_actions.get_children():
		(b as Button).disabled = id == "" and (b as Button).text != "Clear"
	if id == "":
		_info_more.visible = false
		_info_title.text = "Nothing selected"
		_info_chip.visible = false
		_info_body.text = _bullets(["Click a structure in 3D or in the list", "Physiology: watch the beat", "Dissect: open the heart", "Diseases: compare with normal"], "#5B6B65")
		return
	var info := heart.get_part_info(id)
	_info_title.text = info.get("name", id)
	_info_chip.text = heart.get_group_name(info.get("group", ""))
	_info_chip.add_theme_stylebox_override("normal", Pal.chip(Pal.ACCENT))
	_info_chip.add_theme_color_override("font_color", Pal.ACCENT)
	_info_chip.visible = true
	var t := ""
	if info.get("reconstructed", false):
		t += "[color=#A86400]Illustrative (reconstructed) geometry[/color]\n\n"
	t += "[color=#5B6B65][b]KEY POINTS[/b][/color]\n"
	t += _bullets(["[b]Where:[/b] " + _brief(info.get("location", "")), "[b]Does:[/b] " + _brief(info.get("function", "")), "[b]Clinical:[/b] " + _brief(info.get("clinical", ""))])
	if _details_open:
		t += "\n" + _section("Location", info.get("location", ""))
		t += _section("Structure", info.get("structure", ""))
		t += _section("Function", info.get("function", ""))
		t += _section("Relations", info.get("relations", ""))
		t += _section("Clinical relevance", info.get("clinical", ""))
		var fma: String = info.get("fma_id", "")
		t += "[color=#5B6B65][font_size=12]%s%s[/font_size][/color]" % [(fma + " · ") if fma != "" else "", info.get("source", "")]
	_info_body.text = t
	_info_body.scroll_to_line(0)
	_set_more_button()

func _set_more_button() -> void:
	_info_more.visible = true
	_info_more.text = "Less" if _details_open else "More details"
	_info_more.icon = Kit.icon("chevron-left" if _details_open else "chevron-right")

func _show_condition_info() -> void:
	var c := engine.condition
	if _info_kind != "condition" or _info_id != c.get("id", ""):
		_details_open = false
	_info_kind = "condition"
	_info_id = c.get("id", "")
	_info_back.visible = false
	_info_actions.visible = false
	_info_header.text = "CONDITION"
	_info_title.text = c.get("name", "")
	_info_chip.text = c.get("category", "")
	var col := Pal.SUCCESS if c.get("id", "") == "normal" else Pal.WARNING
	_info_chip.add_theme_stylebox_override("normal", Pal.chip(col))
	_info_chip.add_theme_color_override("font_color", col)
	_info_chip.visible = true
	var t := "[color=#5B6B65][b]KEY POINTS[/b][/color]\n"
	t += _bullets(c.get("key_points", [_brief(c.get("summary", ""))]))
	var lf: Array = c.get("look_for", [])
	if lf.size() > 0:
		t += "\n[color=#5B6B65][b]IN THE 3D HEART[/b][/color]\n" + _bullets([_brief(lf[0], 90)] + ([_brief(lf[1], 90)] if lf.size() > 1 else []))
	if _details_open:
		t += "\n" + _section("Summary", c.get("summary", ""))
		t += _section("What happens", c.get("pathophysiology", ""))
		t += _section("Look for in the 3D heart", _bullets(lf).strip_edges())
		t += _section("ECG (simulated on the monitor)", c.get("ecg", ""))
		t += _section("Clinical points", _bullets(c.get("clinical", [])).strip_edges())
		var note: String = (c.get("sim", {}) as Dictionary).get("hemo", {}).get("note", "")
		if note != "":
			t += "[color=#5B6B65][i]Vital signs: %s.[/i][/color]" % note
	_info_body.text = t
	_info_body.scroll_to_line(0)
	_set_more_button()

# ================================================================== monitor (bottom centre)
func _build_monitor() -> Control:
	_monitor = _panel(0)
	_monitor.custom_minimum_size.y = 170
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", Pal.SP_M)
	_monitor.add_child(h)
	var left := VBoxContainer.new(); left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var top := HBoxContainer.new()
	var ll := Label.new(); ll.text = "ECG"; ll.theme_type_variation = "HeaderSmall"; top.add_child(ll)
	var lead := OptionButton.new(); lead.add_item("Lead II"); lead.add_item("Lead V2")
	lead.item_selected.connect(func(i): _ecg.lead = ["II", "V2"][i])
	lead.add_theme_font_size_override("font_size", 12)
	top.add_child(lead)
	var sp := Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; top.add_child(sp)
	_monitor_phase = Label.new(); _monitor_phase.theme_type_variation = "MutedLabel"; _monitor_phase.add_theme_font_size_override("font_size", 12)
	top.add_child(_monitor_phase)
	left.add_child(top)
	_ecg = EcgMonitor.new()
	_ecg.engine = engine
	_ecg.size_flags_vertical = Control.SIZE_EXPAND_FILL
	left.add_child(_ecg)
	h.add_child(left)
	var g := GridContainer.new(); g.columns = 2
	g.add_theme_constant_override("h_separation", 10); g.add_theme_constant_override("v_separation", 2)
	for spec in [["hr", "HR (bpm)", Pal.SUCCESS], ["bp", "BP (mmHg)", Color("#C2362F")], ["sv", "Stroke volume", Pal.TEXT],
			["ef", "Ejection fraction", Pal.TEXT], ["co", "Cardiac output", Pal.TEXT], ["rhythm", "Rhythm", Pal.ACCENT]]:
		var k := Label.new(); k.text = spec[1]; k.theme_type_variation = "MutedLabel"; k.add_theme_font_size_override("font_size", 12)
		var val := Label.new(); val.add_theme_font_size_override("font_size", 18 if spec[0] in ["hr", "bp"] else 14)
		val.add_theme_color_override("font_color", spec[2])
		g.add_child(k); g.add_child(val)
		_vitals[spec[0]] = val
	var gv := VBoxContainer.new()
	gv.add_child(g)
	gv.add_child(_muted("Illustrative values", 12))
	h.add_child(gv)
	return _monitor

# ================================================================== bottom bar
func _build_bottom_bar() -> Control:
	var h := HBoxContainer.new()
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hint_label = Label.new(); _hint_label.theme_type_variation = "MutedLabel"; _hint_label.add_theme_font_size_override("font_size", 12)
	h.add_child(_hint_label)
	var sp := Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; sp.mouse_filter = Control.MOUSE_FILTER_IGNORE; h.add_child(sp)
	var disc := Label.new(); disc.text = "Educational simulation · not for clinical use"
	disc.add_theme_color_override("font_color", Pal.WARNING); disc.add_theme_font_size_override("font_size", 12)
	h.add_child(disc)
	_fps_label = Label.new(); _fps_label.theme_type_variation = "MutedLabel"; _fps_label.add_theme_font_size_override("font_size", 12)
	_fps_label.custom_minimum_size.x = 64; _fps_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	h.add_child(_fps_label)
	return h

## Restores the normal heart (state only; the camera is kept unless reset_camera).
func _reset_session(reset_camera: bool) -> void:
	heart.reset_view_state()
	_cut_name = ""
	if _explode: _explode.set_value_no_signal(0.0)
	engine.set_condition("normal")
	engine.set_severity(1.0)
	engine.speed = 1.0
	engine.motion_scale = 1.0
	engine.playing = true
	if _speed_option: _speed_option.select(0)
	if _play_btn:
		_play_btn.text = "Pause"; _play_btn.icon = Kit.icon("pause")
	_sync_checks()
	_select("")
	if reset_camera:
		cam.reset_view()

func _reset_all() -> void:
	heart.reset_view_state()
	_cut_name = ""
	_explode.set_value_no_signal(0.0)
	engine.set_condition("normal")
	engine.set_severity(1.0)
	engine.playing = true
	_play_btn.text = "Pause"; _play_btn.icon = Kit.icon("pause")
	_sync_checks()
	_select("")
	cam.reset_view()

# ================================================================== developer QA screenshots
func _run_qa_shots(dir: String) -> void:
	DirAccess.make_dir_recursive_absolute(dir)
	var shots := [
		["01_explore_anterior", func(): _set_mode("explore"); _select("lad"); cam.set_preset("anterior", false)],
		["02_labels_left", func(): _select(""); _labels_toggle.button_pressed = true; cam.set_preset("left", false)],
		["03_four_chamber", func(): _set_mode("dissect"); _apply_cut("four_chamber", false); cam.look_from_direction(_cut_n, heart.get_landmark("heart_center"), 0.34, false)],
		["04_short_axis", func(): _apply_cut("short_axis", false); cam.look_from_direction(_cut_n, heart.get_landmark("heart_center"), 0.30, false)],
		["05_explode", func(): _labels_toggle.button_pressed = false; heart.set_cutaway(false); _cut_name = ""; heart.set_explode(0.8); cam.set_preset("anterior", false); cam.distance = 0.55],
		["06_physiology", func(): heart.set_explode(0.0); _set_mode("physiology"); cam.reset_view(false)],
		["06b_blood_flow_slow", func(): engine.speed = 0.25; cam.set_preset("anterior", false)],
		["07_stemi", func(): _set_mode("diseases"); engine.set_condition("anterior_stemi"); cam.set_preset("anterior", false)],
		["08_hcm_4ch", func(): engine.set_condition("hcm"); _recommended_view(); cam.look_from_direction(_cut_n, heart.get_landmark("heart_center"), 0.34, false)],
		["09_dcm_4ch", func(): engine.set_condition("dcm"); _recommended_view(); cam.look_from_direction(_cut_n, heart.get_landmark("heart_center"), 0.36, false)],
		["10_af", func(): heart.set_cutaway(false); _cut_name = ""; engine.set_condition("af"); cam.set_preset("posterior", false)],
	]
	for s in shots:
		(s[1] as Callable).call()
		for i in 70:
			await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(dir.path_join(s[0] + ".png"))
		print("QA shot: ", s[0])
	get_tree().quit()
