## SceneRouter (autoload)
## Scene changes with a short fade, and safe handling of missing scenes.
extends CanvasLayer

signal scene_changed(path: String)

const FADE_TIME := 0.22
var _fade: ColorRect
var _busy := false

func _ready() -> void:
	layer = 100
	_fade = ColorRect.new()
	_fade.color = Color(0.03, 0.05, 0.09, 0.0)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(_fade)

func goto(path: String) -> bool:
	if _busy:
		return false
	if path.is_empty() or not ResourceLoader.exists(path):
		push_error("SceneRouter: scene not found: '%s'" % path)
		return false
	_busy = true
	_fade.mouse_filter = Control.MOUSE_FILTER_STOP
	var t := create_tween()
	t.tween_property(_fade, "color:a", 1.0, FADE_TIME)
	await t.finished
	# leaving a stage: nothing (cuts, disease, EP overlay, calcified valves...) carries over
	HeartModel.reset_global_state()
	var err := get_tree().change_scene_to_file(path)
	if err != OK:
		push_error("SceneRouter: failed to open '%s' (%s)" % [path, error_string(err)])
	await get_tree().process_frame
	await get_tree().process_frame
	var t2 := create_tween()
	t2.tween_property(_fade, "color:a", 0.0, FADE_TIME)
	await t2.finished
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_busy = false
	scene_changed.emit(path)
	return err == OK

func go_home() -> void:
	goto("res://scenes/main/main.tscn")
