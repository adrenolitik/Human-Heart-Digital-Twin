## AppState (autoload)
## Global application state: stage status/progress, graphics-quality settings and
## persistent user settings (user://settings.cfg).
extends Node

signal quality_changed(level: int)
signal stage_status_changed(stage_id: String)
signal heart_style_changed(style_id: String)
signal backdrop_changed(backdrop_id: String)

const APP_NAME := "CardioCath 3D"
const APP_VERSION := "1.0.0 (public release: Stages 1–2)"
const STYLES_PATH := "res://data/anatomy/tissue_styles.json"
## Viewport backdrops behind the 3D heart: [id, name, centre colour, edge colour]
const BACKDROPS := [["mint", "Clinical mint", "#F7FBF8", "#C9DDD1"], ["studio", "Studio navy", "#1B2A44", "#070C16"], ["slate", "Neutral slate", "#3A3F47", "#15181D"], ["clinical", "Clinical grey", "#C9D1D4", "#8E989C"], ["light", "Atlas light", "#F4F1EC", "#C9C4BC"]]
const SETTINGS_PATH := "user://settings.cfg"

enum Quality { LOW, MEDIUM, HIGH }
const QUALITY_NAMES := ["Low (integrated GPU, battery)", "Medium (recommended)", "High"]

## Stage registry. `status`: "available" | "in_development" | "locked".
## `scene` is opened from the dashboard when the stage is not locked.
var stages: Array[Dictionary] = [
	{
		"id": "stage1", "number": 1,
		"title": "Cardiac Anatomy, Physiology & Biology",
		"summary": "Beating 3D heart from real anatomy: explore and dissect it, control heart rate, follow the cardiac cycle and the blood pumped through it, and simulate diseases.",
		"status": "available", "progress": 1.0,
		"milestone_note": "Heart Lab with dissection, cardiac cycle, animated blood flow through chambers and valves, diseases and quiz.",
		"scene": "res://scenes/stage1/heart_lab.tscn", "open_label": "Open Heart Lab",
	},
	{
		"id": "stage2", "number": 2,
		"title": "Electrophysiology & ECG",
		"summary": "Conduction system on the same heart model, animated impulse propagation, ECG waves and intervals, 12-lead viewer and six simulated rhythms.",
		"status": "available", "progress": 1.0,
		"milestone_note": "EP Lab with the conduction system, ECG waves and intervals, a 12-lead viewer and six simulated rhythms.",
		"scene": "res://scenes/stage2/ep_lab.tscn", "open_label": "Open EP Lab",
	},
	{
		"id": "stage3", "number": 3,
		"title": "Coronary Catheterization & Intervention",
		"summary": "Interactive right-radial coronary angiography and PCI: access, wires, catheter engagement, contrast injection, balloon and stent.",
		"status": "coming_soon", "progress": 0.0,
		"milestone_note": "Coming in a future release.",
		"scene": "", "open_label": "Coming soon",
	},
]

var quality: int = Quality.MEDIUM
var heart_style := "lifelike"
var backdrop := "mint"
var _styles := {}

func _ready() -> void:
	_load_settings()
	apply_quality(get_viewport())

func get_stage(stage_id: String) -> Dictionary:
	for s in stages:
		if s["id"] == stage_id:
			return s
	return {}

func set_quality(level: int) -> void:
	quality = clampi(level, Quality.LOW, Quality.HIGH)
	apply_quality(get_viewport())
	_save_settings()
	quality_changed.emit(quality)

## Applies viewport-level quality settings. Scenes listen to `quality_changed`
## for scene-specific adjustments (shadows, texture detail).
func apply_quality(vp: Viewport) -> void:
	if vp == null:
		return
	match quality:
		Quality.LOW:
			vp.msaa_3d = Viewport.MSAA_DISABLED
			vp.scaling_3d_scale = 0.85
		Quality.MEDIUM:
			vp.msaa_3d = Viewport.MSAA_2X
			vp.scaling_3d_scale = 1.0
		Quality.HIGH:
			vp.msaa_3d = Viewport.MSAA_4X
			vp.scaling_3d_scale = 1.0

## Heart colour styles from data/anatomy/tissue_styles.json (id -> dictionary).
func get_heart_styles() -> Array:
	if _styles.is_empty():
		var d = JSON.parse_string(FileAccess.get_file_as_string(STYLES_PATH)) if FileAccess.file_exists(STYLES_PATH) else null
		if d is Dictionary:
			for st in d.get("styles", []):
				_styles[st["id"]] = st
		else:
			push_warning("AppState: missing or invalid %s" % STYLES_PATH)
	return _styles.values()

func get_heart_style(id := "") -> Dictionary:
	get_heart_styles()
	return _styles.get(id if id != "" else heart_style, {})

func set_heart_style(id: String) -> void:
	get_heart_styles()
	if not _styles.has(id):
		return
	heart_style = id
	_save_settings()
	heart_style_changed.emit(id)

func get_backdrop() -> Array:
	for b in BACKDROPS:
		if b[0] == backdrop:
			return b
	return BACKDROPS[0]

func set_backdrop(id: String) -> void:
	backdrop = id
	_save_settings()
	backdrop_changed.emit(id)

func shadows_enabled() -> bool:
	return quality >= Quality.MEDIUM

func texture_detail() -> float:
	return 0.0 if quality == Quality.LOW else 1.0

func _load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SETTINGS_PATH) == OK:
		quality = clampi(int(cfg.get_value("graphics", "quality", Quality.MEDIUM)), Quality.LOW, Quality.HIGH)
		heart_style = str(cfg.get_value("view", "heart_style", "lifelike"))
		if int(cfg.get_value("view", "styles_version", 1)) < 2:
			heart_style = "lifelike"   # Update 4: new default look
		backdrop = str(cfg.get_value("view", "backdrop", "mint"))
		if int(cfg.get_value("view", "styles_version", 1)) < 3:
			backdrop = "mint"   # Update 7: light clinical theme

func _save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("graphics", "quality", quality)
	cfg.set_value("view", "heart_style", heart_style)
	cfg.set_value("view", "styles_version", 3)
	cfg.set_value("view", "backdrop", backdrop)
	var err := cfg.save(SETTINGS_PATH)
	if err != OK:
		push_warning("AppState: could not save settings (%s)" % error_string(err))
