The original reference images, videos and PDF stay in the user's folder
`the author's local reference folder` and are intentionally not copied into the project
(third-party copyright). See docs/01_Reference_Inventory.md.
